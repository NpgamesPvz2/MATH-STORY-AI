import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Award,
  ArrowRight,
  UserCheck,
  Calendar,
  Layers,
  Sparkles,
  X,
} from 'lucide-react';
import { ModerationChecklist, ModerationStatus, ProjectLesson } from '../../types/mathStory';
import { soundEffects } from '../../utils/audioEffects';

interface TeacherModerationProps {
  project: ProjectLesson;
  onUpdateChecklist: (checklist: ModerationChecklist) => void;
  onPublishProject?: (checklist: ModerationChecklist) => void;
  onGoToLibrary: () => void;
  selectedGrade?: string;
}

const getTodayDateString = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatDisplayDate = (dateStr?: string) => {
  if (!dateStr) return new Date().toLocaleDateString('vi-VN');
  try {
    const [y, m, d] = dateStr.split('-');
    if (y && m && d) return `${d}/${m}/${y}`;
  } catch (e) {}
  return dateStr;
};

export const TeacherModeration: React.FC<TeacherModerationProps> = ({
  project,
  onUpdateChecklist,
  onPublishProject,
  onGoToLibrary,
  selectedGrade = 'Lớp 2',
}) => {
  const todayStr = getTodayDateString();

  const [checklist, setChecklist] = useState<ModerationChecklist>(() => {
    const existing = project.moderationChecklist;
    return {
      curriculumCompliant: existing?.curriculumCompliant ?? true,
      dataAccurate: existing?.dataAccurate ?? true,
      calculationVerified: existing?.calculationVerified ?? true,
      dialogueAppropriate: existing?.dialogueAppropriate ?? true,
      imageSafe: existing?.imageSafe ?? true,
      characterConsistent: existing?.characterConsistent ?? true,
      audioClear: existing?.audioClear ?? true,
      questionEngaging: existing?.questionEngaging ?? true,
      pedagogicalFeedback: existing?.pedagogicalFeedback ?? true,
      trialTested: existing?.trialTested ?? true,
      status: existing?.status ?? 'ĐÃ_XUẤT_BẢN',
      approvedBy: existing?.approvedBy ? existing.approvedBy.replace(/^Cô giáo\s*/i, '') : 'Hoàng Diệu Hương',
      approvedDate: todayStr, // Luôn cập nhật ngày phê duyệt xuất bản là ngày hôm nay
    };
  });

  const [approvedDate, setApprovedDate] = useState<string>(todayStr);
  const [teacherName, setTeacherName] = useState(
    checklist.approvedBy ? checklist.approvedBy.replace(/^Cô giáo\s*/i, '') : 'Hoàng Diệu Hương'
  );
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showPublishModal, setShowPublishModal] = useState(false);

  const handleToggle = (key: keyof Omit<ModerationChecklist, 'status' | 'approvedBy' | 'approvedDate'>) => {
    const updated = {
      ...checklist,
      [key]: !checklist[key],
    };
    setChecklist(updated);
    onUpdateChecklist(updated);
  };

  const handleStatusChange = (status: ModerationStatus) => {
    const updated: ModerationChecklist = {
      ...checklist,
      status,
      approvedBy: teacherName,
      approvedDate: approvedDate || todayStr,
    };
    setChecklist(updated);
    if (status === 'ĐÃ_XUẤT_BẢN' && onPublishProject) {
      onPublishProject(updated);
    } else {
      onUpdateChecklist(updated);
    }
    setSaveSuccess(true);
    if (status === 'ĐÃ_XUẤT_BẢN') {
      soundEffects.playCelebration();
      setShowPublishModal(true);
    }
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const criteriaList: {
    key: keyof Omit<ModerationChecklist, 'status' | 'approvedBy' | 'approvedDate'>;
    title: string;
    desc: string;
  }[] = [
    {
      key: 'curriculumCompliant',
      title: '1. Nội dung bám sát SGK Toán 2 (GDPT 2018)',
      desc: 'Phù hợp mục tiêu cần đạt của khối lớp 2, đúng mạch kiến thức số và phép tính.',
    },
    {
      key: 'dataAccurate',
      title: '2. Dữ kiện bài toán chính xác',
      desc: 'Các con số và tình huống thực tế, không gây hiểu lầm cho học sinh.',
    },
    {
      key: 'calculationVerified',
      title: '3. Phép tính được kiểm tra xác định',
      desc: 'Được thẩm định bởi hàm toán học độc lập, kết quả 25 + 17 = 42 chính xác tuyệt đối.',
    },
    {
      key: 'dialogueAppropriate',
      title: '4. Lời thoại trong sáng, phù hợp lứa tuổi 7-8',
      desc: 'Ngôn từ chuẩn tiếng Việt, gần gũi, khích lệ tinh thần học tập của trẻ.',
    },
    {
      key: 'imageSafe',
      title: '5. Hình ảnh an toàn, thẩm mỹ sư phạm cao',
      desc: 'Hoạt hình 3D tươi sáng, không chứa yếu tố bạo lực hay chi tiết phản cảm.',
    },
    {
      key: 'characterConsistent',
      title: '6. Nhân vật giữ vững tạo hình nhất quán',
      desc: 'Áp dụng Character Seed Profile cho Bé Lan xuyên suốt các cảnh.',
    },
    {
      key: 'audioClear',
      title: '7. Âm thanh rõ ràng, tốc độ vừa phải',
      desc: 'Âm lượng cân đối giữa giọng đọc và nhạc nền, không bị rè méo.',
    },
    {
      key: 'questionEngaging',
      title: '8. Câu hỏi tương tác kích thích tư duy',
      desc: 'Đặt ở cảnh 2 đúng thời điểm, không lộ đáp số trước khi học sinh trả lời.',
    },
    {
      key: 'pedagogicalFeedback',
      title: '9. Phản hồi sư phạm khích lệ',
      desc: 'Khi sai có gợi ý từng bước, không chê bai hay gây áp lực tâm lý cho học sinh.',
    },
    {
      key: 'trialTested',
      title: '10. Đã chạy thử nghiệm nghiệm thu hoàn chỉnh',
      desc: 'Giáo viên đã trực tiếp trải nghiệm toàn bộ video và kiểm tra quy trình hoạt động.',
    },
  ];

  const allPassed = criteriaList.every((c) => checklist[c.key]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-emerald-100 text-emerald-700">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 8: Bảng Giáo Viên Kiểm Duyệt Sư Phạm
            </h2>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full">
              10 Tiêu chuẩn kiểm định
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Đảm bảo tính chuẩn mực giáo dục trước khi xuất bản học liệu cho học sinh {selectedGrade} trải nghiệm.
          </p>
        </div>
      </div>



      {/* 10 Criteria Checklist */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-600" />
            <span>10 Tiêu Chí Nghiệm Thu Sư Phạm (Bắt buộc hoàn thành)</span>
          </h3>
          <span
            className={`text-xs font-bold px-3 py-1 rounded-full ${
              allPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
            }`}
          >
            {allPassed ? '✓ Đạt 10/10 tiêu chí' : 'Chưa hoàn thành đủ 10 tiêu chí'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {criteriaList.map((item) => {
            const isChecked = checklist[item.key];
            return (
              <div
                key={item.key}
                onClick={() => handleToggle(item.key)}
                className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3 ${
                  isChecked
                    ? 'border-emerald-400 bg-emerald-50/50'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-lg mt-0.5 flex items-center justify-center font-bold text-xs ${
                    isChecked
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'border-2 border-slate-300 bg-white'
                  }`}
                >
                  {isChecked ? '✓' : ''}
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900">{item.title}</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Teacher Signature Box */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mt-4">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Giáo viên phê duyệt:</label>
            <input
              type="text"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-800"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-slate-700 block">Ngày phê duyệt xuất bản:</label>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.2 rounded-full">
                Hôm nay ({formatDisplayDate(approvedDate)})
              </span>
            </div>
            <input
              type="date"
              value={approvedDate}
              onChange={(e) => setApprovedDate(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-800"
            />
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-medium">
            {allPassed ? (
              <span className="text-emerald-700 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Đã đủ điều kiện để xuất bản lên hệ thống lớp học</span>
              </span>
            ) : (
              <span className="text-amber-700 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Vui lòng tích đủ 10 tiêu chí sư phạm trước khi xuất bản</span>
              </span>
            )}
          </div>

          <button
            onClick={() => handleStatusChange('ĐÃ_XUẤT_BẢN')}
            disabled={!allPassed}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
          >
            <Award className="w-4 h-4" />
            <span>Phê Duyệt & Xuất Bản Lên Hệ Thống Lớp</span>
          </button>
        </div>
      </div>

      {/* Bottom Navigation Bar like Phân hệ 1 */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="text-xs text-slate-500 font-medium">
          Sau khi kiểm duyệt sư phạm, bạn có thể chuyển sang <strong>Phân hệ 9</strong> để quản lý toàn bộ kho học liệu đã xuất bản.
        </div>
        <button
          onClick={onGoToLibrary}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <span>Sang Thư Viện Học Liệu (Phân hệ 9)</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Publication Success Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border-2 border-emerald-300 space-y-5 animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
                  <Award className="w-6 h-6" />
                </span>
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    Phê Duyệt & Xuất Bản Thành Công!
                  </h3>
                  <span className="text-[11px] text-emerald-700 font-bold">
                    Học liệu chính thức phát hành lên hệ thống lớp
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowPublishModal(false)}
                className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content summary */}
            <div className="space-y-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-bold">Tên bài học:</span>
                <span className="font-extrabold text-slate-900 truncate max-w-[260px]">{project.title}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-bold">Giáo viên phê duyệt:</span>
                <span className="font-extrabold text-slate-900">{teacherName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-bold">Ngày xuất bản:</span>
                <span className="font-extrabold text-slate-900">{formatDisplayDate(approvedDate || checklist.approvedDate)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-bold">Kiểm định sư phạm:</span>
                <span className="font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">✓ Đạt 10/10 tiêu chí</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Bài toán câu chuyện hoạt hình đã sẵn sàng cho học sinh tương tác học tập và lưu kết quả đánh giá theo từng mức độ cá nhân hóa.
            </p>

            {/* Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => {
                  setShowPublishModal(false);
                  onGoToLibrary();
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 text-white font-black text-xs shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Xem Thư Viện Học Liệu</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setShowPublishModal(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer text-center"
              >
                Đóng thông báo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
