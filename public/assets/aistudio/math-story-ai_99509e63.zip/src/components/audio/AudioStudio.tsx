import React, { useState, useEffect } from 'react';
import {
  Mic,
  Play,
  Volume2,
  Sparkles,
  CheckCircle2,
  Music,
  Trash2,
  ArrowRight,
  Wand2,
  Square,
} from 'lucide-react';
import { Storyboard } from '../../types/mathStory';
import { requestTTS } from '../../services/api';
import { soundEffects } from '../../utils/audioEffects';

interface AudioStudioProps {
  storyboard: Storyboard | null;
  onSceneAudioUpdated: (sceneNumber: number, audioUrl: string) => void;
  onBackgroundMusicUpdated?: (bgMusic: string, bgVolume: number) => void;
  onGoToInteractivePlayer: () => void;
}

export function normalizeMathSpeech(text: string): string {
  if (!text) return '';
  let res = text;
  // 1. Remove unnatural parenthetical insertions
  res = res.replace(/\s*\([hH]oặc[^)]*\)/g, '');
  res = res.replace(/\s*\(và các[^)]*\)/g, '');

  // 2. Math operations:
  // Multiplication: 4x5=20, 4 x 5 = 20, 4*5=20, 4 × 5 = 20 -> 4 nhân 5 bằng 20
  res = res.replace(/(\d+)\s*[xX*×]\s*(\d+)\s*=\s*(\d+)/g, '$1 nhân $2 bằng $3');
  // Standalone multiplication: 4x5, 4 × 5, 4 * 5
  res = res.replace(/(\d+)\s*[xX*×]\s*(\d+)/g, '$1 nhân $2');

  // Division: 20:4=5, 20 : 4 = 5, 20 / 4 = 5 -> 20 chia 4 bằng 5
  res = res.replace(/(\d+)\s*[:/]\s*(\d+)\s*=\s*(\d+)/g, '$1 chia $2 bằng $3');
  // Standalone division: 20 : 4, 20 / 4
  res = res.replace(/(\d+)\s*[:/]\s*(\d+)/g, '$1 chia $2');

  // Addition: 25 + 17 = 42 -> 25 cộng 17 bằng 42
  res = res.replace(/(\d+)\s*\+\s*(\d+)\s*=\s*(\d+)/g, '$1 cộng $2 bằng $3');
  // Standalone addition: 25 + 17
  res = res.replace(/(\d+)\s*\+\s*(\d+)/g, '$1 cộng $2');

  // Subtraction: 25 - 17 = 8 -> 25 trừ 17 bằng 8
  res = res.replace(/(\d+)\s*-\s*(\d+)\s*=\s*(\d+)/g, '$1 trừ $2 bằng $3');
  // Standalone subtraction: 25 - 17
  res = res.replace(/(\d+)\s*-\s*(\d+)/g, '$1 trừ $2');

  // Equals: "= 20" -> "bằng 20"
  res = res.replace(/\s*=\s*(\d+)/g, ' bằng $1');

  return res.replace(/\s{2,}/g, ' ').trim();
}

export const AudioStudio: React.FC<AudioStudioProps> = ({
  storyboard,
  onSceneAudioUpdated,
  onBackgroundMusicUpdated,
  onGoToInteractivePlayer,
}) => {
  const [ttsLoadingScene, setTtsLoadingScene] = useState<Record<number, boolean>>({});
  const [ttsStatusScene, setTtsStatusScene] = useState<Record<number, string>>({});
  const [isGeneratingAll, setIsGeneratingAll] = useState<boolean>(false);

  // Background music state
  const [bgMusic, setBgMusic] = useState<string>(storyboard?.bgMusic || 'vui-tuoi');
  const [bgVolume, setBgVolume] = useState<number>(storyboard?.bgVolume ?? 25);
  const [isPlayingMusicPreview, setIsPlayingMusicPreview] = useState<boolean>(false);

  // Voice preference per scene
  const [voiceScene1, setVoiceScene1] = useState<string>('auto');
  const [voiceScene2, setVoiceScene2] = useState<string>('auto');
  const [voiceScene3, setVoiceScene3] = useState<string>('auto');

  // Sync background music state when storyboard changes
  useEffect(() => {
    if (storyboard?.bgMusic) setBgMusic(storyboard.bgMusic);
    if (storyboard?.bgVolume !== undefined) setBgVolume(storyboard.bgVolume);
  }, [storyboard?.bgMusic, storyboard?.bgVolume]);

  const handleMusicChange = (newMusic: string) => {
    setBgMusic(newMusic);
    onBackgroundMusicUpdated?.(newMusic, bgVolume);
    if (isPlayingMusicPreview) {
      soundEffects.startBackgroundMusic(newMusic, bgVolume);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setBgVolume(newVol);
    onBackgroundMusicUpdated?.(bgMusic, newVol);
    if (isPlayingMusicPreview) {
      soundEffects.setBackgroundMusicVolume(newVol);
    }
  };

  const toggleMusicPreview = () => {
    if (isPlayingMusicPreview) {
      soundEffects.stopBackgroundMusic();
      setIsPlayingMusicPreview(false);
    } else {
      soundEffects.startBackgroundMusic(bgMusic, bgVolume);
      setIsPlayingMusicPreview(true);
    }
  };

  useEffect(() => {
    return () => {
      soundEffects.stopBackgroundMusic();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const scenes = storyboard?.scenes || [];
  const scene1 = scenes.find((s) => s.sceneNumber === 1) || scenes[0];
  const scene2 = scenes.find((s) => s.sceneNumber === 2) || scenes[1];
  const scene3 = scenes.find((s) => s.sceneNumber === 3) || scenes[2];

  // Helper for generating AI voice for a given scene
  const generateAiAudioForScene = async (sceneNumber: number, voiceSetting: string) => {
    const targetScene = scenes.find((s) => s.sceneNumber === sceneNumber);
    if (!targetScene) return;

    setTtsLoadingScene((prev) => ({ ...prev, [sceneNumber]: true }));
    setTtsStatusScene((prev) => ({
      ...prev,
      [sceneNumber]: `Đang gửi yêu cầu tạo giọng đọc AI Cảnh ${sceneNumber}...`,
    }));

    try {
      const charName = targetScene.characters?.[0] || 'Bé Lan';
      const voiceToRequest = voiceSetting === 'auto' ? undefined : voiceSetting;
      const spokenDialogue = normalizeMathSpeech(targetScene.dialogue);
      const res = await requestTTS(spokenDialogue, voiceToRequest, charName);

      if (res.success && res.audioUrl) {
        onSceneAudioUpdated(sceneNumber, res.audioUrl);
        setTtsStatusScene((prev) => ({
          ...prev,
          [sceneNumber]: `✨ Đã tạo giọng đọc AI Cảnh ${sceneNumber} thành công (${res.voiceUsed || 'Gemini TTS'})!`,
        }));
      } else {
        // Fallback synthesize pleasant voice
        if ('speechSynthesis' in window) {
          const utt = new SpeechSynthesisUtterance(spokenDialogue);
          utt.lang = 'vi-VN';
          utt.rate = 0.92;
          const isChild = charName.toLowerCase().includes('lan') || charName.toLowerCase().includes('bé') || charName.toLowerCase().includes('nam');
          utt.pitch = isChild ? 1.35 : 1.0;
          window.speechSynthesis.speak(utt);
        }
        setTtsStatusScene((prev) => ({
          ...prev,
          [sceneNumber]: `🔊 Đã kích hoạt giọng đọc chuẩn tiếng Việt cho Cảnh ${sceneNumber}!`,
        }));
      }
    } catch (err: any) {
      setTtsStatusScene((prev) => ({
        ...prev,
        [sceneNumber]: `⚠️ Lỗi tạo giọng: ${err.message || 'Không thể kết nối'}.`,
      }));
    } finally {
      setTtsLoadingScene((prev) => ({ ...prev, [sceneNumber]: false }));
    }
  };

  // Batch generate all 3 scenes at once
  const handleGenerateAllScenes = async () => {
    setIsGeneratingAll(true);
    await Promise.all([
      generateAiAudioForScene(1, voiceScene1),
      generateAiAudioForScene(2, voiceScene2),
      generateAiAudioForScene(3, voiceScene3),
    ]);
    setIsGeneratingAll(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-pink-100 text-pink-700">
              <Mic className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 5: Tạo Giọng Đọc AI Cho Các Cảnh (Cảnh 1, 2, 3)
            </h2>
            <span className="text-xs bg-pink-100 text-pink-800 font-bold px-2.5 py-0.5 rounded-full">
              Chuyên biệt Giọng Đọc AI Sư Phạm
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Hệ thống chuyên biệt tạo giọng đọc hoạt hình AI chuẩn sư phạm tiếng Việt cho từng nhân vật và phân cảnh kịch bản.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateAllScenes}
            disabled={isGeneratingAll}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
          >
            <Wand2 className="w-4 h-4" />
            <span>{isGeneratingAll ? 'Đang tạo cả 3 cảnh...' : '⚡ Tạo Giọng AI Cả 3 Cảnh (1 Chạm)'}</span>
          </button>
        </div>
      </div>

      {/* Background Music Config Card */}
      <div className="bg-white rounded-3xl p-5 border border-pink-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-pink-600" />
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">
                Nhạc Nền Hoạt Hình Đi Kèm Giọng AI:
              </h3>
              <p className="text-[11px] text-slate-500">
                Nhạc nền sẽ tự động giảm âm lượng (ducking) êm ái khi giọng đọc AI phát lời thoại.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">{bgVolume}%</span>
            <button
              type="button"
              onClick={toggleMusicPreview}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                isPlayingMusicPreview
                  ? 'bg-red-500 text-white shadow-xs'
                  : 'bg-pink-100 hover:bg-pink-200 text-pink-900 border border-pink-200'
              }`}
            >
              {isPlayingMusicPreview ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Dừng nghe</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Nghe thử nhạc</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          <select
            value={bgMusic}
            onChange={(e) => handleMusicChange(e.target.value)}
            className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-medium"
          >
            <option value="vui-tuoi">🎵 Vui tươi: Bé tập đếm rộn ràng (C major vui nhộn)</option>
            <option value="diu-dang">🌸 Êm dịu: Vườn trường tuổi thơ (Piano êm dịu)</option>
            <option value="kham-pha">🚀 Khám phá: Vùng đất Toán học (Nhịp điệu phiêu lưu)</option>
            <option value="khong-nhac">🔇 Không phát nhạc nền</option>
          </select>

          <div className="flex items-center gap-3 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
            <span className="text-xs text-slate-600 font-bold whitespace-nowrap">Âm lượng nhạc:</span>
            <input
              type="range"
              min="0"
              max="100"
              value={bgVolume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              className="w-full accent-pink-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {storyboard ? (
        /* 3 CARDS: CHỈ TẠO GIỌNG ĐỌC AI CHO 3 CẢNH */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* CẢNH 1 */}
          {scene1 && (
            <div className="bg-white rounded-3xl p-5 border-2 border-sky-300 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-xl bg-sky-600 text-white font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <h3 className="font-black text-slate-900 text-sm">
                      CẢNH 1: {scene1.title.split(':')[1] || scene1.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                    Khởi đầu
                  </span>
                </div>

                <div className="bg-sky-50 border border-sky-200 rounded-2xl p-3 space-y-1">
                  <span className="text-[10px] text-sky-800 font-extrabold block">
                    Lời thoại ({scene1.characters.join(', ')}):
                  </span>
                  <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-sky-100">
                    "{scene1.dialogue.replace(/\s*\([hH]oặc[^)]*\)/g, '')}"
                  </p>
                </div>

                {/* AI Speech TTS */}
                <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>Chọn giọng AI Cảnh 1:</span>
                    </span>
                    <select
                      value={voiceScene1}
                      onChange={(e) => setVoiceScene1(e.target.value)}
                      className="text-[10px] p-1.5 rounded-lg border border-purple-300 bg-white font-bold text-purple-900"
                    >
                      <option value="auto">Tự động ({scene1.characters[0] || 'Bé Lan'})</option>
                      <option value="Aoede">Bé gái (Aoede)</option>
                      <option value="Puck">Bé trai (Puck)</option>
                      <option value="Kore">Cô giáo / Mẹ (Kore)</option>
                    </select>
                  </div>

                  <button
                    onClick={() => generateAiAudioForScene(1, voiceScene1)}
                    disabled={ttsLoadingScene[1]}
                    className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{ttsLoadingScene[1] ? 'Đang tạo giọng AI...' : 'Tạo Giọng Đọc AI Cảnh 1'}</span>
                  </button>

                  {ttsStatusScene[1] && (
                    <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200 font-medium">
                      {ttsStatusScene[1]}
                    </p>
                  )}
                </div>
              </div>

              {/* Playback preview for Scene 1 */}
              {scene1.audioUrl && (
                <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                    <span className="flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Đã có file âm thanh AI Cảnh 1</span>
                    </span>
                    <button
                      onClick={() => onSceneAudioUpdated(1, '')}
                      className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Xóa</span>
                    </button>
                  </div>
                  <audio src={scene1.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                </div>
              )}
            </div>
          )}

          {/* CẢNH 2 */}
          {scene2 && (
            <div className="bg-white rounded-3xl p-5 border-2 border-amber-300 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-xl bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="font-black text-slate-900 text-sm">
                      CẢNH 2: {scene2.title.split(':')[1] || scene2.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                    Dừng câu hỏi ❓
                  </span>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 space-y-1">
                  <span className="text-[10px] text-amber-800 font-extrabold block">
                    Lời thoại ({scene2.characters.join(', ')}):
                  </span>
                  <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-amber-100">
                    "{scene2.dialogue.replace(/\s*\([hH]oặc[^)]*\)/g, '')}"
                  </p>
                </div>

                {/* AI Speech TTS */}
                <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>Chọn giọng AI Cảnh 2:</span>
                    </span>
                    <select
                      value={voiceScene2}
                      onChange={(e) => setVoiceScene2(e.target.value)}
                      className="text-[10px] p-1.5 rounded-lg border border-purple-300 bg-white font-bold text-purple-900"
                    >
                      <option value="auto">Tự động ({scene2.characters[1] || scene2.characters[0] || 'Mẹ'})</option>
                      <option value="Kore">Cô giáo / Mẹ (Kore)</option>
                      <option value="Aoede">Bé gái (Aoede)</option>
                      <option value="Puck">Bé trai (Puck)</option>
                    </select>
                  </div>

                  <button
                    onClick={() => generateAiAudioForScene(2, voiceScene2)}
                    disabled={ttsLoadingScene[2]}
                    className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{ttsLoadingScene[2] ? 'Đang tạo giọng AI...' : 'Tạo Giọng Đọc AI Cảnh 2'}</span>
                  </button>

                  {ttsStatusScene[2] && (
                    <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200 font-medium">
                      {ttsStatusScene[2]}
                    </p>
                  )}
                </div>
              </div>

              {/* Playback preview for Scene 2 */}
              {scene2.audioUrl && (
                <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                    <span className="flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Đã có file âm thanh AI Cảnh 2</span>
                    </span>
                    <button
                      onClick={() => onSceneAudioUpdated(2, '')}
                      className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Xóa</span>
                    </button>
                  </div>
                  <audio src={scene2.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                </div>
              )}
            </div>
          )}

          {/* CẢNH 3 */}
          {scene3 && (
            <div className="bg-white rounded-3xl p-5 border-2 border-emerald-300 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-xl bg-emerald-600 text-white font-black text-xs flex items-center justify-center">
                      3
                    </span>
                    <h3 className="font-black text-slate-900 text-sm">
                      CẢNH 3: {scene3.title.split(':')[1] || scene3.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Kết luận đáp số
                  </span>
                </div>

                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 space-y-1">
                  <span className="text-[10px] text-emerald-800 font-extrabold block">
                    Lời thoại ({scene3.characters.join(', ')}):
                  </span>
                  <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-emerald-100">
                    "{scene3.dialogue.replace(/\s*\([hH]oặc[^)]*\)/g, '')}"
                  </p>
                </div>

                {/* AI Speech TTS */}
                <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>Chọn giọng AI Cảnh 3:</span>
                    </span>
                    <select
                      value={voiceScene3}
                      onChange={(e) => setVoiceScene3(e.target.value)}
                      className="text-[10px] p-1.5 rounded-lg border border-purple-300 bg-white font-bold text-purple-900"
                    >
                      <option value="auto">Tự động ({scene3.characters[0] || 'Bé Lan'})</option>
                      <option value="Aoede">Bé gái (Aoede)</option>
                      <option value="Puck">Bé trai (Puck)</option>
                      <option value="Kore">Cô giáo / Mẹ (Kore)</option>
                    </select>
                  </div>

                  <button
                    onClick={() => generateAiAudioForScene(3, voiceScene3)}
                    disabled={ttsLoadingScene[3]}
                    className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{ttsLoadingScene[3] ? 'Đang tạo giọng AI...' : 'Tạo Giọng Đọc AI Cảnh 3'}</span>
                  </button>

                  {ttsStatusScene[3] && (
                    <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200 font-medium">
                      {ttsStatusScene[3]}
                    </p>
                  )}
                </div>
              </div>

              {/* Playback preview for Scene 3 */}
              {scene3.audioUrl && (
                <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                    <span className="flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Đã có file âm thanh AI Cảnh 3</span>
                    </span>
                    <button
                      onClick={() => onSceneAudioUpdated(3, '')}
                      className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Xóa</span>
                    </button>
                  </div>
                  <audio src={scene3.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Mic className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có kịch bản lời thoại</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Vui lòng hoàn thành kịch bản ở Phân hệ 2 để có lời thoại tạo giọng đọc AI.
          </p>
        </div>
      )}

      {/* Bottom Navigation Bar like Phân hệ 1 */}
      {storyboard && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-medium">
            Đã hoàn thành tạo giọng đọc AI cho các cảnh. Chuyển sang <strong>Phân hệ 6</strong> để tổng hợp video và âm thanh.
          </div>
          <button
            onClick={onGoToInteractivePlayer}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <span>Sang Tạo Video &amp; Âm Thanh (Phân hệ 6)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
