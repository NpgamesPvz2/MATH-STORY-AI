/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header, ActiveTab } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { HomeDashboard } from './components/home/HomeDashboard';
import { MathInputAnalysis } from './components/analysis/MathInputAnalysis';
import { StoryboardEditor } from './components/storyboard/StoryboardEditor';
import { CharacterLibrary } from './components/characters/CharacterLibrary';
import { ImageStudio } from './components/imageStudio/ImageStudio';
import { VideoStudio } from './components/videoStudio/VideoStudio';
import { AudioStudio } from './components/audio/AudioStudio';
import { InteractivePlayer } from './components/interactive/InteractivePlayer';
import { PersonalizedLearning } from './components/personalized/PersonalizedLearning';
import { TeacherModeration } from './components/moderation/TeacherModeration';
import { MaterialLibrary } from './components/library/MaterialLibrary';
import { StudentManagement } from './components/students/StudentManagement';
import { TeacherReports } from './components/reports/TeacherReports';
import { GoogleFlowModal } from './components/flowGuide/GoogleFlowModal';
import {
  CharacterProfile,
  MathAnalysisResult,
  ModerationChecklist,
  ProjectLesson,
  Storyboard,
  StoryTheme,
} from './types/mathStory';
import {
  fetchAppStatus,
  fetchCharacters,
  fetchProjects,
  saveProject,
  updateProject,
} from './services/api';

function createStoryboardFromAnalysis(
  analysis: MathAnalysisResult,
  theme: StoryTheme = 'Gia đình và cuộc sống',
  characterName: string = 'Bé Lan'
): Storyboard {
  const num1 = analysis.num1 ?? analysis.deterministicCheck?.numbers?.[0] ?? 25;
  const num2 = analysis.num2 ?? analysis.deterministicCheck?.numbers?.[1] ?? 17;
  const op = analysis.operation || analysis.deterministicCheck?.operation || 'CỘNG';
  const unit = analysis.unit || analysis.deterministicCheck?.unit || 'quả cam';
  const res = analysis.result ?? analysis.deterministicCheck?.result ?? (op.includes('TRỪ') ? Math.max(num1, num2) - Math.min(num1, num2) : num1 + num2);
  const calc = analysis.calculation || `${num1} + ${num2} = ${res}`;

  let scene1Title = `Cảnh 1: Khởi đầu vui tươi cùng ${characterName}`;
  let scene1Dialogue = `Chào các bạn nhỏ! Mình đang có ${num1} ${unit} đây này!`;
  let scene1Action = `${characterName} đang vui vẻ chăm sóc và chuẩn bị ${num1} ${unit}.`;
  let scene1Math = `Dữ kiện 1: ${num1} ${unit}`;

  let scene2Title = `Cảnh 2: Tình huống phát sinh & Câu hỏi tương tác`;
  let scene2Action = `Tình huống xuất hiện với ${num2} ${unit}. ${characterName} tạm dừng lại để cùng các bạn học sinh suy nghĩ!`;
  let scene2Dialogue = `Bây giờ các bạn hãy giúp mình tìm phép tính đúng nhé!`;
  let scene2Math = `Dữ kiện 2: ${num2} ${unit}`;

  let questionText = `Đố em: Để tìm kết quả bài toán, ta chọn phép tính nào?`;
  let correctLabel = `A. ${num1} + ${num2}`;
  let distractor1 = `B. ${num1} - ${num2}`;
  let distractor2 = `C. ${num1} × ${num2}`;
  let correctFeedback = `Tuyệt vời! Em chọn phép tính rất chính xác!`;
  let hint1 = `Em hãy đọc kỹ câu hỏi của bài toán nhé!`;
  let hint2 = `Quan sát mối quan hệ giữa ${num1} và ${num2} ${unit}.`;

  if (op.includes('TRỪ') || op === '-') {
    scene1Dialogue = `Chào các bạn! Lúc đầu mình có ${num1} ${unit} đấy!`;
    scene2Dialogue = `Sau đó đã bớt đi (hoặc dùng hết) ${num2} ${unit}. Đố các bạn biết còn lại bao nhiêu ${unit}?`;
    questionText = `Đố em: Muốn biết còn lại bao nhiêu ${unit}, ta thực hiện phép tính gì?`;
    correctLabel = `A. ${num1} - ${num2}`;
    distractor1 = `B. ${num1} + ${num2}`;
    distractor2 = `C. ${num1} : ${num2}`;
    correctFeedback = `Hoan hô em! Muốn tìm phần còn lại ta lấy ${num1} - ${num2}.`;
    hint1 = `Khi bớt đi thì số lượng sẽ ít hơn lúc đầu!`;
    hint2 = `Ít hơn thì dùng phép tính trừ (-) em nhé!`;
  } else if (op.includes('NHÂN') || op === '×' || op === '*') {
    scene1Dialogue = `Chào các bạn! Ở đây có ${num1} nhóm (hoặc hàng) ${unit} này!`;
    scene2Dialogue = `Mỗi nhóm có đúng ${num2} ${unit}. Đố các bạn biết tất cả có bao nhiêu ${unit}?`;
    questionText = `Đố em: Để tính tất cả số ${unit} trong các nhóm đều nhau, ta dùng phép tính nào?`;
    correctLabel = `A. ${num1} × ${num2}`;
    distractor1 = `B. ${num1} + ${num2}`;
    distractor2 = `C. ${num1} - ${num2}`;
    correctFeedback = `Xuất sắc! Lấy nhiều lần bằng nhau ta dùng phép nhân ${num1} × ${num2}.`;
    hint1 = `Mỗi nhóm đều có ${num2} ${unit}, có tất cả ${num1} nhóm!`;
    hint2 = `Lấy nhiều lần bằng nhau thì ta dùng phép tính nhân (×) nhé!`;
  } else if (op.includes('CHIA') || op === ':') {
    scene1Dialogue = `Chào các bạn! Mình có tất cả ${num1} ${unit}!`;
    scene2Dialogue = `Mình muốn chia đều cho ${num2} bạn. Đố các bạn mỗi bạn nhận được bao nhiêu?`;
    questionText = `Đố em: Để chia đều ${num1} ${unit} cho ${num2} phần, ta chọn phép tính nào?`;
    correctLabel = `A. ${num1} : ${num2}`;
    distractor1 = `B. ${num1} - ${num2}`;
    distractor2 = `C. ${num1} + ${num2}`;
    correctFeedback = `Rất giỏi! Chia thành các phần bằng nhau ta thực hiện phép chia ${num1} : ${num2}.`;
    hint1 = `Chia đều vào các phần bằng nhau!`;
    hint2 = `Chia đều thì ta dùng phép tính chia (:) em nhé!`;
  } else {
    scene1Dialogue = `Chào các bạn nhỏ! Mình đang có ${num1} ${unit} đây này!`;
    scene2Dialogue = `Ôi thích quá, bây giờ lại có thêm ${num2} ${unit} nữa! Đố các bạn biết tất cả có bao nhiêu?`;
    questionText = `Đố em: Để biết có tất cả bao nhiêu ${unit}, ta cần chọn phép tính nào?`;
    correctLabel = `A. ${num1} + ${num2}`;
    distractor1 = `B. ${num1} - ${num2}`;
    distractor2 = `C. ${num1} × ${num2}`;
    correctFeedback = `Tuyệt vời! Khi thêm vào hoặc tìm tất cả, ta thực hiện phép tính cộng ${num1} + ${num2}.`;
    hint1 = `Khi có thêm thì số ${unit} nhiều hơn hay ít đi?`;
    hint2 = `Nhiều hơn thì dùng phép tính cộng (+) em nhé!`;
  }

  return {
    theme,
    durationSeconds: 45,
    style: 'Hoạt hình 3D dễ thương',
    scenes: [
      {
        sceneNumber: 1,
        title: scene1Title,
        duration: 12,
        setting: `Không gian ngập tràn ánh nắng ấm áp theo phong cách ${theme}`,
        characters: [characterName],
        action: scene1Action,
        dialogue: scene1Dialogue,
        soundFx: 'Nhạc nền thiếu nhi vui tươi, tiếng chim ca ríu rít.',
        mathData: scene1Math,
        imagePrompt: `3D Pixar style cute animation. A friendly 7-year-old child character (${characterName}) cheerfully standing in a colorful environment (${theme}), interacting with ${num1} items (${unit}), bright vibrant lighting, 16:9 widescreen, clean educational design.`,
        motionPrompt: `Camera gently pans right as ${characterName} waves cheerfully to the camera with a bright friendly smile.`,
        interactiveQuestion: null,
      },
      {
        sceneNumber: 2,
        title: scene2Title,
        duration: 18,
        setting: `Không gian tiếp nối, xuất hiện thêm dữ kiện (${num2} ${unit})`,
        characters: [characterName],
        action: scene2Action,
        dialogue: scene2Dialogue,
        soundFx: 'Âm thanh chuông báo câu hỏi tương tác (ding dong), nhạc tạm dừng.',
        mathData: scene2Math,
        imagePrompt: `3D educational cartoon. Character ${characterName} looking curious and asking a question, holding hands to chin in thought, next to group of ${num2} items (${unit}), animated glowing question symbols in warm pastel colors, 16:9.`,
        motionPrompt: `The character tilts head with a curious expression, gentle slow zoom into the thought bubble.`,
        interactiveQuestion: {
          id: 'q-auto-1',
          type: 'CHỌN_PHÉP_TÍNH',
          question: questionText,
          options: [
            {
              label: correctLabel,
              isCorrect: true,
              feedback: correctFeedback,
            },
            {
              label: distractor1,
              isCorrect: false,
              feedback: `Chưa chính xác rồi. Em hãy đọc lại gợi ý nhé!`,
            },
            {
              label: distractor2,
              isCorrect: false,
              feedback: `Chưa đúng rồi. Em hãy thử lại một lần nữa!`,
            },
          ],
          resultCalculation: calc,
          hintStep1: hint1,
          hintStep2: hint2,
        },
      },
      {
        sceneNumber: 3,
        title: 'Cảnh 3: Chúc mừng & Đáp số trọn vẹn',
        duration: 15,
        setting: 'Khung cảnh rực rỡ sắc màu, các đồ vật được xếp ngay ngắn thành kết quả.',
        characters: [characterName],
        action: `${characterName} giơ hai tay ăn mừng chiến thắng cùng các bạn học sinh, hiển thị đáp số rõ ràng trên màn hình.`,
        dialogue: `Đúng rồi các bạn ơi! Phép tính là ${calc}! Các bạn học sinh Lớp 2A7 thật là thông minh!`,
        soundFx: 'Âm thanh pháo hoa chúc mừng tưng bừng, tiếng vỗ tay rộn rã.',
        mathData: `Đáp số: ${calc}`,
        imagePrompt: `3D Pixar animation style. Character ${characterName} celebrating joyfully with arms raised in victory, golden confetti stars raining down, celebratory atmosphere, cheerful expressions, 16:9 widescreen.`,
        motionPrompt: `Joyful celebration jump, colorful confetti sparkles descending gracefully as character laughs happily.`,
        interactiveQuestion: null,
      },
    ],
  };
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [userRole, setUserRole] = useState<'teacher' | 'student'>('teacher');
  const [projects, setProjects] = useState<ProjectLesson[]>([]);
  const [activeProject, setActiveProject] = useState<ProjectLesson | null>(null);
  const [characters, setCharacters] = useState<CharacterProfile[]>([]);
  const [selectedCharId, setSelectedCharId] = useState<string>('char-lan');
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [studentName, setStudentName] = useState<string>('Trần Minh Anh');
  const [studentCode, setStudentCode] = useState<string>('HS-2A2-01');

  // API Status & Flow Guide Modal State
  const [apiStatus, setApiStatus] = useState({
    geminiConfigured: false,
    deterministicMathEngineReady: true,
  });

  const [flowModal, setFlowModal] = useState<{
    isOpen: boolean;
    prompt?: string;
    sceneTitle?: string;
    startImageUrl?: string;
  }>({
    isOpen: false,
  });

  // Initial data loading from server
  useEffect(() => {
    fetchAppStatus().then((status) => {
      setApiStatus({
        geminiConfigured: Boolean(status.geminiConfigured),
        deterministicMathEngineReady: true,
      });
    });

    fetchCharacters().then((chars) => {
      setCharacters(chars);
      if (chars.length > 0) setSelectedCharId(chars[0].id);
    });

    fetchProjects().then((projs) => {
      setProjects(projs);
      if (projs.length > 0) {
        setActiveProject(projs[0]);
      }
    });
  }, []);

  // Update current project helpers
  const handleAnalysisApproved = (analysis: MathAnalysisResult) => {
    if (!activeProject) return;
    const newStoryboard = createStoryboardFromAnalysis(
      analysis,
      activeProject.storyboard?.theme || 'Gia đình và cuộc sống',
      activeProject.storyboard?.scenes?.[0]?.characters?.[0] || 'Bé Lan'
    );
    const updated: ProjectLesson = {
      ...activeProject,
      title: `Bài toán ${analysis.unit}: ${analysis.calculation || analysis.problemStatement.slice(0, 32)}`,
      problemText: analysis.problemStatement,
      mathAnalysis: analysis,
      storyboard: newStoryboard,
    };
    setActiveProject(updated);
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    updateProject(updated.id, updated).catch(console.error);
  };

  const handleStoryboardSaved = (storyboard: Storyboard) => {
    if (!activeProject) return;
    const updated: ProjectLesson = {
      ...activeProject,
      storyboard,
    };
    setActiveProject(updated);
    updateProject(updated.id, updated).catch(console.error);
  };

  const handleSceneImageUpdated = (sceneNumber: number, imageUrl: string) => {
    if (!activeProject?.storyboard) return;
    const updatedScenes = activeProject.storyboard.scenes.map((s) =>
      s.sceneNumber === sceneNumber ? { ...s, imageUrl } : s
    );
    const updated: ProjectLesson = {
      ...activeProject,
      storyboard: {
        ...activeProject.storyboard,
        scenes: updatedScenes,
      },
    };
    setActiveProject(updated);
    updateProject(updated.id, updated).catch(console.error);
  };

  const handleSceneVideoUpdated = (sceneNumber: number, videoUrl: string) => {
    if (!activeProject?.storyboard) return;
    const updatedScenes = activeProject.storyboard.scenes.map((s) =>
      s.sceneNumber === sceneNumber ? { ...s, videoUrl } : s
    );
    const updated: ProjectLesson = {
      ...activeProject,
      storyboard: {
        ...activeProject.storyboard,
        scenes: updatedScenes,
      },
    };
    setActiveProject(updated);
    updateProject(updated.id, updated).catch(console.error);
  };

  const handleSceneAudioUpdated = (sceneNumber: number, audioUrl: string) => {
    if (!activeProject?.storyboard) return;
    const updatedScenes = activeProject.storyboard.scenes.map((s) =>
      s.sceneNumber === sceneNumber ? { ...s, audioUrl } : s
    );
    const updated: ProjectLesson = {
      ...activeProject,
      storyboard: {
        ...activeProject.storyboard,
        scenes: updatedScenes,
      },
    };
    setActiveProject(updated);
    updateProject(updated.id, updated).catch(console.error);
  };

  const handleUpdateChecklist = (checklist: ModerationChecklist) => {
    if (!activeProject) return;
    const updated: ProjectLesson = {
      ...activeProject,
      moderationChecklist: checklist,
    };
    setActiveProject(updated);
    updateProject(updated.id, updated).catch(console.error);
  };

  // Open Google Flow Guide with prefilled scene prompt
  const handleOpenFlowGuide = (prompt?: string, sceneTitle?: string) => {
    setFlowModal({
      isOpen: true,
      prompt: prompt || '3D cute Pixar cartoon style animation for Grade 2 math story, 16:9 widescreen, smooth cinematic motion.',
      sceneTitle: sceneTitle || 'Cảnh bài toán Toán 2',
      startImageUrl: activeProject?.storyboard?.scenes?.[0]?.imageUrl,
    });
  };

  // Canonical sample project quick opener
  const handleOpenSampleProject = () => {
    const sample = projects.find((p) => p.isSample) || projects[0];
    if (sample) {
      setActiveProject(sample);
      setUserRole('student');
      setActiveTab('interactive');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* Universal Header with 12 Tabs & Author Credentials */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        userRole={userRole}
        setUserRole={setUserRole}
        apiStatus={apiStatus}
        onOpenFlowGuide={() => handleOpenFlowGuide()}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {activeTab === 'home' && activeProject && (
          <HomeDashboard
            onNavigate={(tab) => setActiveTab(tab)}
            sampleProject={activeProject}
            onOpenSampleProject={handleOpenSampleProject}
          />
        )}

        {activeTab === 'analysis' && (
          <MathInputAnalysis
            currentAnalysis={activeProject?.mathAnalysis || null}
            onAnalysisApproved={handleAnalysisApproved}
            onGoToStoryboard={() => setActiveTab('storyboard')}
          />
        )}

        {activeTab === 'storyboard' && activeProject && (
          <StoryboardEditor
            analysis={activeProject.mathAnalysis}
            characters={characters}
            currentStoryboard={activeProject.storyboard}
            onStoryboardSaved={handleStoryboardSaved}
            onOpenFlowGuideWithPrompt={(prompt, title) => handleOpenFlowGuide(prompt, title)}
            onGoToImageStudio={() => setActiveTab('images')}
          />
        )}

        {activeTab === 'characters' && (
          <CharacterLibrary
            characters={characters}
            selectedCharId={selectedCharId}
            onSelectCharacter={(id) => setSelectedCharId(id)}
            onCharacterAdded={(newChar) => setCharacters((prev) => [...prev, newChar])}
          />
        )}

        {activeTab === 'images' && (
          <ImageStudio
            storyboard={activeProject?.storyboard || null}
            mathAnalysis={activeProject?.mathAnalysis || null}
            onSceneImageUpdated={handleSceneImageUpdated}
            onGoToVideoStudio={() => setActiveTab('videos')}
          />
        )}

        {activeTab === 'videos' && (
          <VideoStudio
            storyboard={activeProject?.storyboard || null}
            mathAnalysis={activeProject?.mathAnalysis || null}
            onSceneVideoUpdated={handleSceneVideoUpdated}
            onOpenFlowGuideWithPrompt={(prompt, title) => handleOpenFlowGuide(prompt, title)}
            onGoToAudioStudio={() => setActiveTab('audio')}
            onGoToInteractivePlayer={() => setActiveTab('interactive')}
          />
        )}

        {activeTab === 'audio' && (
          <AudioStudio
            storyboard={activeProject?.storyboard || null}
            onSceneAudioUpdated={handleSceneAudioUpdated}
            onGoToInteractivePlayer={() => setActiveTab('interactive')}
          />
        )}

        {activeTab === 'interactive' && activeProject && (
          <InteractivePlayer
            project={activeProject}
            isDemoMode={isDemoMode}
            studentName={studentName}
            studentCode={studentCode}
            onGoToPersonalizedTier={() => setActiveTab('personalized')}
          />
        )}

        {activeTab === 'personalized' && activeProject && (
          <PersonalizedLearning
            project={activeProject}
            onGoToModeration={() => setActiveTab('moderation')}
          />
        )}

        {activeTab === 'moderation' && activeProject && (
          <TeacherModeration
            project={activeProject}
            onUpdateChecklist={handleUpdateChecklist}
            onGoToLibrary={() => setActiveTab('library')}
          />
        )}

        {activeTab === 'library' && (
          <MaterialLibrary
            projects={projects}
            activeProjectId={activeProject?.id || ''}
            onSelectProject={(p) => setActiveProject(p)}
            onGoToInteractivePlayer={() => setActiveTab('interactive')}
          />
        )}

        {activeTab === 'students' && (
          <StudentManagement
            isDemoMode={isDemoMode}
            onToggleDemoMode={(demo) => setIsDemoMode(demo)}
            onSelectStudentForInteraction={(code, name) => {
              setStudentCode(code);
              setStudentName(name);
              setActiveTab('interactive');
            }}
          />
        )}

        {activeTab === 'reports' && (
          <TeacherReports isDemoMode={isDemoMode} />
        )}
      </main>

      {/* Universal Footer */}
      <Footer />

      {/* Google Flow Guide Modal */}
      <GoogleFlowModal
        isOpen={flowModal.isOpen}
        onClose={() => setFlowModal({ isOpen: false })}
        promptToCopy={flowModal.prompt}
        sceneTitle={flowModal.sceneTitle}
        startImageUrl={flowModal.startImageUrl}
      />
    </div>
  );
}
