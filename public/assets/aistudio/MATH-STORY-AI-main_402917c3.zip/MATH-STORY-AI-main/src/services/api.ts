import {
  CharacterProfile,
  MathAnalysisResult,
  ProjectLesson,
  Storyboard,
  StudentSubmission,
  AnalyticsSummary,
} from '../types/mathStory';

export async function fetchAppStatus() {
  try {
    const res = await fetch('/api/status');
    if (!res.ok) throw new Error('Không thể kết nối máy chủ backend');
    return await res.json();
  } catch (err: any) {
    return {
      appName: 'MATH STORY AI',
      geminiConfigured: false,
      deterministicMathEngineReady: true,
      error: err.message,
    };
  }
}

export async function analyzeMathProblem(
  problemText: string,
  grade: string = 'Lớp 2',
  topic: string = 'Bài toán có lời văn'
): Promise<MathAnalysisResult> {
  const res = await fetch('/api/math/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ problemText, grade, topic }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Lỗi khi phân tích bài toán');
  }

  return await res.json();
}

export async function generateStoryboardScript(
  problemText: string,
  analysis: MathAnalysisResult,
  theme: string,
  durationSeconds: number,
  characterId: string
): Promise<Storyboard> {
  const res = await fetch('/api/math/generate-script', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      problemText,
      analysis,
      theme,
      durationSeconds,
      characterId,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Lỗi khi tạo kịch bản');
  }

  return await res.json();
}

export async function fetchCharacters(): Promise<CharacterProfile[]> {
  const res = await fetch('/api/characters');
  if (!res.ok) throw new Error('Lỗi lấy danh sách nhân vật');
  return await res.json();
}

export async function createCharacter(character: Partial<CharacterProfile>): Promise<CharacterProfile> {
  const res = await fetch('/api/characters', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(character),
  });
  if (!res.ok) throw new Error('Lỗi khi thêm nhân vật');
  return await res.json();
}

export async function generateAIImage(
  prompt: string,
  aspectRatio: string = '16:9',
  characterId?: string,
  sceneNumber: number = 1
): Promise<{ success: boolean; imageUrl?: string; error?: string; recommendation?: string; isFallback3D?: boolean }> {
  const PRESET_3D: Record<number, string> = {
    1: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=1200&q=80',
    2: 'https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?auto=format&fit=crop&w=1200&q=80',
    3: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80',
  };
  const fallbackUrl = PRESET_3D[sceneNumber] || PRESET_3D[1];

  try {
    const res = await fetch('/api/images/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, aspectRatio, characterId, sceneNumber }),
    });

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      await res.text();
      return {
        success: true,
        imageUrl: fallbackUrl,
        isFallback3D: true,
        recommendation: 'Hệ thống đã tự động áp dụng tranh minh họa 3D Pixar sắc nét cho bài học.',
      };
    }

    const data = await res.json();
    if (!data.imageUrl) {
      data.imageUrl = fallbackUrl;
    }
    return data;
  } catch (err: any) {
    console.warn('generateAIImage fetch caught error, using 3D fallback:', err);
    return {
      success: true,
      imageUrl: fallbackUrl,
      isFallback3D: true,
      recommendation: 'Đã kích hoạt tranh 3D Pixar minh họa trực quan chuẩn lớp 2.',
    };
  }
}

export async function requestTTS(
  text: string,
  voice: string = 'Kore'
): Promise<{ success: boolean; audioUrl?: string; error?: string; recommendation?: string }> {
  try {
    const res = await fetch('/api/audio/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, voice }),
    });

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      await res.text();
      return {
        success: false,
        error: 'Chưa kết nối API TTS',
        recommendation: 'Có thể sử dụng bộ giọng đọc Web Speech API tự nhiên của trình duyệt.',
      };
    }

    return await res.json();
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Lỗi khi gọi TTS',
      recommendation: 'Đang chuyển sang giọng đọc tiếng Việt của thiết bị.',
    };
  }
}

export async function fetchProjects(): Promise<ProjectLesson[]> {
  const res = await fetch('/api/projects');
  if (!res.ok) throw new Error('Lỗi khi tải danh sách dự án');
  return await res.json();
}

export async function fetchProjectById(id: string): Promise<ProjectLesson> {
  const res = await fetch(`/api/projects/${id}`);
  if (!res.ok) throw new Error('Không tìm thấy dự án');
  return await res.json();
}

export async function saveProject(project: Partial<ProjectLesson>): Promise<ProjectLesson> {
  const res = await fetch('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(project),
  });
  if (!res.ok) throw new Error('Lỗi khi lưu dự án');
  return await res.json();
}

export async function updateProject(id: string, project: Partial<ProjectLesson>): Promise<ProjectLesson> {
  const res = await fetch(`/api/projects/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(project),
  });
  if (!res.ok) throw new Error('Lỗi khi cập nhật dự án');
  return await res.json();
}

export async function submitStudentAnswer(payload: {
  projectId: string;
  studentCode: string;
  studentName: string;
  chosenOption: string;
  isCorrect: boolean;
  attemptCount: number;
  timeTakenSeconds: number;
  errorType: string;
  isDemo: boolean;
}): Promise<any> {
  const res = await fetch('/api/submissions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return await res.json();
}

export async function fetchAnalyticsSummary(): Promise<AnalyticsSummary> {
  const res = await fetch('/api/reports/summary');
  if (!res.ok) throw new Error('Lỗi khi tải báo cáo tổng hợp');
  return await res.json();
}
