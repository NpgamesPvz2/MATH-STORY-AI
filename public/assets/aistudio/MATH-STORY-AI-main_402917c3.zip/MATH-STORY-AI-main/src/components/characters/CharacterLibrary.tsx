import React, { useState } from 'react';
import {
  Users,
  Plus,
  Sparkles,
  ShieldCheck,
  Check,
  User,
  Heart,
  Volume2,
  AlertCircle,
  Upload,
} from 'lucide-react';
import { CharacterProfile } from '../../types/mathStory';
import { createCharacter } from '../../services/api';

interface CharacterLibraryProps {
  characters: CharacterProfile[];
  selectedCharId: string;
  onSelectCharacter: (charId: string) => void;
  onCharacterAdded: (newChar: CharacterProfile) => void;
}

export const CharacterLibrary: React.FC<CharacterLibraryProps> = ({
  characters,
  selectedCharId,
  onSelectCharacter,
  onCharacterAdded,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('Học sinh lớp 2A7');
  const [age, setAge] = useState(7);
  const [gender, setGender] = useState('Nữ');
  const [appearance, setAppearance] = useState('');
  const [outfit, setOutfit] = useState('');
  const [personality, setPersonality] = useState('');
  const [voiceStyle, setVoiceStyle] = useState('Giọng thiếu nhi trong trẻo, vui tươi');
  const [loading, setLoading] = useState(false);

  const handleSaveCharacter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);

    try {
      const newChar = await createCharacter({
        name,
        role,
        age: Number(age),
        gender,
        appearance: appearance || 'Đáng yêu, hoạt hình 3D phong cách Pixar',
        outfit: outfit || 'Đồng phục học sinh tiểu học dễ thương',
        personality: personality || 'Chăm ngoan, yêu thích khám phá môn Toán',
        voiceStyle,
      });
      onCharacterAdded(newChar);
      setShowAddModal(false);
      // Reset form
      setName('');
      setAppearance('');
      setOutfit('');
      setPersonality('');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-teal-100 text-teal-700">
              <Users className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 3: Thư Viện Nhân Vật & Character Profile
            </h2>
            <span className="text-xs bg-teal-100 text-teal-800 font-bold px-2.5 py-0.5 rounded-full">
              Hồ sơ đặc tính bất biến
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Lưu trữ thuộc tính diện mạo, trang phục và tính cách để tự động đưa vào prompt tạo ảnh & video, giúp tối đa hóa sự nhất quán giữa các cảnh.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-teal-600 to-sky-600 hover:from-teal-700 hover:to-sky-700 text-white font-extrabold text-xs shadow-md transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Tạo Nhân Vật Mới</span>
        </button>
      </div>

      {/* Consistency Disclaimer */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-900 leading-relaxed">
          <strong>Lưu ý công nghệ AI tạo sinh:</strong> Các mô hình hình ảnh AI hiện nay không cam kết bảo đảm tuyệt đối 100% sự đồng nhất từng chi tiết giữa các cảnh quay. Hệ thống của MATH STORY AI tự động nhúng các thẻ thuộc tính bất biến (Character Seed Attributes) vào mọi Prompt sinh ảnh để giữ tỷ lệ tương đồng nhân vật cao nhất có thể.
        </div>
      </div>

      {/* Character Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {characters.map((char) => {
          const isSelected = selectedCharId === char.id;

          return (
            <div
              key={char.id}
              className={`bg-white rounded-3xl p-5 border-2 transition-all shadow-sm flex flex-col justify-between ${
                isSelected
                  ? 'border-teal-500 ring-2 ring-teal-200'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="space-y-4">
                {/* Header card */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-400 to-teal-400 p-0.5 shadow-sm">
                      <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center text-2xl">
                        {char.gender === 'Robot' ? '🤖' : char.gender === 'Nữ' ? '👧' : '👦'}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                        <span>{char.name}</span>
                        {char.isPreset && (
                          <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">
                            Mẫu sẵn
                          </span>
                        )}
                      </h3>
                      <p className="text-[11px] text-teal-700 font-bold">{char.role} ({char.age} tuổi)</p>
                    </div>
                  </div>

                  {isSelected && (
                    <span className="bg-teal-500 text-white p-1 rounded-full text-xs">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>

                {/* Attributes */}
                <div className="space-y-2 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase block mb-0.5">
                      Ngoại hình & Tóc:
                    </span>
                    <p className="text-slate-700 font-medium">{char.appearance}</p>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase block mb-0.5">
                      Trang phục & Màu sắc chủ đạo:
                    </span>
                    <p className="text-slate-700 font-medium">{char.outfit}</p>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase block mb-0.5">
                      Tính cách & Giọng nói:
                    </span>
                    <p className="text-slate-700 font-medium mb-1">{char.personality}</p>
                    <p className="text-[11px] text-sky-700 italic flex items-center gap-1">
                      <Volume2 className="w-3 h-3" />
                      <span>{char.voiceStyle}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 mt-4 border-t border-slate-100">
                <button
                  onClick={() => onSelectCharacter(char.id)}
                  className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {isSelected ? 'Đang được chọn cho kịch bản' : 'Chọn nhân vật này'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Character Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-teal-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-800 text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-teal-600" />
                <span>Tạo Nhân Vật Hoạt Hình Mới</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCharacter} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tên nhân vật:</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="VD: Bé An, Chú Vịt Thông Thái..."
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Độ tuổi:</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Giới tính / Loại:</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium bg-white"
                  >
                    <option value="Nữ">Nữ</option>
                    <option value="Nam">Nam</option>
                    <option value="Robot">Robot</option>
                    <option value="Động vật">Động vật</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Vai trò:</label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="VD: Học sinh lớp 2A7"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Đặc điểm ngoại hình & Kiểu tóc (bất biến):
                </label>
                <textarea
                  value={appearance}
                  onChange={(e) => setAppearance(e.target.value)}
                  placeholder="VD: Mắt to tròn, tóc đuôi gà nơ đỏ, má phúng phính đáng yêu..."
                  rows={2}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Trang phục & Màu sắc chủ đạo:
                </label>
                <input
                  type="text"
                  value={outfit}
                  onChange={(e) => setOutfit(e.target.value)}
                  placeholder="VD: Áo thun vàng cam, quần yếm bò xanh, giày trắng..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Tính cách:</label>
                <input
                  type="text"
                  value={personality}
                  onChange={(e) => setPersonality(e.target.value)}
                  placeholder="VD: Năng động, thích đố vui, tính toán nhanh..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Phong cách giọng đọc:</label>
                <input
                  type="text"
                  value={voiceStyle}
                  onChange={(e) => setVoiceStyle(e.target.value)}
                  placeholder="VD: Giọng miền Bắc trong trẻo, hồn nhiên..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold shadow cursor-pointer"
                >
                  {loading ? 'Đang lưu...' : 'Lưu Hồ Sơ Nhân Vật'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
