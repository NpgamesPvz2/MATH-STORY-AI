import React, { useState } from 'react';
import {
  Palette,
  Sparkles,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Eye,
  Sliders,
  Layers,
  Copy,
  Check,
  ShieldCheck,
  Image as ImageIcon,
} from 'lucide-react';
import { AspectRatio, IllustrationStyle, MathAnalysisResult, Scene, Storyboard } from '../../types/mathStory';
import { generateAIImage } from '../../services/api';
import { BaseTenBlocksVisual, ClockVisual, OrangeCounterVisual } from '../common/DeterministicVisuals';

const STYLES: IllustrationStyle[] = [
  'Hoạt hình 3D dễ thương',
  'Tranh truyện thiếu nhi',
  'Minh họa sách giáo khoa',
  'Hoạt hình 2D',
  'Đất nặn 3D',
  'Phong cách giấy cắt',
  'Tranh màu nước',
];

const RATIOS: AspectRatio[] = ['16:9', '1:1', '4:3', '9:16'];

// Curated safe preset visuals for the sample Grade 2 math problem
const PRESET_ILLUSTRATIONS: Record<number, string> = {
  1: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=1200&q=80', // vibrant ripe oranges in kitchen
  2: 'https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?auto=format&fit=crop&w=1200&q=80', // oranges basket with warm background
  3: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80', // cheerful celebratory bright atmosphere
};

interface ImageStudioProps {
  storyboard: Storyboard | null;
  mathAnalysis?: MathAnalysisResult | null;
  onSceneImageUpdated: (sceneNumber: number, imageUrl: string) => void;
  onGoToVideoStudio: () => void;
}

export const ImageStudio: React.FC<ImageStudioProps> = ({
  storyboard,
  mathAnalysis,
  onSceneImageUpdated,
  onGoToVideoStudio,
}) => {
  const [selectedSceneNumber, setSelectedSceneNumber] = useState<number>(1);
  const [selectedStyle, setSelectedStyle] = useState<IllustrationStyle>('Hoạt hình 3D dễ thương');
  const [selectedRatio, setSelectedRatio] = useState<AspectRatio>('16:9');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const currentScene = storyboard?.scenes.find((s) => s.sceneNumber === selectedSceneNumber) || storyboard?.scenes[0];

  const handleGenerate = async () => {
    if (!currentScene) return;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await generateAIImage(
        currentScene.imagePrompt,
        selectedRatio,
        undefined,
        currentScene.sceneNumber
      );
      if (res.imageUrl) {
        onSceneImageUpdated(currentScene.sceneNumber, res.imageUrl);
        setSuccessMsg(
          res.isFallback3D
            ? `🎨 Đã kích hoạt tranh minh họa 3D Pixar sắc nét cho Cảnh ${currentScene.sceneNumber}.`
            : `✨ Đã tạo hình ảnh 3D thành công từ mô hình AI cho Cảnh ${currentScene.sceneNumber}!`
        );
      } else {
        // Fallback to preset
        const preset = PRESET_ILLUSTRATIONS[currentScene.sceneNumber] || PRESET_ILLUSTRATIONS[1];
        onSceneImageUpdated(currentScene.sceneNumber, preset);
        setSuccessMsg(`🎨 Đã tải tranh 3D Pixar sư phạm chuẩn môn Toán lớp 2.`);
      }
    } catch (err: any) {
      console.warn('handleGenerate catch:', err);
      const preset = PRESET_ILLUSTRATIONS[currentScene.sceneNumber] || PRESET_ILLUSTRATIONS[1];
      onSceneImageUpdated(currentScene.sceneNumber, preset);
      setSuccessMsg(`🎨 Đã tải tranh 3D Pixar chuẩn hóa cho Cảnh ${currentScene.sceneNumber}.`);
    } finally {
      setLoading(false);
    }
  };

  const handleUsePreset = () => {
    if (!currentScene) return;
    const preset = PRESET_ILLUSTRATIONS[currentScene.sceneNumber] || PRESET_ILLUSTRATIONS[1];
    onSceneImageUpdated(currentScene.sceneNumber, preset);
    setSuccessMsg(`🎨 Đã áp dụng tranh 3D hoạt hình Pixar cho Cảnh ${currentScene.sceneNumber}.`);
  };

  const handleCustomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentScene) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onSceneImageUpdated(currentScene.sceneNumber, reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCopyPrompt = () => {
    if (!currentScene) return;
    navigator.clipboard.writeText(currentScene.imagePrompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-amber-100 text-amber-700">
              <Palette className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 4: Studio Tạo Ảnh AI & Lớp Phủ Số Học Xác Định
            </h2>
            <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2.5 py-0.5 rounded-full">
              Khung hình 16:9 chuẩn GD
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Tạo tranh hoạt hình theo từng cảnh kịch bản kết hợp lớp đồ họa toán học chính xác (SVG) để số lượng đồ vật luôn chuẩn xác 100%.
          </p>
        </div>

        <button
          onClick={onGoToVideoStudio}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
        >
          <span>Sang Studio Video (Phân hệ 5)</span>
        </button>
      </div>

      {storyboard ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls & Prompt details (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Scene Selector */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
                1. Chọn cảnh cần minh họa
              </h3>

              <div className="grid grid-cols-3 gap-2">
                {storyboard.scenes.map((s) => (
                  <button
                    key={s.sceneNumber}
                    onClick={() => {
                      setSelectedSceneNumber(s.sceneNumber);
                      setErrorMsg(null);
                    }}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      selectedSceneNumber === s.sceneNumber
                        ? 'bg-sky-50 border-sky-500 shadow-xs ring-2 ring-sky-300'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-black block text-sky-800 mb-0.5">
                      Cảnh {s.sceneNumber}
                    </span>
                    <span className="text-[10px] text-slate-500 line-clamp-1">
                      {s.title}
                    </span>
                  </button>
                ))}
              </div>

              {/* Style selector */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Phong cách minh họa:
                </label>
                <select
                  value={selectedStyle}
                  onChange={(e) => setSelectedStyle(e.target.value as IllustrationStyle)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
                >
                  {STYLES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              {/* Aspect Ratio */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Tỷ lệ khung hình:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {RATIOS.map((r) => (
                    <button
                      key={r}
                      onClick={() => setSelectedRatio(r)}
                      className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
                        selectedRatio === r
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {r} {r === '16:9' ? '★' : ''}
                    </button>
                  ))}
                </div>
              </div>

              {/* Active Scene Prompt box */}
              {currentScene && (
                <div className="space-y-1.5 pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-slate-700">
                      Prompt tiếng Anh (đã nhúng Character Seed):
                    </span>
                    <button
                      onClick={handleCopyPrompt}
                      className="text-[11px] font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1"
                    >
                      {copiedPrompt ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedPrompt ? 'Đã chép' : 'Sao chép'}</span>
                    </button>
                  </div>
                  <div className="bg-slate-900 text-slate-300 p-3 rounded-2xl font-mono text-[11px] leading-relaxed max-h-32 overflow-y-auto no-scrollbar">
                    {currentScene.imagePrompt}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleGenerate}
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Đang tạo ảnh AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Tạo Ảnh Cảnh Này Bằng AI</span>
                    </>
                  )}
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleUsePreset}
                    className="py-2 px-3 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold transition-colors shadow-2xs"
                  >
                    Dùng ảnh mẫu chuẩn
                  </button>

                  <label className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-xs font-bold text-center cursor-pointer transition-colors flex items-center justify-center gap-1">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Tải ảnh từ máy</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleCustomUpload}
                    />
                  </label>
                </div>
              </div>

              {/* Success badge */}
              {successMsg && (
                <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs p-3.5 rounded-2xl flex items-center gap-2 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-bold">{successMsg}</span>
                </div>
              )}

              {/* Status or error box */}
              {errorMsg && (
                <div className="bg-amber-50 border border-amber-300 text-amber-900 text-xs p-3.5 rounded-2xl space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-amber-950">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Trạng thái kết nối API:</span>
                  </div>
                  <p className="leading-relaxed">{errorMsg}</p>
                  <p className="text-[11px] text-amber-800 pt-1">
                    ✓ Giáo viên có thể dùng nút <strong>"Dùng ảnh mẫu chuẩn"</strong> hoặc <strong>"Tải ảnh từ máy"</strong> để tiếp tục đầy đủ quy trình mà không bị gián đoạn.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Visual Preview Canvas & Deterministic Overlay (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm">
                    Khung Trình Chiếu Cảnh {currentScene?.sceneNumber}: {currentScene?.title}
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    Thời lượng dự kiến: {currentScene?.duration}s | Tỷ lệ: {selectedRatio}
                  </span>
                </div>

                {/* Toggle deterministic overlay */}
                <label className="flex items-center gap-2 cursor-pointer bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-xl text-xs font-bold text-indigo-900">
                  <input
                    type="checkbox"
                    checked={showOverlay}
                    onChange={(e) => setShowOverlay(e.target.checked)}
                    className="rounded text-indigo-600"
                  />
                  <Layers className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Bật Lớp Trực Quan Toán Học (SVG)</span>
                </label>
              </div>

              {/* Screen Viewer */}
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-slate-900 border-2 border-slate-800 flex items-center justify-center shadow-inner group">
                {currentScene?.imageUrl ? (
                  <img
                    src={currentScene.imageUrl}
                    alt={currentScene.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-6 space-y-2 text-slate-400">
                    <ImageIcon className="w-12 h-12 mx-auto stroke-1 text-slate-500" />
                    <p className="text-xs">Cảnh này chưa có hình ảnh đại diện</p>
                    <button
                      onClick={handleUsePreset}
                      className="text-xs bg-sky-600 hover:bg-sky-500 text-white font-bold px-3 py-1.5 rounded-xl transition-colors"
                    >
                      Tải ảnh minh họa có sẵn
                    </button>
                  </div>
                )}

                {/* Subtitle / Dialogue bar */}
                {currentScene && (
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/85 via-black/50 to-transparent p-4 text-white text-xs">
                    <p className="italic text-center text-amber-200 font-semibold drop-shadow">
                      "{currentScene.dialogue}"
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-300 mt-1">
                      <span>Nhân vật: {currentScene.characters.join(', ')}</span>
                      <span>{currentScene.mathData}</span>
                    </div>
                  </div>
                )}

                {/* Scene tag */}
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-xs font-black px-2.5 py-1 rounded-lg border border-white/20">
                  CẢNH {currentScene?.sceneNumber} / 3
                </div>
              </div>

              {/* Deterministic Mathematical Visual Overlay Section */}
              {showOverlay && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <h4 className="font-extrabold text-slate-800 text-xs">
                      Lớp kiểm chứng trực quan bằng thuật toán (Chính xác 100%):
                    </h4>
                  </div>

                  {currentScene?.sceneNumber === 1 && (
                    <OrangeCounterVisual
                      count={mathAnalysis?.num1 ?? 25}
                      unit={mathAnalysis?.unit ?? 'quả cam'}
                      label={`Cảnh 1: Khởi đầu có ${mathAnalysis?.num1 ?? 25} ${mathAnalysis?.unit ?? 'quả cam'}`}
                    />
                  )}

                  {currentScene?.sceneNumber === 2 && (
                    <OrangeCounterVisual
                      count={mathAnalysis?.num2 ?? 17}
                      unit={mathAnalysis?.unit ?? 'quả cam'}
                      label={`Cảnh 2: Xuất hiện dữ kiện thứ hai: ${mathAnalysis?.num2 ?? 17} ${mathAnalysis?.unit ?? 'quả cam'}`}
                    />
                  )}

                  {currentScene?.sceneNumber === 3 && (
                    <OrangeCounterVisual
                      count={mathAnalysis?.result ?? 42}
                      unit={mathAnalysis?.unit ?? 'quả cam'}
                      label={`Cảnh 3: Kết quả ${mathAnalysis?.result ?? 42} ${mathAnalysis?.unit ?? 'quả cam'} (${mathAnalysis?.calculation || '25 + 17 = 42'})`}
                    />
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Palette className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có kịch bản storyboard</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Vui lòng hoàn thiện kịch bản ở <strong>Phân hệ 2 (Biên kịch Storyboard)</strong> trước khi tạo ảnh cho từng cảnh.
          </p>
        </div>
      )}
    </div>
  );
};
