import React from 'react';
import {
  Sparkles,
  BookOpen,
  Film,
  Users,
  Palette,
  Mic,
  Gamepad2,
  CheckCircle2,
  BarChart3,
  Video,
  Layers,
  ArrowRight,
  ShieldCheck,
  School,
  Play,
  Award,
} from 'lucide-react';
import { ActiveTab } from '../common/Header';
import { ProjectLesson } from '../../types/mathStory';

interface HomeDashboardProps {
  onNavigate: (tab: ActiveTab) => void;
  sampleProject: ProjectLesson;
  onOpenSampleProject: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onNavigate,
  sampleProject,
  onOpenSampleProject,
}) => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Hero Banner with 3D Educational Aesthetics */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-sky-600 via-teal-600 to-amber-500 p-8 md:p-12 text-white shadow-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-10 w-80 h-80 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-black tracking-wide uppercase">
              Sáng Kiến Giáo Dục Ứng Dụng AI Năm 2026
            </span>
            <span className="bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full text-xs font-black">
              Lớp 2A7
            </span>
            <span className="bg-sky-900/60 px-2.5 py-0.5 rounded-full text-xs font-bold text-sky-100">
              TH Đặng Trần Côn
            </span>
          </div>

          <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-tight">
            MATH STORY AI
          </h1>
          <p className="text-lg md:text-xl font-extrabold text-amber-200">
            XƯỞNG SÁNG TẠO CÂU CHUYỆN TOÁN HỌC BẰNG TRÍ TUỆ NHÂN TẠO
          </p>

          <p className="text-sm md:text-base text-sky-100 italic leading-relaxed bg-black/20 p-3.5 rounded-2xl backdrop-blur-xs border border-white/10">
            "Một bài toán – Một câu chuyện – Một thử thách tư duy – Một hành trình tiến bộ."
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('analysis')}
              className="px-6 py-3.5 rounded-2xl bg-white hover:bg-sky-50 text-sky-800 font-black text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Tạo Câu Chuyện Toán Mới</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenSampleProject}
              className="px-6 py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Xem Demo: Bài Toán Những Quả Cam (25 + 17 = 42)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Featured Canonical Sample Lesson Card */}
      <div className="bg-amber-50/80 border-2 border-amber-300 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-3xl shadow-md shrink-0">
            🍊
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-amber-500 text-white font-black text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                DỰ ÁN MINH HỌA TIÊU BIỂU (DEMO)
              </span>
              <span className="text-xs text-amber-800 font-bold">Lớp 2A2</span>
            </div>
            <h3 className="text-lg font-black text-amber-950">
              Bài toán những quả cam (Phép cộng có nhớ: 25 + 17 = 42)
            </h3>
            <p className="text-xs text-slate-700 mt-1 max-w-2xl leading-relaxed">
              "Lan có 25 quả cam. Mẹ cho Lan thêm 17 quả cam. Hỏi Lan có tất cả bao nhiêu quả cam?"
              Đã tạo đủ 3 phân cảnh hoạt hình 3D, câu hỏi tương tác dừng tại giây thứ 15 và kiểm duyệt 10 tiêu chí.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenSampleProject}
          className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Vào Học Tương Tác Ngay</span>
        </button>
      </div>

      {/* 6 Large Action Cards Required by Section II */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-black text-slate-800">
            Các Thẻ Chức Năng Chính Của Ứng Dụng
          </h2>
          <span className="text-xs text-slate-500">Thiết kế chuẩn UX/UI cho giáo viên & học sinh lớp 2</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Card 1 */}
          <div
            onClick={() => onNavigate('analysis')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-sky-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                📐
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-sky-600 transition-colors">
                Tạo Câu Chuyện Mới
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Nhập đề toán, tải ảnh OCR, chạy bộ phân tích sư phạm AI và kiểm tra xác định bằng code toán học 100%.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-sky-600">
              <span>Phân hệ 1 & 2</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2 */}
          <div
            onClick={() => onNavigate('videos')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-purple-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                🎬
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-purple-600 transition-colors">
                Tạo Video Toán Học
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Xuất prompt sang Google Flow / VideoFX, tải clip đã dựng trở lại và ghép timeline 3 cảnh chuẩn 16:9.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-purple-600">
              <span>Phân hệ 5</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3 */}
          <div
            onClick={() => onNavigate('images')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                🎨
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-amber-600 transition-colors">
                Tạo Tranh Minh Họa & Lớp SVG
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Studio tạo ảnh hoạt hình 3D kết hợp lớp phủ số học xác định (rổ cam, khối chục, đồng hồ) không lo vẽ sai số.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-amber-600">
              <span>Phân hệ 4</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4 */}
          <div
            onClick={() => onNavigate('interactive')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                🎮
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-emerald-600 transition-colors">
                Học Toán Tương Tác (Trọng tâm)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Trình chiếu video tự động dừng tại cảnh 2, bé chọn phép tính hoặc kéo thả trực quan, nhận gợi ý nhẹ nhàng.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-600">
              <span>Phân hệ 7</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 5 */}
          <div
            onClick={() => onNavigate('library')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-teal-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                📚
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-teal-600 transition-colors">
                Thư Viện Học Liệu & Phiếu In
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Kho bài học lưu trữ đề bài, kịch bản, phiếu học tập in ấn (Worksheet) và đường link chia sẻ có phân quyền.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-teal-600">
              <span>Phân hệ 10</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 6 */}
          <div
            onClick={() => onNavigate('reports')}
            className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                📊
              </div>
              <h3 className="font-black text-slate-900 text-base group-hover:text-indigo-600 transition-colors">
                Báo Cáo & Đánh Giá Tiến Bộ
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Biểu đồ tỷ lệ chọn đúng phép tính, chẩn đoán 5 dạng lỗi sư phạm phổ biến và xuất báo cáo CSV/Excel.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-indigo-600">
              <span>Phân hệ 12</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>

      {/* Author & Solution Credentials Box */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
        <div className="space-y-1">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Tác giả giải pháp</span>
          <h4 className="text-base font-black text-amber-400">HOÀNG DIỆU HƯƠNG</h4>
          <p className="text-slate-300">Giáo viên chủ nhiệm lớp 2A2</p>
        </div>
        <div className="space-y-1">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Đơn vị công tác</span>
          <h4 className="text-base font-black text-white">TRƯỜNG TIỂU HỌC ĐẶNG TRẦN CÔN</h4>
          <p className="text-slate-300">Năm thực hiện: 2026</p>
        </div>
        <div className="space-y-1">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Mục tiêu giải pháp</span>
          <h4 className="text-base font-black text-emerald-400">Đổi Mới Dạy Toán Lớp 2</h4>
          <p className="text-slate-300">Chuyển hóa bài toán khô khan thành câu chuyện hoạt hình đa giác quan.</p>
        </div>
      </div>
    </div>
  );
};
