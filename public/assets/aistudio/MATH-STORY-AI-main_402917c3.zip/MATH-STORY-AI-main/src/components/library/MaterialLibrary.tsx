import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  Copy,
  Eye,
  Download,
  Share2,
  CheckCircle2,
  Calendar,
  User,
  School,
  Printer,
  Sparkles,
  Layers,
  ArrowRight,
  FileText,
} from 'lucide-react';
import { ProjectLesson } from '../../types/mathStory';

interface MaterialLibraryProps {
  projects: ProjectLesson[];
  activeProjectId: string;
  onSelectProject: (project: ProjectLesson) => void;
  onGoToInteractivePlayer: () => void;
}

export const MaterialLibrary: React.FC<MaterialLibraryProps> = ({
  projects,
  activeProjectId,
  onSelectProject,
  onGoToInteractivePlayer,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('all');
  const [showWorksheetModal, setShowWorksheetModal] = useState<ProjectLesson | null>(null);
  const [shareCopied, setShareCopied] = useState<string | null>(null);

  const filteredProjects = projects.filter((p) => {
    const matchSearch =
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.problemText.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchTopic = selectedTopic === 'all' || p.topic.includes(selectedTopic);
    return matchSearch && matchTopic;
  });

  const handleShare = (id: string) => {
    const shareUrl = `${window.location.origin}?lesson=${id}`;
    navigator.clipboard.writeText(shareUrl);
    setShareCopied(id);
    setTimeout(() => setShareCopied(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-sky-100 text-sky-700">
              <BookOpen className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 10: Thư Viện Học Liệu & Kho Dự Án Toán 2
            </h2>
            <span className="text-xs bg-sky-100 text-sky-800 font-bold px-2.5 py-0.5 rounded-full">
              Lưu trữ trọn gói kịch bản, video & phiếu bài tập
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Quản lý, tái sử dụng, chia sẻ liên trường và xuất phiếu học tập in ấn cho học sinh lớp 2 theo từng chủ đề.
          </p>
        </div>

        <button
          onClick={onGoToInteractivePlayer}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <span>Trải Nghiệm Học Liệu Tương Tác</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Search & Filters */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm kiếm theo tên bài, nội dung đề toán hoặc tác giả..."
            className="w-full text-xs pl-10 pr-4 py-2.5 rounded-2xl border border-slate-300 font-medium focus:ring-2 focus:ring-sky-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            className="w-full sm:w-56 text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
          >
            <option value="all">Tất cả chủ đề Toán 2</option>
            <option value="Phép cộng">Phép cộng có nhớ</option>
            <option value="Phép trừ">Phép trừ có nhớ</option>
            <option value="nhân">Bảng nhân 2 & 5</option>
            <option value="chia">Bảng chia 2 & 5</option>
            <option value="lời văn">Bài toán có lời văn</option>
          </select>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProjects.map((p) => {
          const isSelected = activeProjectId === p.id;

          return (
            <div
              key={p.id}
              className={`bg-white rounded-3xl p-5 border-2 transition-all shadow-sm flex flex-col justify-between ${
                isSelected
                  ? 'border-sky-500 ring-2 ring-sky-200'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="space-y-3.5">
                {/* Header tags */}
                <div className="flex items-center justify-between">
                  <span
                    className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                      p.isSample
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : 'bg-sky-100 text-sky-800'
                    }`}
                  >
                    {p.isSample ? 'MINH HỌA (DEMO SAMPLE)' : 'HỌC LIỆU LỚP 2A7'}
                  </span>

                  <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {p.moderationChecklist?.status.replace(/_/g, ' ') || 'ĐÃ DUYỆT'}
                  </span>
                </div>

                {/* Title & Topic */}
                <div>
                  <h3 className="font-black text-slate-900 text-sm">{p.title}</h3>
                  <span className="text-[11px] text-sky-700 font-bold block mt-0.5">
                    {p.topic}
                  </span>
                </div>

                {/* Problem snippet */}
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs text-slate-700 font-medium leading-relaxed line-clamp-3">
                  "{p.problemText}"
                </div>

                {/* Calculation verification tag */}
                <div className="flex items-center justify-between text-xs bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                  <span className="text-slate-600 font-bold">Phép tính:</span>
                  <span className="font-mono font-black text-amber-950">
                    {p.mathAnalysis?.calculation || '25 + 17 = 42'}
                  </span>
                </div>

                {/* Author & School metadata */}
                <div className="text-[11px] text-slate-500 space-y-1 pt-1 border-t border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3 h-3 text-slate-400" />
                    <span>Tác giả: <strong>{p.author}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <School className="w-3 h-3 text-slate-400" />
                    <span>{p.school} — Lớp {p.classId}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 mt-4 border-t border-slate-100 space-y-2">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => onSelectProject(p)}
                    className="py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold transition-all shadow-xs flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Mở bài này</span>
                  </button>

                  <button
                    onClick={() => setShowWorksheetModal(p)}
                    className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Phiếu in</span>
                  </button>
                </div>

                <button
                  onClick={() => handleShare(p.id)}
                  className="w-full py-1.5 rounded-xl text-[11px] font-bold text-slate-600 hover:bg-slate-100 flex items-center justify-center gap-1.5 transition-colors"
                >
                  {shareCopied === p.id ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Đã sao chép link chia sẻ bài học!</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Chia sẻ đường dẫn có phân quyền</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Printable Worksheet Modal */}
      {showWorksheetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-sky-100 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-sky-600" />
                <h3 className="font-extrabold text-slate-900 text-base">
                  Phiếu Học Tập Tương Tác & Bài Tập In (Worksheet)
                </h3>
              </div>
              <button
                onClick={() => setShowWorksheetModal(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Printable Paper Preview */}
            <div className="bg-white p-6 border-2 border-slate-300 rounded-2xl shadow-inner space-y-4 text-slate-900 font-serif">
              <div className="text-center space-y-1 border-b-2 border-slate-800 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  TRƯỜNG TIỂU HỌC ĐẶNG TRẦN CÔN — LỚP 2A7
                </h4>
                <h3 className="text-base font-black uppercase">
                  PHIẾU BÀI TẬP TOÁN: {showWorksheetModal.title}
                </h3>
                <p className="text-xs italic">
                  Chủ đề: {showWorksheetModal.topic} | Năm học 2025 - 2026
                </p>
                <div className="flex justify-between text-xs pt-2 font-sans">
                  <span>Họ và tên học sinh: .................................................</span>
                  <span>Điểm: ...........</span>
                </div>
              </div>

              <div className="space-y-3 font-sans text-xs">
                <div>
                  <strong>Bài toán:</strong> {showWorksheetModal.problemText}
                </div>

                <div className="border border-slate-300 p-4 rounded-xl min-h-[120px] space-y-2">
                  <div className="text-center font-bold">BÀI GIẢI</div>
                  <div className="text-slate-400 italic">
                    (Học sinh viết câu lời giải, phép tính và đáp số vào các dòng bên dưới)
                  </div>
                  <div className="border-b border-dotted border-slate-300 pt-5"></div>
                  <div className="border-b border-dotted border-slate-300 pt-5"></div>
                  <div className="border-b border-dotted border-slate-300 pt-5"></div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowWorksheetModal(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-black shadow flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>In Phiếu Bài Tập</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
