import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Award,
  ArrowRight,
  UserCheck,
  Calendar,
  Layers,
} from 'lucide-react';
import { ModerationChecklist, ModerationStatus, ProjectLesson } from '../../types/mathStory';

interface TeacherModerationProps {
  project: ProjectLesson;
  onUpdateChecklist: (checklist: ModerationChecklist) => void;
  onGoToLibrary: () => void;
}

export const TeacherModeration: React.FC<TeacherModerationProps> = ({
  project,
  onUpdateChecklist,
  onGoToLibrary,
}) => {
  const [checklist, setChecklist] = useState<ModerationChecklist>(
    project.moderationChecklist || {
      curriculumCompliant: true,
      dataAccurate: true,
      calculationVerified: true,
      dialogueAppropriate: true,
      imageSafe: true,
      characterConsistent: true,
      audioClear: true,
      questionEngaging: true,
      pedagogicalFeedback: true,
      trialTested: true,
      status: 'ĐÃ_XUẤT_BẢN',
      approvedBy: 'Cô giáo Hoàng Diệu Hương',
      approvedDate: '2026-03-20',
    }
  );

  const [teacherName, setTeacherName] = useState(checklist.approvedBy || 'Cô giáo Hoàng Diệu Hương');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleToggle = (key: keyof Omit<ModerationChecklist, 'status' | 'approvedBy' | 'approvedDate'>) => {
    const updated = {
      ...checklist,
      [key]: !checklist[key],
    };
    setChecklist(updated);
    onUpdateChecklist(updated);
  };

  const handleStatusChange = (status: ModerationStatus) => {
    const updated: ModerationChecklist = {
      ...checklist,
      status,
      approvedBy: teacherName,
      approvedDate: new Date().toISOString().split('T')[0],
    };
    setChecklist(updated);
    onUpdateChecklist(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const criteriaList: {
    key: keyof Omit<ModerationChecklist, 'status' | 'approvedBy' | 'approvedDate'>;
    title: string;
    desc: string;
  }[] = [
    {
      key: 'curriculumCompliant',
      title: '1. Nội dung bám sát SGK Toán 2 (GDPT 2018)',
      desc: 'Phù hợp mục tiêu cần đạt của khối lớp 2, đúng mạch kiến thức số và phép tính.',
    },
    {
      key: 'dataAccurate',
      title: '2. Dữ kiện bài toán chính xác',
      desc: 'Các con số và tình huống thực tế, không gây hiểu lầm cho học sinh.',
    },
    {
      key: 'calculationVerified',
      title: '3. Phép tính được kiểm tra xác định',
      desc: 'Được thẩm định bởi hàm toán học độc lập, kết quả 25 + 17 = 42 chính xác tuyệt đối.',
    },
    {
      key: 'dialogueAppropriate',
      title: '4. Lời thoại trong sáng, phù hợp lứa tuổi 7-8',
      desc: 'Ngôn từ chuẩn tiếng Việt, gần gũi, khích lệ tinh thần học tập của trẻ.',
    },
    {
      key: 'imageSafe',
      title: '5. Hình ảnh an toàn, thẩm mỹ sư phạm cao',
      desc: 'Hoạt hình 3D tươi sáng, không chứa yếu tố bạo lực hay chi tiết phản cảm.',
    },
    {
      key: 'characterConsistent',
      title: '6. Nhân vật giữ vững tạo hình nhất quán',
      desc: 'Áp dụng Character Seed Profile cho Bé Lan xuyên suốt các cảnh.',
    },
    {
      key: 'audioClear',
      title: '7. Âm thanh rõ ràng, tốc độ vừa phải',
      desc: 'Âm lượng cân đối giữa giọng đọc và nhạc nền, không bị rè méo.',
    },
    {
      key: 'questionEngaging',
      title: '8. Câu hỏi tương tác kích thích tư duy',
      desc: 'Đặt ở cảnh 2 đúng thời điểm, không lộ đáp số trước khi học sinh trả lời.',
    },
    {
      key: 'pedagogicalFeedback',
      title: '9. Phản hồi sư phạm khích lệ',
      desc: 'Khi sai có gợi ý từng bước, không chê bai hay gây áp lực tâm lý cho học sinh.',
    },
    {
      key: 'trialTested',
      title: '10. Đã chạy thử nghiệm nghiệm thu hoàn chỉnh',
      desc: 'Giáo viên đã trực tiếp trải nghiệm toàn bộ video và kiểm tra quy trình hoạt động.',
    },
  ];

  const allPassed = criteriaList.every((c) => checklist[c.key]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-emerald-100 text-emerald-700">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 9: Bảng Giáo Viên Kiểm Duyệt Sư Phạm
            </h2>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full">
              10 Tiêu chuẩn kiểm định
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Đảm bảo tính chuẩn mực giáo dục trước khi xuất bản học liệu cho học sinh lớp 2A7 trải nghiệm.
          </p>
        </div>

        <button
          onClick={onGoToLibrary}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
        >
          <span>Sang Thư Viện Học Liệu (Phân hệ 10)</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Workflow Status Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
          Quy trình trạng thái học liệu
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          {(['BẢN_NHÁP', 'ĐANG_CHỈNH_SỬA', 'CHỜ_DUYỆT', 'ĐÃ_DUYỆT', 'ĐÃ_XUẤT_BẢN'] as ModerationStatus[]).map(
            (st) => {
              const isActive = checklist.status === st;
              return (
                <button
                  key={st}
                  onClick={() => handleStatusChange(st)}
                  className={`p-3 rounded-2xl border font-bold text-center transition-all cursor-pointer ${
                    isActive
                      ? st === 'ĐÃ_XUẤT_BẢN'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm ring-2 ring-emerald-300'
                        : 'bg-sky-600 text-white border-sky-600 shadow-sm ring-2 ring-sky-300'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="block text-[10px] opacity-80 uppercase">Trạng thái</span>
                  <span className="font-extrabold">{st.replace(/_/g, ' ')}</span>
                </button>
              );
            }
          )}
        </div>

        {saveSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Đã cập nhật trạng thái kiểm duyệt thành công!</span>
          </div>
        )}
      </div>

      {/* 10 Criteria Checklist */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-600" />
            <span>10 Tiêu Chí Nghiệm Thu Sư Phạm (Bắt buộc hoàn thành)</span>
          </h3>
          <span
            className={`text-xs font-bold px-3 py-1 rounded-full ${
              allPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
            }`}
          >
            {allPassed ? '✓ Đạt 10/10 tiêu chí' : 'Chưa hoàn thành đủ 10 tiêu chí'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {criteriaList.map((item) => {
            const isChecked = checklist[item.key];
            return (
              <div
                key={item.key}
                onClick={() => handleToggle(item.key)}
                className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3 ${
                  isChecked
                    ? 'border-emerald-400 bg-emerald-50/50'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-lg mt-0.5 flex items-center justify-center font-bold text-xs ${
                    isChecked
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'border-2 border-slate-300 bg-white'
                  }`}
                >
                  {isChecked ? '✓' : ''}
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900">{item.title}</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Teacher Signature Box */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mt-4">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Giáo viên phê duyệt:</label>
            <input
              type="text"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-800"
            />
          </div>
          <div>
            <label className="font-bold text-slate-700 block mb-1">Ngày phê duyệt xuất bản:</label>
            <input
              type="date"
              value={checklist.approvedDate || '2026-03-20'}
              readOnly
              className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-medium text-slate-700"
            />
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={() => handleStatusChange('ĐÃ_XUẤT_BẢN')}
            disabled={!allPassed}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40"
          >
            <Award className="w-4 h-4" />
            <span>Phê Duyệt & Xuất Bản Lên Hệ Thống Lớp 2A7</span>
          </button>
        </div>
      </div>
    </div>
  );
};
