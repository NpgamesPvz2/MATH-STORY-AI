import React, { useState, useRef } from 'react';
import {
  Mic,
  Square,
  Play,
  Pause,
  Upload,
  Volume2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Music,
  Trash2,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Scene, Storyboard } from '../../types/mathStory';
import { requestTTS } from '../../services/api';

interface AudioStudioProps {
  storyboard: Storyboard | null;
  onSceneAudioUpdated: (sceneNumber: number, audioUrl: string) => void;
  onGoToInteractivePlayer: () => void;
}

export const AudioStudio: React.FC<AudioStudioProps> = ({
  storyboard,
  onSceneAudioUpdated,
  onGoToInteractivePlayer,
}) => {
  const [selectedSceneNumber, setSelectedSceneNumber] = useState<number>(1);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioSpeed, setAudioSpeed] = useState<number>(1.0);
  const [ttsLoading, setTtsLoading] = useState(false);
  const [ttsStatus, setTtsStatus] = useState<string | null>(null);
  const [bgMusic, setBgMusic] = useState('tap-dem');
  const [bgVolume, setBgVolume] = useState(30);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const currentScene = storyboard?.scenes.find((s) => s.sceneNumber === selectedSceneNumber) || storyboard?.scenes[0];

  // Start real browser recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        if (currentScene) {
          onSceneAudioUpdated(currentScene.sceneNumber, audioUrl);
        }
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      alert('Không thể mở micro: ' + err.message + '. Vui lòng cấp quyền micro trên trình duyệt.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentScene) return;
    const url = URL.createObjectURL(file);
    onSceneAudioUpdated(currentScene.sceneNumber, url);
  };

  const handleRequestAI_TTS = async () => {
    if (!currentScene) return;
    setTtsLoading(true);
    setTtsStatus(null);
    try {
      const res = await requestTTS(currentScene.dialogue, 'Kore');
      if (res.success && res.audioUrl) {
        onSceneAudioUpdated(currentScene.sceneNumber, res.audioUrl);
        setTtsStatus('Tạo giọng đọc AI thành công!');
      } else {
        setTtsStatus(res.recommendation || 'Dịch vụ AI TTS chưa kết nối. Khuyến khích cô giáo ghi âm giọng trực tiếp trên micro.');
      }
    } catch (err: any) {
      setTtsStatus(err.message || 'Lỗi khi gọi dịch vụ âm thanh');
    } finally {
      setTtsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-pink-100 text-pink-700">
              <Mic className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 6: Giọng Đọc Sư Phạm & Thu Âm Lời Thoại
            </h2>
            <span className="text-xs bg-pink-100 text-pink-800 font-bold px-2.5 py-0.5 rounded-full">
              Hỗ trợ Micro trình duyệt thật
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Giáo viên có thể tự thu âm bằng giọng đọc của mình hoặc tạo giọng đọc tự động, kết hợp nhạc nền nhẹ nhàng phù hợp lứa tuổi 7-8.
          </p>
        </div>

        <button
          onClick={onGoToInteractivePlayer}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Sang Bài Học Tương Tác</span>
        </button>
      </div>

      {storyboard ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Scene Selector & Dialogue (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
                1. Chọn cảnh để thu âm lời thoại
              </h3>

              <div className="space-y-2">
                {storyboard.scenes.map((s) => {
                  const isSelected = selectedSceneNumber === s.sceneNumber;
                  const hasAudio = Boolean(s.audioUrl);

                  return (
                    <div
                      key={s.sceneNumber}
                      onClick={() => setSelectedSceneNumber(s.sceneNumber)}
                      className={`p-3 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-pink-500 bg-pink-50/70 shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-800 font-black text-xs flex items-center justify-center">
                          {s.sceneNumber}
                        </span>
                        <div>
                          <h4 className="font-extrabold text-xs text-slate-900">{s.title}</h4>
                          <span className="text-[10px] text-slate-500 line-clamp-1">
                            "{s.dialogue}"
                          </span>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          hasAudio
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {hasAudio ? 'Đã có audio' : 'Chưa có'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Dialogue Box */}
              {currentScene && (
                <div className="bg-sky-50 border border-sky-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-900">
                      Lời thoại Cảnh {currentScene.sceneNumber}:
                    </span>
                    <span className="text-[11px] text-sky-700 font-semibold">
                      Nhân vật: {currentScene.characters.join(', ')}
                    </span>
                  </div>
                  <p className="text-sm font-black text-slate-800 italic bg-white p-3 rounded-xl border border-sky-100">
                    "{currentScene.dialogue}"
                  </p>
                  <p className="text-[11px] text-slate-500">
                    * Lưu ý sư phạm: Lời thoại ngắn gọn, tốc độ đọc 0.8x - 1.0x giúp trẻ lớp 2 nghe rõ và tiếp thu tốt.
                  </p>
                </div>
              )}

              {/* Background music settings */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Music className="w-4 h-4 text-pink-600" />
                    <span>Nhạc nền thiếu nhi nhẹ nhàng:</span>
                  </span>
                  <span className="text-[11px] font-bold text-slate-500">{bgVolume}% âm lượng</span>
                </div>

                <select
                  value={bgMusic}
                  onChange={(e) => setBgMusic(e.target.value)}
                  className="w-full text-xs p-2 rounded-xl border border-slate-300 bg-white font-medium"
                >
                  <option value="tap-dem">Giai điệu vui vẻ: Tập đếm cùng bạn bè</option>
                  <option value="vuon-truong">Giai điệu êm dịu: Vườn trường tuổi thơ</option>
                  <option value="kham-pha">Giai điệu rộn ràng: Khám phá kỳ thú</option>
                </select>

                <input
                  type="range"
                  min="0"
                  max="100"
                  value={bgVolume}
                  onChange={(e) => setBgVolume(Number(e.target.value))}
                  className="w-full accent-pink-600 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Audio Recording / TTS / Player (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
              <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-pink-600" />
                <span>2. Thu âm trực tiếp hoặc Tải file âm thanh</span>
              </h3>

              {/* Recorder Box */}
              <div className="bg-gradient-to-tr from-pink-50 via-rose-50 to-amber-50 rounded-2xl p-6 border-2 border-pink-200 text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-white shadow-md flex items-center justify-center text-pink-600">
                  <Mic className={`w-8 h-8 ${isRecording ? 'animate-pulse text-red-600' : ''}`} />
                </div>

                {isRecording ? (
                  <div className="space-y-1">
                    <span className="inline-block px-3 py-1 bg-red-100 text-red-700 font-extrabold text-xs rounded-full animate-bounce">
                      Đang thu âm: {recordingDuration} giây...
                    </span>
                    <p className="text-xs text-slate-600">
                      Cô giáo đọc rõ lời thoại: <em>"{currentScene?.dialogue}"</em>
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-600 font-medium">
                    Nhấn nút bên dưới để ghi âm trực tiếp bằng micro máy tính hoặc điện thoại
                  </p>
                )}

                {/* Recorder Control Button */}
                <div className="flex items-center justify-center gap-3">
                  {!isRecording ? (
                    <button
                      onClick={startRecording}
                      className="px-6 py-2.5 rounded-2xl bg-pink-600 hover:bg-pink-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <Mic className="w-4 h-4" />
                      <span>Bắt Đầu Ghi Âm Giọng Đọc</span>
                    </button>
                  ) : (
                    <button
                      onClick={stopRecording}
                      className="px-6 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <Square className="w-4 h-4 fill-current" />
                      <span>Dừng & Lưu Lời Thoại Cảnh Này</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Alternative 1: Upload file */}
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
                <div>
                  <h4 className="font-extrabold text-slate-800">Tải file âm thanh đã thu sẵn (.mp3, .wav):</h4>
                  <p className="text-[11px] text-slate-500">Dành cho trường hợp giáo viên đã chuẩn bị file audio</p>
                </div>
                <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer shadow-2xs">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Chọn file từ máy</span>
                  <input
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>

              {/* Alternative 2: AI Speech TTS */}
              <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-extrabold text-purple-900 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>Thử nghiệm Tạo Giọng Nói Bằng AI (Gemini TTS):</span>
                    </h4>
                    <p className="text-[11px] text-purple-700">Tự động đọc lời thoại bằng giọng cô giáo chuẩn</p>
                  </div>

                  <button
                    onClick={handleRequestAI_TTS}
                    disabled={ttsLoading}
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold transition-all shadow-2xs disabled:opacity-50 cursor-pointer"
                  >
                    {ttsLoading ? 'Đang đọc...' : 'Tạo giọng đọc AI'}
                  </button>
                </div>

                {ttsStatus && (
                  <p className="text-[11px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200">
                    {ttsStatus}
                  </p>
                )}
              </div>

              {/* Playback preview for current scene if available */}
              {currentScene?.audioUrl && (
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Đã có file ghi âm cho Cảnh {currentScene.sceneNumber}:</span>
                    </span>
                    <button
                      onClick={() => onSceneAudioUpdated(currentScene.sceneNumber, '')}
                      className="text-red-600 hover:text-red-800 text-[11px] flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Xóa thu lại</span>
                    </button>
                  </div>
                  <audio
                    src={currentScene.audioUrl}
                    controls
                    className="w-full h-10 rounded-lg accent-emerald-600"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Mic className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có kịch bản lời thoại</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Vui lòng hoàn thành kịch bản ở Phân hệ 2 để có lời thoại thu âm.
          </p>
        </div>
      )}
    </div>
  );
};
