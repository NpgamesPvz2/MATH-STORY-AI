import React, { useState } from 'react';
import {
  Video,
  Film,
  Play,
  Upload,
  Download,
  Copy,
  Check,
  ExternalLink,
  Layers,
  ArrowRight,
  AlertTriangle,
  Clock,
  Sparkles,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import { MathAnalysisResult, Scene, Storyboard } from '../../types/mathStory';
import { CartoonAnimatedVideo } from '../interactive/CartoonAnimatedVideo';

interface VideoStudioProps {
  storyboard: Storyboard | null;
  mathAnalysis?: MathAnalysisResult | null;
  onSceneVideoUpdated: (sceneNumber: number, videoUrl: string) => void;
  onOpenFlowGuideWithPrompt: (prompt: string, sceneTitle: string) => void;
  onGoToAudioStudio: () => void;
  onGoToInteractivePlayer: () => void;
}

export const VideoStudio: React.FC<VideoStudioProps> = ({
  storyboard,
  mathAnalysis,
  onSceneVideoUpdated,
  onOpenFlowGuideWithPrompt,
  onGoToAudioStudio,
  onGoToInteractivePlayer,
}) => {
  const [selectedSceneNumber, setSelectedSceneNumber] = useState<number>(1);
  const [copiedPromptId, setCopiedPromptId] = useState<string | null>(null);
  const [activePlaybackScene, setActivePlaybackScene] = useState<number>(1);
  const [isPlayingSequence, setIsPlayingSequence] = useState<boolean>(false);

  const currentScene = storyboard?.scenes.find((s) => s.sceneNumber === selectedSceneNumber) || storyboard?.scenes[0];

  const handleCopyPrompt = (prompt: string, id: string) => {
    navigator.clipboard.writeText(prompt);
    setCopiedPromptId(id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentScene) return;

    // Load uploaded MP4 / WebM into browser blob url
    const objectUrl = URL.createObjectURL(file);
    onSceneVideoUpdated(currentScene.sceneNumber, objectUrl);
  };

  const handlePlaySequence = () => {
    setIsPlayingSequence(true);
    setActivePlaybackScene(1);
    // Cycle through scene 1 -> 2 -> 3
    setTimeout(() => setActivePlaybackScene(2), 3500);
    setTimeout(() => setActivePlaybackScene(3), 7000);
    setTimeout(() => setIsPlayingSequence(false), 10500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-purple-100 text-purple-700">
              <Video className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 5: Studio Video AI & Quy Trình Google Flow
            </h2>
            <span className="text-xs bg-purple-100 text-purple-800 font-bold px-2.5 py-0.5 rounded-full">
              Khung hình 16:9 | Trình tự 3 cảnh
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Hỗ trợ xuất prompt chuẩn hóa sang Google Flow / VideoFX, tải clip đã dựng trở lại và ghép trình chiếu theo thứ tự kịch bản.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onGoToAudioStudio}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors"
          >
            Sang Thu Âm & Lời Thoại
          </button>
          <button
            onClick={onGoToInteractivePlayer}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Chạy Thử Nghiệm Tương Tác</span>
          </button>
        </div>
      </div>

      {/* Google Flow Standard Workflow Notice */}
      <div className="bg-sky-50 border-2 border-sky-200 rounded-3xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-sky-950 text-sm flex items-center gap-2">
            <Film className="w-4 h-4 text-sky-600" />
            <span>Quy trình sáng tạo Video với Google Flow (Khuyến nghị chuẩn sư phạm 2026)</span>
          </h3>
          <span className="text-xs font-bold bg-white text-sky-800 px-3 py-1 rounded-full border border-sky-200">
            Minh bạch API & Bản quyền
          </span>
        </div>
        <p className="text-xs text-sky-900 leading-relaxed">
          Google Flow / VideoFX tạo ra những đoạn phim hoạt hình chất lượng điện ảnh nhưng cần thao tác người dùng. MATH STORY AI hỗ trợ trọn vẹn 4 bước: <strong>1. Chép Prompt → 2. Tải ảnh bắt đầu → 3. Render tại Flow → 4. Nạp clip MP4 về đây</strong> để hệ thống tự động gắn câu hỏi tương tác dừng video.
        </p>
      </div>

      {storyboard ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Scene Selector & Flow Export Actions (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
                1. Chọn cảnh để kết nối video
              </h3>

              <div className="space-y-2">
                {storyboard.scenes.map((s) => {
                  const isSelected = selectedSceneNumber === s.sceneNumber;
                  const hasVideo = Boolean(s.videoUrl);

                  return (
                    <div
                      key={s.sceneNumber}
                      onClick={() => setSelectedSceneNumber(s.sceneNumber)}
                      className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-purple-500 bg-purple-50/70 shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs ${
                            hasVideo
                              ? 'bg-emerald-500 text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {hasVideo ? '✓' : s.sceneNumber}
                        </div>
                        <div>
                          <h4 className="font-extrabold text-xs text-slate-900">{s.title}</h4>
                          <span className="text-[10px] text-slate-500">
                            {s.duration} giây {s.interactiveQuestion ? '• (Có câu hỏi dừng)' : ''}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            hasVideo
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {hasVideo ? 'Đã có clip' : 'Chờ clip'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Active Scene Motion Prompt */}
              {currentScene && (
                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-800">
                      Motion Prompt (Google Flow):
                    </span>
                    <button
                      onClick={() =>
                        handleCopyPrompt(currentScene.motionPrompt, `vp-${currentScene.sceneNumber}`)
                      }
                      className="text-xs font-bold text-purple-600 hover:text-purple-800 flex items-center gap-1"
                    >
                      {copiedPromptId === `vp-${currentScene.sceneNumber}` ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Đã chép</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Chép prompt</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="bg-slate-900 text-slate-200 p-3 rounded-2xl font-mono text-xs leading-relaxed max-h-24 overflow-y-auto no-scrollbar">
                    {currentScene.motionPrompt}
                  </div>

                  {/* Actions for current scene */}
                  <div className="space-y-2 pt-1">
                    <button
                      onClick={() =>
                        onOpenFlowGuideWithPrompt(
                          currentScene.motionPrompt,
                          currentScene.title
                        )
                      }
                      className="w-full py-2.5 px-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Film className="w-3.5 h-3.5" />
                      <span>Mở Trợ Lý Xuất Prompt Google Flow</span>
                    </button>

                    <label className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 font-extrabold text-xs text-center cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-2xs">
                      <Upload className="w-4 h-4 text-slate-600" />
                      <span>Tải Clip MP4/WebM Của Cảnh Này Lên</span>
                      <input
                        type="file"
                        accept="video/mp4,video/webm"
                        className="hidden"
                        onChange={handleVideoUpload}
                      />
                    </label>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Timeline Sequencer Preview (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                    <Layers className="w-4 h-4 text-purple-600" />
                    <span>🎬 Trình Dựng Video Demo 3D (Pixar Animation Engine)</span>
                    <span className="bg-purple-100 text-purple-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                      100% 3D
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Trình chiếu thử nghiệm 3 cảnh 3D nối tiếp mượt mà, không giật lag
                  </p>
                </div>

                <button
                  onClick={handlePlaySequence}
                  disabled={isPlayingSequence}
                  className="flex items-center gap-1.5 text-xs font-extrabold text-white bg-gradient-to-r from-sky-600 to-purple-600 hover:from-sky-700 hover:to-purple-700 px-4 py-2 rounded-xl shadow cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isPlayingSequence ? 'Đang chạy trình tự 3D...' : 'Chạy Toàn Bộ Kịch Bản 3D'}</span>
                </button>
              </div>

              {/* Main Preview Player with 3D Animated Cartoon Engine */}
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-slate-900 border-2 border-slate-800 flex items-center justify-center shadow-lg">
                {(() => {
                  const activeScene =
                    storyboard.scenes.find((s) => s.sceneNumber === activePlaybackScene) ||
                    currentScene;

                  if (activeScene) {
                    return (
                      <CartoonAnimatedVideo
                        sceneNumber={activeScene.sceneNumber}
                        isPlaying={isPlayingSequence}
                        dialogue={activeScene.dialogue}
                        mathData={activeScene.mathData}
                        num1={mathAnalysis?.num1}
                        num2={mathAnalysis?.num2}
                        result={mathAnalysis?.result ?? undefined}
                        operation={mathAnalysis?.operation}
                        unit={mathAnalysis?.unit}
                        characterName={activeScene.characters?.[0] || 'Bé Lan'}
                      />
                    );
                  }

                  return (
                    <div className="text-center p-6 text-slate-400 space-y-2">
                      <Film className="w-12 h-12 mx-auto stroke-1" />
                      <p className="text-xs">Đang tải cảnh...</p>
                    </div>
                  );
                })()}
              </div>

              {/* Timeline scrub track */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span>Trục thời gian phân cảnh (45 giây)</span>
                  <span className="text-[11px] text-purple-700 font-extrabold">
                    Điểm dừng câu hỏi: Cảnh 2 (~ giây 15-30)
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {storyboard.scenes.map((s) => (
                    <div
                      key={s.sceneNumber}
                      onClick={() => setActivePlaybackScene(s.sceneNumber)}
                      className={`p-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                        activePlaybackScene === s.sceneNumber
                          ? 'bg-purple-100 border-purple-500 font-bold text-purple-900 shadow-xs'
                          : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-700 text-xs'
                      }`}
                    >
                      <span className="text-[11px] font-black block">Cảnh {s.sceneNumber}</span>
                      <span className="text-[10px] text-slate-500">{s.duration}s</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Video className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có dữ liệu kịch bản</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Vui lòng hoàn thành kịch bản ở Phân hệ 2 để xuất prompt và ghép nối video.
          </p>
        </div>
      )}
    </div>
  );
};
