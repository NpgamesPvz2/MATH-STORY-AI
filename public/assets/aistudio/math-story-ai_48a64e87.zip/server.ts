import http from 'http';
import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT: number = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper: check if Gemini API key exists
const hasApiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');

let aiClient: GoogleGenAI | null = null;
if (hasApiKey) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Deterministic Math Solver for Grade 2 Elementary Math (GDPT 2018)
function solveGrade2MathDeterministic(problemText: string) {
  let text = problemText;
  // Convert common Vietnamese word numbers
  text = text.replace(/một chục/gi, '10').replace(/1 chục/gi, '10').replace(/hai chục/gi, '20').replace(/2 chục/gi, '20');

  // Extract numbers
  const numbers = (text.match(/\d+/g) || []).map(Number);
  const lower = text.toLowerCase();

  // Unit detector
  let unit = 'đơn vị';
  if (lower.includes('quả cam') || lower.includes('cam')) unit = 'quả cam';
  else if (lower.includes('quả trứng') || lower.includes('trứng gà') || lower.includes('trứng')) unit = 'quả trứng';
  else if (lower.includes('con gà') || lower.includes('gà mái') || lower.includes('gà trống') || lower.includes('gà')) unit = 'con gà';
  else if (lower.includes('cây bạch đàn') || lower.includes('cây')) unit = 'cây';
  else if (lower.includes('bông hoa') || lower.includes('hoa')) unit = 'bông hoa';
  else if (lower.includes('viên bi') || lower.includes('bi')) unit = 'viên bi';
  else if (lower.includes('quả táo') || lower.includes('táo')) unit = 'quả táo';
  else if (lower.includes('học sinh') || lower.includes('bạn')) unit = 'học sinh';
  else if (lower.includes('quyển sách') || lower.includes('quyển vở') || lower.includes('vở') || lower.includes('sách')) unit = 'quyển vở';
  else if (lower.includes('cm') || lower.includes('xăng-ti-mét')) unit = 'cm';
  else if (lower.includes('dm') || lower.includes('đề-xi-mét')) unit = 'dm';
  else if (lower.includes('m') || lower.includes('mét')) unit = 'm';
  else if (lower.includes('kg') || lower.includes('ki-lô-gam')) unit = 'kg';
  else if (lower.includes('lít') || lower.includes('l')) unit = 'lít';
  else if (lower.includes('đồng')) unit = 'đồng';

  // Character detector
  const charactersInProblem: string[] = [];
  const knownKeywords = [
    { pattern: /\b(lan|bé lan)\b/i, name: 'Bé Lan' },
    { pattern: /\b(mẹ|mẹ lan)\b/i, name: 'Mẹ' },
    { pattern: /\b(bác an|ông an)\b/i, name: 'Bác An' },
    { pattern: /\b(nam|bạn nam|bé nam)\b/i, name: 'Bạn Nam' },
    { pattern: /\b(minh|bạn minh|bé minh)\b/i, name: 'Bé Minh' },
    { pattern: /\b(bà|bà ngoại|bà nội)\b/i, name: 'Bà' },
    { pattern: /\b(bố|ba)\b/i, name: 'Bố' },
    { pattern: /\b(cô giáo|cô hương)\b/i, name: 'Cô giáo Hương' },
    { pattern: /\b(mai|bạn mai)\b/i, name: 'Bạn Mai' },
    { pattern: /\b(hải|bạn hải)\b/i, name: 'Bạn Hải' },
    { pattern: /\b(tuấn|bạn tuấn)\b/i, name: 'Bạn Tuấn' },
    { pattern: /\b(linh|bạn linh)\b/i, name: 'Bạn Linh' },
    { pattern: /\b(hoa|bạn hoa)\b/i, name: 'Bạn Hoa' },
    { pattern: /\b(robot|rô-bốt|tô-bốt)\b/i, name: 'Toán Tô-bốt (AI Robot)' },
  ];

  for (const item of knownKeywords) {
    if (item.pattern.test(text)) {
      if (!charactersInProblem.includes(item.name)) {
        charactersInProblem.push(item.name);
      }
    }
  }

  if (charactersInProblem.length === 0) {
    const nameMatch = text.match(/\b(Bạn|Bác|Chú|Cô|Bé|Em)\s+([A-ZÀ-Ỹ][a-zà-ỹ]+)/);
    if (nameMatch) {
      charactersInProblem.push(`${nameMatch[1]} ${nameMatch[2]}`);
    } else {
      charactersInProblem.push('Bé Lan');
    }
  }

  // Validity checks: must have at least 2 numbers, and text at least 10 chars
  const isValid = numbers.length >= 2 && text.trim().length >= 10;
  let validationMessage = '';
  if (!isValid) {
    if (numbers.length === 0) {
      validationMessage = 'Bài toán không hợp lệ: Đề bài không chứa số liệu nào. Vui lòng nhập đề bài có ít nhất 2 số liệu và câu hỏi cần tìm.';
    } else if (numbers.length === 1) {
      validationMessage = `Bài toán không hợp lệ: Đề bài chỉ có 1 số liệu (${numbers[0]} ${unit}). Cần ít nhất 2 số liệu để xác định phép tính.`;
    } else {
      validationMessage = 'Bài toán không hợp lệ: Nội dung đề bài quá ngắn hoặc thiếu thông tin.';
    }
  }

  // Operation priority detection
  // 1. Multiplication: "mỗi hàng có ... hỏi ... hàng", "gấp ... lần", "nhân"
  const isMultiplication =
    lower.includes('nhân') ||
    lower.includes('gấp') ||
    ((lower.includes('mỗi') || lower.includes('1 hàng') || lower.includes('mỗi hàng')) &&
      (lower.includes('hàng cây') || lower.includes('nhóm') || lower.includes('như thế')));

  // 2. Division: "chia đều", "chia cho", "chia thành"
  const isDivision = lower.includes('chia đều') || lower.includes('chia cho') || lower.includes('chia thành') || lower.includes('chia ra');

  // 3. Subtraction: "bán", "bớt", "cho đi", "còn lại", "ít hơn", "ngắn hơn", "nhẹ hơn", "trừ"
  const isSubtraction =
    lower.includes('bớt') ||
    lower.includes('ít hơn') ||
    lower.includes('còn lại') ||
    lower.includes('cho đi') ||
    lower.includes('đã bán') ||
    lower.includes('bán đi') ||
    lower.includes('bán') ||
    lower.includes('trừ') ||
    lower.includes('ngắn hơn') ||
    lower.includes('nhẹ hơn');

  let operation = 'CỘNG';
  let calculation = '';
  let result: number | null = null;
  let explanation = '';

  const a = numbers[0] !== undefined ? numbers[0] : 25;
  const b = numbers[1] !== undefined ? numbers[1] : 17;
  const safeNums = [a, b];

  if (isMultiplication) {
    operation = 'NHÂN';
    result = a * b;
    calculation = `${a} × ${b} = ${result}`;
    explanation = `Mỗi nhóm có ${a} (${unit}), có ${b} nhóm như thế nên ta thực hiện phép nhân: ${a} × ${b} = ${result} (${unit}).`;
  } else if (isDivision && b !== 0) {
    operation = 'CHIA';
    result = Math.floor(a / b);
    calculation = `${a} : ${b} = ${result}`;
    explanation = `Có ${a} (${unit}) chia đều vào ${b} phần nên ta thực hiện phép chia: ${a} : ${b} = ${result} (${unit}).`;
  } else if (isSubtraction) {
    operation = 'TRỪ';
    const big = Math.max(a, b);
    const small = Math.min(a, b);
    result = big - small;
    calculation = `${big} - ${small} = ${result}`;
    safeNums[0] = big;
    safeNums[1] = small;
    explanation = `Vì có bớt đi, đã bán hoặc tìm số còn lại nên ta thực hiện phép trừ: ${big} - ${small} = ${result} (${unit}).`;
  } else {
    // Default: Addition
    operation = 'CỘNG';
    result = a + b;
    calculation = `${a} + ${b} = ${result}`;
    explanation = `Vì tìm số lượng tất cả (thêm vào hoặc nhiều hơn) nên ta thực hiện phép cộng: ${a} + ${b} = ${result} (${unit}).`;
  }

  return {
    numbers: safeNums,
    operation,
    calculation,
    result,
    unit,
    explanation,
    hasEnoughData: numbers.length >= 2,
    isValid,
    validationMessage,
    charactersInProblem,
  };
}

// In-memory persistent database for projects, submissions, moderation
const memoryDb = {
  projects: [] as any[],
  characters: [] as any[],
  submissions: [] as any[],
};

// Seed default projects & characters
memoryDb.characters = [
  {
    id: 'char-lan',
    name: 'Bé Lan',
    role: 'Học sinh lớp 2A2',
    age: 7,
    gender: 'Nữ',
    appearance: 'Cô bé 7 tuổi dễ thương, hai mắt to tròn sáng ngời, tóc buộc hai bên có nơ đỏ, nụ cười tươi tắn.',
    outfit: 'Áo thun màu vàng cam năng động, chân váy jean xanh, đeo khăn quàng nhỏ gọn.',
    personality: 'Chăm chỉ, thích học Toán, yêu thích khám phá và giúp đỡ mẹ.',
    voiceStyle: 'Giọng bé gái miền Bắc trong trẻo, hồn nhiên, vui tươi',
    isPreset: true,
  },
  {
    id: 'char-minh',
    name: 'Bé Minh',
    role: 'Học sinh lớp 2A2',
    age: 7,
    gender: 'Nam',
    appearance: 'Cậu bé 7 tuổi thông minh, tóc đen cắt gọn gàng, đeo cặp kính tròn ngộ nghĩnh.',
    outfit: 'Áo sơ mi cộc tay trắng cổ viền xanh dương, quần sóc kaki màu kem, giày thể thao.',
    personality: 'Ham học hỏi, thích đố vui toán học, tính nhẩm nhanh.',
    voiceStyle: 'Giọng bé trai hoạt bát, rõ ràng, tự tin',
    isPreset: true,
  },
  {
    id: 'char-huong',
    name: 'Cô giáo Hương',
    role: 'Giáo viên chủ nhiệm Lớp 2',
    age: 28,
    gender: 'Nữ',
    appearance: 'Cô giáo trẻ trung, gương mặt nhân hậu, ánh mắt ấm áp khích lệ học trò.',
    outfit: 'Áo dài truyền thống màu xanh ngọc bích trang nhã, tóc buông xõa ngang vai.',
    personality: 'Dịu dàng, tận tụy, luôn khen ngợi và gợi mở tư duy cho học sinh tiểu học.',
    voiceStyle: 'Giọng cô giáo Hà Nội chuẩn mực, truyền cảm, ấm áp, nhịp điệu chậm rãi',
    isPreset: true,
  },
  {
    id: 'char-robot',
    name: 'Toán Tô-bốt (AI Robot)',
    role: 'Trợ lý học tập thông minh',
    age: 2,
    gender: 'Robot',
    appearance: 'Robot nhỏ xinh hình tròn bầu bĩnh màu xanh dương và trắng bạc, 2 ăng-ten phát sáng, màn hình trước ngực hiển thị các phép tính vui nhộn.',
    outfit: 'Vỏ kim loại bóng loáng, bánh lăn cơ động, cánh tay nam châm hút số.',
    personality: 'Hài hước, thông minh, luôn mang đến những thử thách bất ngờ.',
    voiceStyle: 'Giọng robot thân thiện, có âm vang điện tử nhẹ, ngộ nghĩnh',
    isPreset: true,
  },
];

// Canonical Sample Project: "Bài toán những quả cam"
memoryDb.projects.push({
  id: 'project-cam-sample',
  title: 'Bài toán những quả cam',
  grade: 'Lớp 2',
  classId: '2A2',
  school: 'Tiểu học Đặng Trần Côn',
  author: 'Hoàng Diệu Hương',
  isSample: true,
  topic: 'Phép cộng có nhớ trong phạm vi 100',
  problemText: 'Lan có 25 quả cam. Mẹ cho Lan thêm 17 quả cam. Hỏi Lan có tất cả bao nhiêu quả cam?',
  mathAnalysis: {
    problemStatement: 'Lan có 25 quả cam. Mẹ cho Lan thêm 17 quả cam. Hỏi Lan có tất cả bao nhiêu quả cam?',
    givenData: ['Lan có lúc đầu: 25 quả cam', 'Mẹ cho thêm: 17 quả cam'],
    target: 'Số quả cam Lan có tất cả',
    mathematicalRelation: 'Tìm tổng của hai số lượng khi được nhận thêm',
    calculation: '25 + 17 = 42',
    result: 42,
    unit: 'quả cam',
    verifiedByDeterministicCode: true,
    knowledgeGoal: 'Rèn luyện kỹ năng giải bài toán có lời văn dạng thêm vào, củng cố phép cộng có nhớ trong phạm vi 100 (5 + 7 = 12 viết 2 nhớ 1, 2 + 1 = 3 thêm 1 bằng 4).',
    commonMistakes: [
      'Chọn nhầm phép trừ 25 - 17 vì nhìn nhầm từ khóa',
      'Cộng quên nhớ: 25 + 17 = 32 (5 + 7 = 12 viết 2 nhưng quên nhớ 1 vào hàng chục)',
      'Ghi sai đơn vị (ví dụ ghi quả táo hoặc chỉ ghi 42 không có đơn vị)',
    ],
    guidingQuestions: [
      'Lúc đầu Lan có bao nhiêu quả cam?',
      'Mẹ cho thêm thì số cam của Lan tăng lên hay giảm đi?',
      'Muốn biết Lan có tất cả bao nhiêu quả ta làm phép tính gì?',
    ],
    status: 'ĐÃ_DUYỆT_PHÂN_TÍCH',
  },
  storyboard: {
    theme: 'Gia đình và cuộc sống',
    durationSeconds: 45,
    style: 'Hoạt hình 3D dễ thương',
    scenes: [
      {
        sceneNumber: 1,
        title: 'Cảnh 1: Gian bếp ấm áp của bé Lan',
        duration: 12,
        setting: 'Gian bếp sáng sủa, ấm cúng của gia đình bé Lan, trên bàn gỗ có một chiếc rổ mây đựng 25 quả cam vàng tươi.',
        characters: ['Bé Lan', 'Mẹ'],
        action: 'Lan đứng bên bàn đếm những quả cam tươi mẹ vừa hái trong vườn. Lan mỉm cười rạng rỡ và xếp cam ngăn nắp.',
        dialogue: 'A, sáng nay mình đã hái được 25 quả cam vàng ươm rồi này! Cam thơm quá!',
        soundFx: 'Tiếng chim hót líu lo ngoài cửa sổ, nhạc nền thiếu nhi vui tươi rộn rã.',
        mathData: 'Lúc đầu: 25 quả cam',
        imageUrl: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=1200&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        imagePrompt: '3D cute Pixar cartoon style. A cheerful 7-year-old Vietnamese girl with twin pigtails and red ribbons (Character: Bé Lan) smiling in a sunlit cozy kitchen, counting exactly 25 vibrant ripe oranges neatly arranged in a woven basket on a wooden table, warm ambient lighting, 16:9 ratio, child-friendly educational art.',
        motionPrompt: 'Slow push in camera towards Lan as she gently touches an orange with a happy smile, warm sunlight glistening through kitchen window.',
        interactiveQuestion: null,
      },
      {
        sceneNumber: 2,
        title: 'Cảnh 2: Món quà bất ngờ của Mẹ & Thử thách tương tác',
        duration: 18,
        setting: 'Mẹ Lan bước vào với chiếc túi đựng thêm 17 quả cam mọng nước, đặt cạnh rổ cam của Lan.',
        characters: ['Bé Lan', 'Mẹ'],
        action: 'Mẹ mỉm cười xoa đầu Lan và trao thêm cho Lan 17 quả cam. Video tạm dừng tại giây thứ 15 để hiển thị câu hỏi tương tác cho học sinh.',
        dialogue: 'Lan ngoan lắm! Mẹ cho con thêm 17 quả cam nữa nhé! Đố con biết bây giờ con có tất cả bao nhiêu quả cam?',
        soundFx: 'Âm thanh keng nhẹ báo hiệu thử thách tư duy xuất hiện, nhạc chậm lại chờ bé trả lời.',
        mathData: 'Mẹ cho thêm: 17 quả cam. Tìm tổng số cam?',
        imageUrl: 'https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?auto=format&fit=crop&w=1200&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
        imagePrompt: '3D cute animation style. Gentle Vietnamese mother in friendly homewear handing a small basket with 17 fresh oranges to her happy daughter Bé Lan in the bright kitchen, playful math sparkles in the air, vivid colors, educational illustration, 16:9 widescreen.',
        motionPrompt: 'Mother hands over the basket of 17 oranges. Gentle pause effect as a glowing question mark sparkles above Lan.',
        interactiveQuestion: {
          id: 'q-cam-1',
          type: 'CHỌN_PHÉP_TÍNH',
          question: 'Mẹ cho Lan thêm 17 quả cam. Để biết Lan có tất cả bao nhiêu quả cam, em chọn phép tính nào?',
          options: [
            { label: 'A. 25 + 17', isCorrect: true, feedback: 'Chính xác! Mẹ cho thêm nên số cam của Lan tăng lên, ta thực hiện phép tính cộng 25 + 17.' },
            { label: 'B. 25 - 17', isCorrect: false, feedback: 'Chưa đúng rồi. Mẹ cho thêm cam chứ không bớt đi, nên số cam phải nhiều hơn. Em hãy chọn phép cộng nhé!' },
            { label: 'C. 25 × 17', isCorrect: false, feedback: 'Chưa đúng rồi. Đây là bài toán thêm vào số lượng, chưa phải dạng nhóm nhiều lần. Em hãy thử lại!' },
          ],
          resultCalculation: '25 + 17 = 42 quả cam',
          hintStep1: 'Mẹ cho thêm cam thì số cam của Lan nhiều hơn hay ít đi nhỉ?',
          hintStep2: 'Tìm số cam "tất cả" khi được cho thêm, ta dùng phép cộng.',
        },
      },
      {
        sceneNumber: 3,
        title: 'Cảnh 3: Niềm vui chiến thắng & Đáp số 42 quả cam',
        duration: 15,
        setting: 'Lan cùng mẹ xếp các quả cam thành 4 rổ chục (40 quả) và 2 quả cam đơn vị, tổng cộng là 42 quả cam.',
        characters: ['Bé Lan', 'Mẹ'],
        action: 'Lan vui mừng nhảy cẫng lên vỗ tay. Mẹ và Lan cùng nhau thưởng thức ly nước cam thơm ngon.',
        dialogue: 'Dạ, con tính ra rồi ạ! 25 cộng 17 bằng 42 quả cam! Con có tất cả 42 quả cam ạ!',
        soundFx: 'Âm thanh pháo hoa vui nhộn, tiếng cười hạnh phúc của hai mẹ con, nhạc kết thúc rộn ràng.',
        mathData: 'Đáp số: 42 quả cam (25 + 17 = 42)',
        imageUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
        imagePrompt: '3D animation scene. Cheerful 7-year-old girl Bé Lan and her mother joyfully celebrating in the kitchen with a glass of fresh orange juice, 42 bright oranges arranged clearly in baskets, confetti stars, warm heartwarming atmosphere, 16:9.',
        motionPrompt: 'Lan jumps joyfully with hands up in victory, mother claps hands with proud smile, gentle confetti falling.',
        interactiveQuestion: null,
      },
    ],
  },
  moderationChecklist: {
    curriculumCompliant: true,
    dataAccurate: true,
    calculationVerified: true,
    dialogueAppropriate: true,
    imageSafe: true,
    characterConsistent: true,
    audioClear: true,
    questionEngaging: true,
    pedagogicalFeedback: true,
    trialTested: true,
    status: 'ĐÃ_XUẤT_BẢN',
    approvedBy: 'Cô giáo Hoàng Diệu Hương',
    approvedDate: new Date().toISOString().split('T')[0],
  },
  createdAt: new Date().toISOString(),
});

// Seed sample student evaluation records for class 2A2
memoryDb.submissions = [
  {
    id: 'sub-1',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-01',
    studentName: 'Trần Minh Anh',
    isDemo: true,
    chosenOption: 'A. 25 + 17',
    isCorrect: true,
    attemptCount: 1,
    timeTakenSeconds: 8,
    errorType: 'KHÔNG_CÓ',
    timestamp: '2026-03-20T08:30:00Z',
  },
  {
    id: 'sub-2',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-02',
    studentName: 'Nguyễn Bảo Nam',
    isDemo: true,
    chosenOption: 'B. 25 - 17',
    isCorrect: false,
    attemptCount: 2,
    timeTakenSeconds: 15,
    errorType: 'SAI_LỰA_CHỌN_PHÉP_TÍNH',
    timestamp: '2026-03-20T08:32:00Z',
  },
  {
    id: 'sub-3',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-03',
    studentName: 'Lê Linh Đan',
    isDemo: true,
    chosenOption: 'A. 25 + 17',
    isCorrect: true,
    attemptCount: 1,
    timeTakenSeconds: 6,
    errorType: 'KHÔNG_CÓ',
    timestamp: '2026-03-20T08:35:00Z',
  },
  {
    id: 'sub-4',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-04',
    studentName: 'Vũ Đức Khang',
    isDemo: true,
    chosenOption: 'A. 25 + 17',
    isCorrect: true,
    attemptCount: 1,
    timeTakenSeconds: 10,
    errorType: 'KHÔNG_CÓ',
    timestamp: '2026-03-20T08:40:00Z',
  },
  {
    id: 'sub-5',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-05',
    studentName: 'Phạm Tuệ Mẫn',
    isDemo: true,
    chosenOption: 'B. 25 - 17',
    isCorrect: false,
    attemptCount: 3,
    timeTakenSeconds: 22,
    errorType: 'SAI_LỰA_CHỌN_PHÉP_TÍNH',
    timestamp: '2026-03-20T08:45:00Z',
  },
  {
    id: 'sub-6',
    projectId: 'project-cam-sample',
    studentCode: 'HS-2A2-06',
    studentName: 'Hoàng Quang Huy',
    isDemo: true,
    chosenOption: 'A. 25 + 17',
    isCorrect: true,
    attemptCount: 1,
    timeTakenSeconds: 7,
    errorType: 'KHÔNG_CÓ',
    timestamp: '2026-03-20T08:48:00Z',
  },
];

// ==========================================
// API ROUTES
// ==========================================

// 1. Health check & configuration status
app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    appName: 'MATH STORY AI',
    version: '2026.1.0',
    school: 'TIỂU HỌC ĐẶNG TRẦN CÔN',
    class: '2A2',
    author: 'HOÀNG DIỆU HƯƠNG',
    geminiConfigured: hasApiKey,
    deterministicMathEngineReady: true,
    videoFlowWorkflowReady: true,
    imageStudioReady: true,
  });
});

// Helper: auto-register characters found in problem
function autoRegisterCharactersFromProblem(chars: string[]) {
  chars.forEach((name) => {
    const exists = memoryDb.characters.some((c) => c.name.toLowerCase() === name.toLowerCase());
    if (!exists && name) {
      const isFemale = /mẹ|bà|lan|mai|linh|cúc|hoa|nữ|cô/i.test(name);
      const isAdult = /bác|chú|cô|mẹ|bà|bố|ông|giáo viên/i.test(name);
      memoryDb.characters.unshift({
        id: `char-problem-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        name,
        role: isAdult ? 'Nhân vật trong bài toán' : 'Học sinh lớp 2A2',
        age: isAdult ? 35 : 7,
        gender: isFemale ? 'Nữ' : 'Nam',
        appearance: isAdult
          ? `${name} hiền hậu, nụ cười ấm áp, trang phục giản dị gần gũi, hoạt hình 3D phong cách Pixar.`
          : `Bạn nhỏ ${name} 7 tuổi thông minh nhanh nhẹn, gương mặt tươi sáng, phong cách 3D đáng yêu.`,
        outfit: isAdult ? 'Trang phục đời thường ấm cúng, màu sắc tươi tắn' : 'Đồng phục học sinh lớp 2 năng động',
        personality: 'Thân thiện, chăm chỉ, yêu thích các câu chuyện toán học.',
        voiceStyle: isAdult ? 'Giọng người lớn truyền cảm, ấm áp' : 'Giọng thiếu nhi trong trẻo, vui tươi',
        isPreset: false,
        fromCurrentProblem: true,
      });
    }
  });
}

// 2. Math Analysis API
app.post('/api/math/analyze', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  try {
    const { problemText, grade = 'Lớp 2', topic = 'Bài toán có lời văn' } = req.body;

    if (!problemText || typeof problemText !== 'string' || problemText.trim().length === 0) {
      res.status(200).json({
        problemStatement: 'Chưa có đề bài',
        givenData: ['Vui lòng nhập đề bài toán'],
        target: 'Chưa xác định',
        mathematicalRelation: 'Chưa có dữ kiện',
        operation: 'KHÔNG_HỢP_LỆ',
        calculation: '',
        result: null,
        unit: 'đơn vị',
        isValid: false,
        validationMessage: 'Đề bài chưa được nhập. Vui lòng nhập nội dung bài toán.',
        knowledgeGoal: 'Rèn luyện khả năng nhận biết dữ kiện',
        commonMistakes: ['Đọc lướt đề bài'],
        guidingQuestions: ['Đề bài cho biết gì?'],
        status: 'CHỜ_PHÊ_DUYỆT',
        verifiedByDeterministicCode: true,
      });
      return;
    }

    // Always run deterministic check first
    const deterministic = solveGrade2MathDeterministic(problemText);

    // Auto-register characters in problem to character library
    if (deterministic.charactersInProblem && deterministic.charactersInProblem.length > 0) {
      autoRegisterCharactersFromProblem(deterministic.charactersInProblem);
    }

    // Check validity
    if (!deterministic.isValid) {
      res.status(200).json({
        problemStatement: problemText,
        givenData: deterministic.numbers.map((n) => `Số liệu tìm thấy: ${n} ${deterministic.unit}`),
        target: 'Chưa đủ dữ kiện để xác định yêu cầu',
        mathematicalRelation: deterministic.validationMessage,
        operation: 'KHÔNG_HỢP_LỆ',
        calculation: 'Chưa thể thực hiện phép tính',
        result: null,
        unit: deterministic.unit,
        isValid: false,
        validationMessage: deterministic.validationMessage,
        charactersInProblem: deterministic.charactersInProblem,
        knowledgeGoal: 'Cần bổ sung đầy đủ số liệu và câu hỏi theo chuẩn môn Toán lớp 2.',
        commonMistakes: ['Đề bài thiếu dữ kiện số liệu hoặc không có câu hỏi cần tìm.'],
        guidingQuestions: ['Đề bài đã cho biết những số lượng nào?', 'Bài toán yêu cầu tìm cái gì?'],
        deterministicCheck: deterministic,
        verifiedByDeterministicCode: true,
        status: 'CHỜ_PHÊ_DUYỆT',
      });
      return;
    }

    // If Gemini API is available, enrich with pedagogical analysis
    if (aiClient) {
      try {
        const prompt = `Bạn là chuyên gia giáo dục tiểu học am hiểu sâu sắc Chương trình GDPT 2018 môn Toán lớp 2 tại Việt Nam.
Hãy phân tích bài toán sau đây cho học sinh ${grade}:
Đề bài: "${problemText}"
Chủ đề: "${topic}"

Hãy trả về định dạng JSON đúng theo cấu trúc:
{
  "problemStatement": "${problemText.replace(/"/g, '\\"')}",
  "givenData": ["danh sách từng dữ kiện cụ thể đề bài đã cho"],
  "target": "câu hỏi và yêu cầu cụ thể cần tìm",
  "mathematicalRelation": "mối quan hệ toán học giữa các dữ kiện",
  "operation": "${deterministic.operation}",
  "calculation": "${deterministic.calculation}",
  "result": ${deterministic.result ?? 0},
  "unit": "${deterministic.unit}",
  "knowledgeGoal": "mục tiêu kiến thức, năng lực toán học cần hình thành cho học sinh lớp 2 theo CT GDPT 2018",
  "commonMistakes": ["3 lỗi sai thường gặp nhất của học sinh lớp 7-8 tuổi khi làm bài này"],
  "guidingQuestions": ["3 câu hỏi gợi mở từng bước giúp học sinh tự tìm ra cách giải mà không làm thay em"]
}
Chỉ trả về JSON hợp lệ, không giải thích thêm.`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            thinkingConfig: {
              thinkingLevel: ThinkingLevel.LOW,
            },
          },
        });

        const rawText = response.text || '';
        const cleanJson = rawText.replace(/```json\n?/gi, '').replace(/```\n?/g, '').trim();
        const parsed = JSON.parse(cleanJson || '{}');

        res.status(200).json({
          problemStatement: problemText,
          givenData: Array.isArray(parsed.givenData) && parsed.givenData.length > 0
            ? parsed.givenData
            : [`Dữ kiện 1: ${deterministic.numbers[0]} ${deterministic.unit}`, `Dữ kiện 2: ${deterministic.numbers[1]} ${deterministic.unit}`],
          target: parsed.target || `Tìm số lượng ${deterministic.unit} theo yêu cầu bài toán`,
          mathematicalRelation: parsed.mathematicalRelation || deterministic.explanation,
          operation: parsed.operation || deterministic.operation,
          calculation: parsed.calculation || deterministic.calculation,
          result: typeof parsed.result === 'number' ? parsed.result : deterministic.result,
          unit: parsed.unit || deterministic.unit,
          num1: deterministic.numbers[0] || 0,
          num2: deterministic.numbers[1] || 0,
          problemType: parsed.operation || deterministic.operation,
          knowledgeGoal: parsed.knowledgeGoal || 'Rèn luyện khả năng nhận biết dữ kiện, lựa chọn phép tính phù hợp và tính toán chính xác môn Toán lớp 2.',
          commonMistakes: Array.isArray(parsed.commonMistakes) && parsed.commonMistakes.length > 0
            ? parsed.commonMistakes
            : ['Chọn sai phép tính do đọc lướt từ khóa', 'Tính nhầm khi thực hiện phép tính có nhớ', 'Quên ghi đơn vị vào đáp số'],
          guidingQuestions: Array.isArray(parsed.guidingQuestions) && parsed.guidingQuestions.length > 0
            ? parsed.guidingQuestions
            : ['Bài toán cho em biết những gì?', 'Bài toán hỏi em điều gì?', 'Em chọn phép tính nào để giải bài toán?'],
          deterministicCheck: deterministic,
          verifiedByDeterministicCode: true,
          isValid: true,
          validationMessage: '',
          charactersInProblem: deterministic.charactersInProblem,
          status: 'CHỜ_PHÊ_DUYỆT',
        });
        return;
      } catch (geminiError: any) {
        console.warn('Gemini analysis error, falling back to deterministic engine:', geminiError?.message);
      }
    }

    // Deterministic fallback response when Gemini is not configured or offline
    res.status(200).json({
      problemStatement: problemText,
      givenData: [
        `Số thứ nhất: ${deterministic.numbers[0]} ${deterministic.unit}`,
        `Số thứ hai: ${deterministic.numbers[1]} ${deterministic.unit}`,
      ],
      target: `Tìm kết quả bài toán với đơn vị ${deterministic.unit}`,
      mathematicalRelation: deterministic.explanation,
      operation: deterministic.operation,
      calculation: deterministic.calculation,
      result: deterministic.result,
      unit: deterministic.unit,
      num1: deterministic.numbers[0] || 0,
      num2: deterministic.numbers[1] || 0,
      problemType: deterministic.operation,
      knowledgeGoal: 'Rèn luyện khả năng nhận biết dữ kiện, lựa chọn phép tính phù hợp và tính toán chính xác theo chuẩn môn Toán lớp 2.',
      commonMistakes: [
        'Chọn sai phép tính do đọc lướt từ khóa',
        'Cộng/trừ nhầm khi thực hiện tính toán có nhớ',
        'Quên viết đơn vị đo trong câu trả lời',
      ],
      guidingQuestions: [
        'Bài toán cho em biết những gì?',
        'Bài toán hỏi em điều gì?',
        'Để tìm được câu trả lời, em sẽ lựa chọn phép tính nào?',
      ],
      deterministicCheck: deterministic,
      verifiedByDeterministicCode: true,
      isValid: deterministic.isValid,
      validationMessage: deterministic.validationMessage,
      charactersInProblem: deterministic.charactersInProblem,
      status: 'CHỜ_PHÊ_DUYỆT',
    });
  } catch (err: any) {
    console.error('Error in /api/math/analyze:', err);
    const deterministic = solveGrade2MathDeterministic(req.body?.problemText || '');
    res.status(200).json({
      problemStatement: req.body?.problemText || '',
      givenData: [`Dữ kiện: ${deterministic.numbers.join(', ')} ${deterministic.unit}`],
      target: `Tìm số lượng ${deterministic.unit}`,
      mathematicalRelation: deterministic.explanation,
      operation: deterministic.operation,
      calculation: deterministic.calculation,
      result: deterministic.result,
      unit: deterministic.unit,
      num1: deterministic.numbers[0] || 0,
      num2: deterministic.numbers[1] || 0,
      problemType: deterministic.operation,
      knowledgeGoal: 'Rèn luyện kỹ năng giải toán có lời văn lớp 2',
      commonMistakes: ['Tính toán nhầm'],
      guidingQuestions: ['Em hãy đọc kỹ đề bài'],
      deterministicCheck: deterministic,
      verifiedByDeterministicCode: true,
      status: 'CHỜ_PHÊ_DUYỆT',
    });
  }
});

function getDefaultSceneImage(sceneNumber: number, unit: string = 'quả cam'): string {
  const u = (unit || '').toLowerCase();
  if (u.includes('trứng') || u.includes('gà')) {
    if (sceneNumber === 1) return 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=1200&q=80';
    if (sceneNumber === 2) return 'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?auto=format&fit=crop&w=1200&q=80';
    return 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80';
  }
  if (u.includes('cây') || u.includes('hoa')) {
    if (sceneNumber === 1) return 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=80';
    if (sceneNumber === 2) return 'https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?auto=format&fit=crop&w=1200&q=80';
    return 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80';
  }
  // Default oranges / bright Pixar classroom
  if (sceneNumber === 1) return 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=1200&q=80';
  if (sceneNumber === 2) return 'https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?auto=format&fit=crop&w=1200&q=80';
  return 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80';
}

// 3. Storyboard Generation API
app.post('/api/math/generate-script', async (req: Request, res: Response) => {
  try {
    const { problemText, analysis, theme = 'Gia đình và cuộc sống', durationSeconds = 45, characterId = 'char-lan' } = req.body;

    const selectedChar = memoryDb.characters.find(c => c.id === characterId) || memoryDb.characters[0];

    if (aiClient) {
      try {
        const prompt = `Bạn là biên kịch hoạt hình giáo dục thiếu nhi kiêm chuyên gia phương pháp dạy Toán lớp 2 tại Việt Nam.
Hãy chuyển thể bài toán sau thành kịch bản phân cảnh hoạt hình 3D (3 cảnh) hấp dẫn, gần gũi, nhân văn cho học sinh 7-8 tuổi.

Đề bài: "${problemText}"
Phép tính đáp án: "${analysis?.calculation || ''}"
Chủ đề câu chuyện: "${theme}"
Thời lượng: ${durationSeconds} giây
Nhân vật chính: "${selectedChar.name}" (${selectedChar.appearance}, tính cách: ${selectedChar.personality})

YÊU CẦU QUAN TRỌNG:
1. Cảnh 1: Giới thiệu tình huống tự nhiên, nêu dữ kiện đầu tiên.
2. Cảnh 2: Xuất hiện dữ kiện thứ hai và TẠM DỪNG để tạo câu hỏi thử thách tương tác cho học sinh. TUYỆT ĐỐI KHÔNG tiết lộ đáp án ở cảnh 2!
3. Cảnh 3: Sau khi học sinh trả lời đúng, nhân vật giải thích phép tính, ăn mừng và chốt đáp số.
4. Mỗi cảnh có lời thoại tiếng Việt ngắn gọn, biểu cảm đáng yêu, phù hợp trẻ 7-8 tuổi.
5. Mỗi cảnh có "imagePrompt" tiếng Anh chi tiết để tạo ảnh hoạt hình 3D phong cách Pixar, giữ nguyên đặc điểm nhân vật ${selectedChar.name}.
6. Mỗi cảnh có "motionPrompt" cho chuyển động video.

Trả về JSON đúng cấu trúc:
{
  "theme": "${theme}",
  "durationSeconds": ${durationSeconds},
  "style": "Hoạt hình 3D dễ thương",
  "scenes": [
    {
      "sceneNumber": 1,
      "title": "Tên cảnh 1",
      "duration": 12,
      "setting": "Mô tả bối cảnh",
      "characters": ["${selectedChar.name}"],
      "action": "Hành động của nhân vật",
      "dialogue": "Lời thoại tiếng Việt",
      "soundFx": "Hiệu ứng âm thanh và nhạc nền",
      "mathData": "Dữ kiện 1",
      "imagePrompt": "English 3D Pixar cartoon prompt with character details",
      "motionPrompt": "Camera and character movement prompt for video generation",
      "interactiveQuestion": null
    },
    {
      "sceneNumber": 2,
      "title": "Tên cảnh 2 & Thử thách tương tác",
      "duration": 18,
      "setting": "Mô tả bối cảnh cảnh 2",
      "characters": ["${selectedChar.name}"],
      "action": "Hành động đưa ra câu hỏi và tạm dừng",
      "dialogue": "Lời thoại đưa ra tình huống",
      "soundFx": "Âm thanh chuông báo thử thách",
      "mathData": "Dữ kiện 2",
      "imagePrompt": "English 3D animation prompt",
      "motionPrompt": "Video prompt with pause point",
      "interactiveQuestion": {
        "id": "q-1",
        "type": "CHỌN_PHÉP_TÍNH",
        "question": "Câu hỏi tương tác ngắn gọn dễ hiểu",
        "options": [
          {"label": "A. Phép tính đúng", "isCorrect": true, "feedback": "Lời khen ngợi và giải thích ngắn gọn"},
          {"label": "B. Phép tính sai 1", "isCorrect": false, "feedback": "Gợi ý nhẹ nhàng không chê bai"},
          {"label": "C. Phép tính sai 2", "isCorrect": false, "feedback": "Gợi ý định hướng lại"}
        ],
        "resultCalculation": "${analysis?.calculation || ''}",
        "hintStep1": "Gợi ý bước 1",
        "hintStep2": "Gợi ý bước 2"
      }
    },
    {
      "sceneNumber": 3,
      "title": "Tên cảnh 3: Khám phá đáp án & Niềm vui chiến thắng",
      "duration": 15,
      "setting": "Mô tả bối cảnh cảnh 3",
      "characters": ["${selectedChar.name}"],
      "action": "Ăn mừng và nêu đáp số",
      "dialogue": "Lời thoại tổng kết đáp án",
      "soundFx": "Tiếng pháo hoa chúc mừng",
      "mathData": "Đáp số cuối cùng",
      "imagePrompt": "English 3D animation victory scene prompt",
      "motionPrompt": "Celebratory motion prompt",
      "interactiveQuestion": null
    }
  ]
}
Chỉ trả về JSON hợp lệ.`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            thinkingConfig: {
              thinkingLevel: ThinkingLevel.LOW,
            },
          },
        });

        const rawText = response.text || '';
        const cleanJson = rawText.replace(/```json\n?/gi, '').replace(/```\n?/g, '').trim();
        const parsed = JSON.parse(cleanJson || '{}');
        if (parsed && Array.isArray(parsed.scenes)) {
          parsed.scenes = parsed.scenes.map((s: any, idx: number) => ({
            ...s,
            imageUrl: s.imageUrl || getDefaultSceneImage(s.sceneNumber || idx + 1, analysis?.unit || 'quả cam'),
          }));
        }
        res.json(parsed);
        return;
      } catch (geminiError: any) {
        console.warn('Gemini script generation fallback:', geminiError?.message);
      }
    }

    // High quality pedagogical template fallback
    const num1 = analysis?.num1 ?? analysis?.deterministicCheck?.numbers?.[0] ?? 25;
    const num2 = analysis?.num2 ?? analysis?.deterministicCheck?.numbers?.[1] ?? 17;
    const op = analysis?.operation || analysis?.deterministicCheck?.operation || 'CỘNG';
    const unit = analysis?.unit || analysis?.deterministicCheck?.unit || 'quả cam';
    const resValue = analysis?.result ?? analysis?.deterministicCheck?.result ?? (op.includes('TRỪ') ? Math.max(num1, num2) - Math.min(num1, num2) : num1 + num2);
    const calc = analysis?.calculation || `${num1} ${op.includes('TRỪ') ? '-' : op.includes('NHÂN') ? '×' : op.includes('CHIA') ? ':' : '+'} ${num2} = ${resValue}`;

    let scene1Title = `Cảnh 1: Khởi đầu cùng ${selectedChar.name}`;
    let scene1Action = `${selectedChar.name} đang vui tươi cùng ${num1} ${unit}.`;
    let scene1Dialogue = `Chào các bạn nhỏ! Mình đang có ${num1} ${unit} đây này!`;
    let scene1Math = `Dữ kiện 1: ${num1} ${unit}`;

    let scene2Title = `Cảnh 2: Tình huống bài toán & Thử thách tương tác`;
    let scene2Action = `Tình huống xuất hiện với ${num2} ${unit}. ${selectedChar.name} tạm dừng để cùng học sinh suy nghĩ!`;
    let scene2Dialogue = `Bây giờ các bạn hãy giúp mình tìm cách tính nhé!`;
    let scene2Math = `Dữ kiện 2: ${num2} ${unit}`;

    let questionText = `Đố em: Để tìm kết quả bài toán, ta chọn phép tính nào?`;
    let correctLabel = `A. ${num1} + ${num2}`;
    let distractor1 = `B. ${num1} - ${num2}`;
    let distractor2 = `C. ${num1} × ${num2}`;
    let correctFeedback = `Tuyệt vời! Em chọn phép tính rất chính xác!`;
    let hint1 = `Em hãy đọc kỹ câu hỏi của bài toán nhé!`;
    let hint2 = `Quan sát mối quan hệ giữa các dữ kiện ${num1} và ${num2}.`;

    if (op.includes('TRỪ') || op === '-') {
      scene1Dialogue = `Chào các bạn! Lúc đầu mình có ${num1} ${unit} đấy!`;
      scene2Dialogue = `Sau đó đã bớt đi (hoặc dùng hết) ${num2} ${unit}. Đố các bạn biết còn lại bao nhiêu ${unit}?`;
      questionText = `Đố em: Muốn biết còn lại bao nhiêu ${unit}, ta thực hiện phép tính gì?`;
      correctLabel = `A. ${num1} - ${num2}`;
      distractor1 = `B. ${num1} + ${num2}`;
      distractor2 = `C. ${num1} : ${num2}`;
      correctFeedback = `Hoan hô em! Muốn tìm phần còn lại ta lấy ${num1} - ${num2}.`;
      hint1 = `Khi bớt đi thì số lượng sẽ ít hơn lúc đầu!`;
      hint2 = `Ít hơn thì dùng phép tính trừ (-) em nhé!`;
    } else if (op.includes('NHÂN') || op === '×' || op === '*') {
      scene1Dialogue = `Chào các bạn! Ở đây có ${num1} hàng (hoặc nhóm) ${unit} này!`;
      scene2Dialogue = `Mỗi hàng có đúng ${num2} ${unit}. Đố các bạn biết tất cả có bao nhiêu ${unit}?`;
      questionText = `Đố em: Để tính tổng số ${unit} trong các hàng đều nhau, ta dùng phép tính nào?`;
      correctLabel = `A. ${num1} × ${num2}`;
      distractor1 = `B. ${num1} + ${num2}`;
      distractor2 = `C. ${num1} - ${num2}`;
      correctFeedback = `Xuất sắc! Số lượng được lấy nhiều lần bằng nhau nên dùng phép nhân ${num1} × ${num2}.`;
      hint1 = `Mỗi nhóm đều có ${num2} ${unit}, có tất cả ${num1} nhóm!`;
      hint2 = `Lấy nhiều lần bằng nhau thì ta dùng phép tính nhân (×) nhé!`;
    } else if (op.includes('CHIA') || op === ':') {
      scene1Dialogue = `Chào các bạn! Mình có tất cả ${num1} ${unit}!`;
      scene2Dialogue = `Mình muốn chia đều cho ${num2} bạn. Đố các bạn mỗi bạn nhận được bao nhiêu?`;
      questionText = `Đố em: Để chia đều ${num1} ${unit} cho ${num2} phần, ta chọn phép tính nào?`;
      correctLabel = `A. ${num1} : ${num2}`;
      distractor1 = `B. ${num1} - ${num2}`;
      distractor2 = `C. ${num1} + ${num2}`;
      correctFeedback = `Rất giỏi! Chia thành các phần bằng nhau ta thực hiện phép chia ${num1} : ${num2}.`;
      hint1 = `Chia đều vào các phần bằng nhau!`;
      hint2 = `Chia đều thì ta dùng phép tính chia (:) em nhé!`;
    } else {
      // CỘNG
      scene1Dialogue = `Chào các bạn nhỏ! Mình đang có ${num1} ${unit} đây này!`;
      scene2Dialogue = `Ôi thích quá, bây giờ lại có thêm ${num2} ${unit} nữa! Đố các bạn biết tất cả có bao nhiêu?`;
      questionText = `Đố em: Để biết có tất cả bao nhiêu ${unit}, ta cần chọn phép tính nào?`;
      correctLabel = `A. ${num1} + ${num2}`;
      distractor1 = `B. ${num1} - ${num2}`;
      distractor2 = `C. ${num1} × ${num2}`;
      correctFeedback = `Tuyệt vời! Khi thêm vào hoặc tìm tất cả, ta thực hiện phép tính cộng ${num1} + ${num2}.`;
      hint1 = `Khi có thêm thì số ${unit} nhiều hơn hay ít đi?`;
      hint2 = `Nhiều hơn thì dùng phép tính cộng (+) em nhé!`;
    }

    res.json({
      theme,
      durationSeconds,
      style: 'Hoạt hình 3D dễ thương',
      scenes: [
        {
          sceneNumber: 1,
          title: scene1Title,
          duration: Math.round(durationSeconds * 0.3),
          setting: `Không gian ngập tràn ánh nắng ấm áp theo phong cách ${theme}`,
          characters: [selectedChar.name],
          action: scene1Action,
          dialogue: scene1Dialogue,
          soundFx: 'Nhạc nền thiếu nhi vui tươi, tiếng chim ca ríu rít.',
          mathData: scene1Math,
          imageUrl: getDefaultSceneImage(1, unit),
          imagePrompt: `3D Pixar style cute animation. A friendly 7-year-old child character (${selectedChar.name}: ${selectedChar.appearance}) cheerfully standing in a colorful environment (${theme}), interacting with ${num1} items (${unit}), bright vibrant lighting, 16:9 widescreen, clean educational design.`,
          motionPrompt: `Camera gently pans right as ${selectedChar.name} waves cheerfully to the camera with a bright friendly smile.`,
          interactiveQuestion: null,
        },
        {
          sceneNumber: 2,
          title: scene2Title,
          duration: Math.round(durationSeconds * 0.4),
          setting: `Không gian tiếp nối, xuất hiện thêm yếu tố (${num2} ${unit})`,
          characters: [selectedChar.name],
          action: scene2Action,
          dialogue: scene2Dialogue,
          soundFx: 'Âm thanh chuông báo câu hỏi tương tác (ding dong), nhạc tạm dừng.',
          mathData: scene2Math,
          imageUrl: getDefaultSceneImage(2, unit),
          imagePrompt: `3D educational cartoon. Character ${selectedChar.name} looking curious and asking a question, holding hands to chin in thought, next to group of ${num2} items (${unit}), animated glowing question symbols in warm pastel colors, 16:9.`,
          motionPrompt: `The character tilts head with a curious expression, gentle slow zoom into the thought bubble.`,
          interactiveQuestion: {
            id: 'q-auto-1',
            type: 'CHỌN_PHÉP_TÍNH',
            question: questionText,
            options: [
              {
                label: correctLabel,
                isCorrect: true,
                feedback: correctFeedback,
              },
              {
                label: distractor1,
                isCorrect: false,
                feedback: `Chưa chính xác rồi. Em hãy đọc lại gợi ý nhé!`,
              },
              {
                label: distractor2,
                isCorrect: false,
                feedback: `Chưa đúng rồi. Em hãy thử lại một lần nữa!`,
              },
            ],
            resultCalculation: calc,
            hintStep1: hint1,
            hintStep2: hint2,
          },
        },
        {
          sceneNumber: 3,
          title: 'Cảnh 3: Chúc mừng & Đáp số trọn vẹn',
          duration: Math.round(durationSeconds * 0.3),
          setting: 'Khung cảnh rực rỡ sắc màu, các đồ vật được xếp ngay ngắn thành kết quả.',
          characters: [selectedChar.name],
          action: `${selectedChar.name} giơ hai tay ăn mừng chiến thắng cùng các bạn học sinh, hiển thị đáp số rõ ràng trên màn hình.`,
          dialogue: `Đúng rồi các bạn ơi! Phép tính là ${calc}! Các bạn học sinh ${analysis?.grade || 'Lớp 2'} thật là thông minh!`,
          soundFx: 'Âm thanh pháo hoa chúc mừng tưng bừng, tiếng vỗ tay rộn rã.',
          mathData: `Đáp số: ${calc}`,
          imageUrl: getDefaultSceneImage(3, unit),
          imagePrompt: `3D Pixar animation style. Character ${selectedChar.name} celebrating joyfully with arms raised in victory, golden confetti stars raining down, celebratory atmosphere, cheerful expressions, 16:9 widescreen.`,
          motionPrompt: `Joyful celebration jump, colorful confetti sparkles descending gracefully as character laughs happily.`,
          interactiveQuestion: null,
        },
      ],
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Lỗi khi tạo kịch bản' });
  }
});

// 4. Character Library API
app.get('/api/characters', (req: Request, res: Response) => {
  res.json(memoryDb.characters);
});

app.post('/api/characters', (req: Request, res: Response) => {
  const { name, role, age, gender, appearance, outfit, personality, voiceStyle } = req.body;
  if (!name) {
    res.status(400).json({ error: 'Tên nhân vật không được để trống' });
    return;
  }
  const newChar = {
    id: `char-custom-${Date.now()}`,
    name,
    role: role || 'Học sinh lớp 2',
    age: age || 7,
    gender: gender || 'Nữ',
    appearance: appearance || 'Đáng yêu, hoạt hình 3D',
    outfit: outfit || 'Trang phục học sinh thanh lịch',
    personality: personality || 'Vui vẻ, yêu thích môn Toán',
    voiceStyle: voiceStyle || 'Giọng tiếng Việt thiếu nhi trong trẻo',
    isPreset: false,
  };
  memoryDb.characters.push(newChar);
  res.json(newChar);
});

// Dynamic 3D Scene Visual Generator for elementary math
function createBespokeSceneSvg(sceneNumber: number, prompt: string): string {
  const isScene1 = Number(sceneNumber) === 1;
  const isScene2 = Number(sceneNumber) === 2;
  const isScene3 = Number(sceneNumber) === 3;
  const title = isScene1 ? 'Cảnh 1: Khởi đầu bài toán' : isScene2 ? 'Cảnh 2: Tình huống phát sinh & Câu hỏi' : 'Cảnh 3: Hoàn thành & Đáp số trọn vẹn';
  const badge = isScene1 ? 'Dữ kiện 1' : isScene2 ? 'Thử thách tư duy' : 'Đáp số chuẩn';
  const bgGrad1 = isScene1 ? '#38bdf8' : isScene2 ? '#f59e0b' : '#10b981';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${bgGrad1}" />
        <stop offset="65%" stop-color="#fef3c7" />
        <stop offset="100%" stop-color="#78350f" />
      </linearGradient>
      <linearGradient id="table" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#d97706" />
        <stop offset="100%" stop-color="#78350f" />
      </linearGradient>
      <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
        <feDropShadow dx="0" dy="6" stdDeviation="10" flood-color="#000000" flood-opacity="0.3" />
      </filter>
    </defs>
    <rect width="1280" height="720" fill="url(#bg)" />
    <!-- Sunlight glow -->
    <circle cx="160" cy="120" r="140" fill="#fef08a" opacity="0.45" />
    <circle cx="160" cy="120" r="60" fill="#ffffff" opacity="0.6" />
    <!-- Arched kitchen window -->
    <g transform="translate(980, 80)">
      <path d="M 0 160 A 80 80 0 0 1 160 160 L 160 220 L 0 220 Z" fill="#bae6fd" opacity="0.85" stroke="#78350f" stroke-width="8" />
      <line x1="80" y1="80" x2="80" y2="220" stroke="#78350f" stroke-width="5" />
      <line x1="0" y1="160" x2="160" y2="160" stroke="#78350f" stroke-width="5" />
    </g>
    <!-- Warm table surface -->
    <path d="M 0 460 L 1280 460 L 1280 720 L 0 720 Z" fill="url(#table)" />
    <rect x="0" y="460" width="1280" height="14" fill="#fde68a" opacity="0.4" />
    <ellipse cx="640" cy="540" rx="340" ry="24" fill="#000000" opacity="0.25" />
    <!-- Character representation (Bé Lan) -->
    <g transform="translate(240, 240)" filter="url(#shadow)">
      <ellipse cx="50" cy="90" rx="26" ry="40" fill="#451a03" transform="rotate(-20 50 90)" />
      <ellipse cx="170" cy="90" rx="26" ry="40" fill="#451a03" transform="rotate(20 170 90)" />
      <circle cx="68" cy="88" r="10" fill="#dc2626" />
      <circle cx="152" cy="88" r="10" fill="#dc2626" />
      <circle cx="110" cy="110" r="58" fill="#ffedd5" stroke="#fcd34d" stroke-width="4" />
      <path d="M 54 90 Q 110 130 166 90 Q 110 50 54 90 Z" fill="#451a03" />
      <ellipse cx="90" cy="112" rx="9" ry="14" fill="#0f172a" />
      <circle cx="94" cy="107" r="4" fill="#ffffff" />
      <ellipse cx="130" cy="112" rx="9" ry="14" fill="#0f172a" />
      <circle cx="134" cy="107" r="4" fill="#ffffff" />
      <circle cx="80" cy="128" r="8" fill="#fda4af" opacity="0.8" />
      <circle cx="140" cy="128" r="8" fill="#fda4af" opacity="0.8" />
      <path d="M 98 132 Q 110 144 122 132" fill="none" stroke="#e11d48" stroke-width="4" stroke-linecap="round" />
      <!-- Cute Peter-Pan collar with no text inside character -->
      <path d="M 88 165 Q 98 178 110 168 Q 122 178 132 165 Z" fill="#ffffff" stroke="#fcd34d" stroke-width="2" />
      <circle cx="110" cy="190" r="3" fill="#ffffff" />
      <circle cx="110" cy="210" r="3" fill="#ffffff" />
    </g>
    <!-- Center basket of items -->
    <g transform="translate(640, 480)" filter="url(#shadow)">
      <path d="M -160 0 Q -180 80 -120 110 Q 0 130 120 110 Q 180 80 160 0 Z" fill="#78350f" stroke="#451a03" stroke-width="6" />
      <ellipse cx="0" cy="0" rx="160" ry="24" fill="#92400e" stroke="#451a03" stroke-width="5" />
      ${Array.from({ length: isScene1 ? 14 : isScene2 ? 20 : 26 }).map((_, i) => {
        const cx = -110 + (i % 6) * 44 + ((i / 6) % 2) * 20;
        const cy = -35 + Math.floor(i / 6) * 30;
        return `<circle cx="${cx}" cy="${cy}" r="18" fill="#f97316" stroke="#c2410c" stroke-width="2" />
                <circle cx="${cx - 5}" cy="${cy - 5}" r="5" fill="#fef08a" opacity="0.8" />`;
      }).join('')}
    </g>
    <!-- Top badge -->
    <g transform="translate(50, 40)" filter="url(#shadow)">
      <rect x="0" y="0" width="400" height="52" rx="26" fill="#0f172a" opacity="0.92" stroke="#f59e0b" stroke-width="3" />
      <text x="30" y="33" font-family="sans-serif" font-size="18" font-weight="900" fill="#fef08a">3D PIXAR: CẢNH ${sceneNumber}</text>
      <text x="220" y="33" font-family="sans-serif" font-size="14" font-weight="700" fill="#ffffff">• ${badge}</text>
    </g>
    <!-- Title banner at bottom -->
    <g transform="translate(140, 630)" filter="url(#shadow)">
      <rect x="0" y="0" width="1000" height="60" rx="18" fill="#0f172a" opacity="0.92" stroke="#ffffff" stroke-width="2" />
      <text x="500" y="38" font-family="sans-serif" font-size="20" font-weight="900" fill="#fef08a" text-anchor="middle">🎨 ${title}</text>
    </g>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// 5. Image Studio API
app.post('/api/images/generate', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  try {
    const { prompt, aspectRatio = '16:9', characterId, sceneNumber = 1 } = req.body;
    const dynamicFallback = createBespokeSceneSvg(Number(sceneNumber), prompt || '');

    // Check if Gemini / Imagen image generation is available
    if (aiClient) {
      try {
        const response = await aiClient.models.generateImages({
          model: 'imagen-3.0-generate-002',
          prompt: `High quality children educational 3D cute Pixar cartoon style illustration for elementary school: ${prompt}`,
          config: {
            numberOfImages: 1,
            aspectRatio: aspectRatio as any,
          },
        });

        const imgBytes = response.generatedImages?.[0]?.image?.imageBytes;
        if (imgBytes) {
          res.status(200).json({
            success: true,
            imageUrl: `data:image/png;base64,${imgBytes}`,
            source: 'imagen-3.0-generate-002',
          });
          return;
        }
      } catch (imgErr: any) {
        console.warn('Image generation via Imagen notice (using high quality 3D SVG scene):', imgErr?.message);
      }
    }

    res.status(200).json({
      success: true,
      imageUrl: dynamicFallback,
      isFallback3D: true,
      source: 'preset-3d-bespoke',
      recommendation: 'Đã tạo tranh 3D hoạt hình Pixar sắc nét cho cảnh này.',
    });
  } catch (err: any) {
    console.error('Error in /api/images/generate:', err);
    res.status(200).json({
      success: true,
      imageUrl: createBespokeSceneSvg(Number(req.body?.sceneNumber || 1), ''),
      isFallback3D: true,
      error: err?.message,
    });
  }
});

function getVoiceForCharacter(characterName: string = '', dialogue: string = '', explicitVoice?: string): string {
  if (explicitVoice && explicitVoice !== 'Kore') return explicitVoice;
  const name = (characterName || '').toLowerCase();
  const text = (dialogue || '').toLowerCase();

  // Child female (Bé Lan, bạn nữ, Lan) -> Aoede (youthful girl/child)
  if (name.includes('lan') || name.includes('bé gái') || name.includes('minh anh') || name.includes('bé lan')) {
    return 'Aoede';
  }
  // Child male (Bé Minh, bạn Nam, Nam, Minh) -> Puck (youthful boy/child)
  if (name.includes('minh') || name.includes('nam') || name.includes('bé trai') || name.includes('bảo nam')) {
    return 'Puck';
  }
  // Adult female (Mẹ, Cô giáo, Cô Hương) -> Kore (gentle mother/teacher)
  if (name.includes('mẹ') || name.includes('cô') || name.includes('mẹ lan') || name.includes('cô giáo')) {
    return 'Kore';
  }
  // Adult male (Bác An, Bố, Thầy giáo) -> Fenrir (warm adult male)
  if (name.includes('bác') || name.includes('bố') || name.includes('thầy') || name.includes('chú')) {
    return 'Fenrir';
  }
  // Detect from dialogue text
  if (text.includes('dạ, con') || text.includes('con tính ra') || text.includes('mình đã hái') || text.includes('mình có')) {
    return 'Aoede';
  }
  if (text.includes('mẹ cho') || text.includes('đố con') || text.includes('các em')) {
    return 'Kore';
  }
  return 'Aoede'; // Default to child voice for elementary students
}

// 6. Speech / TTS API
app.post('/api/audio/tts', async (req: Request, res: Response) => {
  try {
    const { text, voice, characterName = '' } = req.body;
    if (!text) {
      res.status(400).json({ error: 'Thiếu nội dung lời thoại' });
      return;
    }

    const cleanText = text.trim();
    const resolvedVoice = getVoiceForCharacter(characterName, cleanText, voice);

    if (aiClient) {
      try {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [{ text: cleanText }], // PURE DIALOGUE ONLY! Never prepend "Nói bằng tiếng Việt..."
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: resolvedVoice as any },
              },
            },
          },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          res.json({
            success: true,
            audioUrl: `data:audio/wav;base64,${base64Audio}`,
            voiceUsed: resolvedVoice,
            source: 'gemini-3.8-flash-lite-tts',
          });
          return;
        }
      } catch (ttsErr: any) {
        console.warn('TTS API notice (switching to client speech engine):', ttsErr?.message);
        res.status(200).json({
          success: false,
          fallbackSpeech: true,
          voiceUsed: resolvedVoice,
          recommendation: 'Hệ thống tự động sử dụng giọng đọc tự nhiên chuẩn lứa tuổi trên trình duyệt.',
        });
        return;
      }
    }

    res.status(200).json({
      success: false,
      fallbackSpeech: true,
      voiceUsed: resolvedVoice,
      recommendation: 'Giáo viên có thể sử dụng giọng đọc tự nhiên hoặc ghi âm trực tiếp.',
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Lỗi xử lý âm thanh' });
  }
});

// 7. Video API & Google Flow Workflow Integration
app.post('/api/video/generate', async (req: Request, res: Response) => {
  // Google Flow / Veo export endpoint
  const { prompt, startImageUrl, sceneNumber, durationSeconds } = req.body;

  res.json({
    supported: false,
    message: 'Tài khoản hiện tại chưa mở trực tiếp API Veo/Omni Flash video endpoint.',
    flowInstructions: {
      step1: 'Nhấn nút "Sao chép Prompt sang Google Flow" bên dưới.',
      step2: 'Tải ảnh đại diện cảnh về máy tính (nếu có).',
      step3: 'Truy cập Google Flow (hoặc VideoFX), dán ảnh làm Start Frame và dán Prompt chuyển động.',
      step4: 'Tải clip MP4 về máy và tải lên MATH STORY AI để ghép nối kịch bản hoàn chỉnh.',
    },
    promptExport: prompt,
    startImageUrl,
    sceneNumber,
  });
});

// 8. Projects & Lessons CRUD
app.get('/api/projects', (req: Request, res: Response) => {
  res.json(memoryDb.projects);
});

app.get('/api/projects/:id', (req: Request, res: Response) => {
  const project = memoryDb.projects.find(p => p.id === req.params.id);
  if (!project) {
    res.status(404).json({ error: 'Không tìm thấy học liệu' });
    return;
  }
  res.json(project);
});

app.post('/api/projects', (req: Request, res: Response) => {
  const newProject = {
    ...req.body,
    id: req.body.id || `project-${Date.now()}`,
    createdAt: new Date().toISOString(),
    isSample: false,
  };
  memoryDb.projects.unshift(newProject);
  res.json(newProject);
});

app.put('/api/projects/:id', (req: Request, res: Response) => {
  // Protect canonical demo sample project: never overwrite or mutate the DEMO
  if (req.params.id === 'project-cam-sample' || (req.body && req.body.isSample)) {
    const demo = memoryDb.projects.find(p => p.id === 'project-cam-sample');
    res.json(demo || req.body);
    return;
  }
  const index = memoryDb.projects.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Không tìm thấy học liệu' });
    return;
  }
  memoryDb.projects[index] = {
    ...memoryDb.projects[index],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  res.json(memoryDb.projects[index]);
});

// 9. Interactive Submissions & Learning Analytics
app.get('/api/submissions', (req: Request, res: Response) => {
  const { projectId } = req.query;
  if (projectId) {
    res.json(memoryDb.submissions.filter(s => s.projectId === projectId));
    return;
  }
  res.json(memoryDb.submissions);
});

app.post('/api/submissions', (req: Request, res: Response) => {
  const { projectId, studentCode, studentName, chosenOption, isCorrect, attemptCount, timeTakenSeconds, errorType, isDemo } = req.body;
  const submission = {
    id: `sub-${Date.now()}`,
    projectId: projectId || 'project-cam-sample',
    studentCode: studentCode || 'HS-ANONYMOUS',
    studentName: studentName || 'Học sinh',
    chosenOption,
    isCorrect,
    attemptCount: attemptCount || 1,
    timeTakenSeconds: timeTakenSeconds || 10,
    errorType: errorType || (isCorrect ? 'KHÔNG_CÓ' : 'SAI_LỰA_CHỌN_PHÉP_TÍNH'),
    isDemo: Boolean(isDemo),
    timestamp: new Date().toISOString(),
  };
  memoryDb.submissions.unshift(submission);
  res.json({ success: true, submission });
});

// 10. Summary Reports & Error Distribution
app.get('/api/reports/summary', (req: Request, res: Response) => {
  const totalSubmissions = memoryDb.submissions.length;
  const correctCount = memoryDb.submissions.filter(s => s.isCorrect).length;
  const accuracyRate = totalSubmissions > 0 ? Math.round((correctCount / totalSubmissions) * 100) : 0;

  const errorTypes = {
    SAI_DỮ_KIỆN: 0,
    SAI_LỰA_CHỌN_PHÉP_TÍNH: 0,
    SAI_TÍNH_TOÁN: 0,
    SAI_ĐƠN_VỊ: 0,
    CHƯA_HIỂU_TÌNH_HUỐNG: 0,
  };

  memoryDb.submissions.forEach(sub => {
    if (!sub.isCorrect && (sub.errorType in errorTypes)) {
      (errorTypes as any)[sub.errorType]++;
    }
  });

  res.json({
    totalProjects: memoryDb.projects.length,
    publishedProjects: memoryDb.projects.filter(p => p.moderationChecklist?.status === 'ĐÃ_XUẤT_BẢN').length,
    totalSubmissions,
    accuracyRate,
    errorDistribution: errorTypes,
    recentSubmissions: memoryDb.submissions.slice(0, 10),
  });
});

// Catch-all for API routes to never return HTML
app.all('/api/*', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(404).json({
    success: false,
    error: `API route not found: ${req.method} ${req.path}`,
  });
});

// Vite middleware integration
async function start() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`MATH STORY AI Server running at http://0.0.0.0:${PORT}`);
    initializeDemoProjectTts().catch((err) => {
      console.warn('Initial Demo TTS generation warning:', err?.message);
    });
  });
}

// Background startup helper: Pre-generate Gemini TTS audio for the demo project scenes
async function initializeDemoProjectTts() {
  const project = memoryDb.projects.find((p) => p.id === 'project-cam-sample');
  if (!project || !project.storyboard?.scenes) return;

  // Enforce correct addition dialogues on the demo project scenes
  const canonicalDialogues = [
    {
      sceneNumber: 1,
      dialogue: 'A, sáng nay mình đã hái được 25 quả cam vàng ươm rồi này! Cam thơm quá!',
      character: 'Bé Lan',
      voice: 'Aoede', // Child voice
    },
    {
      sceneNumber: 2,
      dialogue: 'Lan ngoan lắm! Mẹ cho con thêm 17 quả cam nữa nhé! Đố con biết bây giờ con có tất cả bao nhiêu quả cam?',
      character: 'Mẹ',
      voice: 'Kore', // Mother voice
    },
    {
      sceneNumber: 3,
      dialogue: 'Dạ, con tính ra rồi ạ! 25 cộng 17 bằng 42 quả cam! Con có tất cả 42 quả cam ạ!',
      character: 'Bé Lan',
      voice: 'Aoede', // Child voice
    },
  ];

  // Update scenes to match canonical addition problem and clear any old audio with instruction prefixes
  project.storyboard.scenes.forEach((s: any) => {
    const canon = canonicalDialogues.find((c) => c.sceneNumber === s.sceneNumber);
    if (canon) {
      s.dialogue = canon.dialogue;
      s.characters = [canon.character];
      // Reset audioUrl so we don't keep old subtraction or prompt audio
      s.audioUrl = '';
    }
  });

  if (!aiClient) return;

  for (const canon of canonicalDialogues) {
    const scene = project.storyboard.scenes.find((s: any) => s.sceneNumber === canon.sceneNumber);
    if (!scene) continue;

    try {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [{ text: canon.dialogue.trim() }], // Pure text only, no instruction prefix!
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: canon.voice as any },
            },
          },
        },
      });
      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        scene.audioUrl = `data:audio/wav;base64,${base64Audio}`;
        console.log(`Demo Scene ${scene.sceneNumber} (${canon.character} - ${canon.voice}) Gemini TTS generated successfully.`);
      }
    } catch (err: any) {
      console.warn(`TTS generation notice for demo scene ${scene.sceneNumber} (${canon.character}):`, err?.message);
      // Leave scene.audioUrl empty so player uses browser speech synthesis with child pitch
      scene.audioUrl = '';
    }
  }
}

start().catch(err => {
  console.error('Failed to start server:', err);
});
