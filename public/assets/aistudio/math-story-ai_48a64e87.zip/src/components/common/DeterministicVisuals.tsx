import React from 'react';

// 1. Exact Item Counter with Groups of 10 and Single Units
export const OrangeCounterVisual: React.FC<{
  count: number;
  label?: string;
  unit?: string;
  icon?: string;
}> = ({ count, label, unit = 'quả cam', icon }) => {
  const tens = Math.floor(count / 10);
  const units = count % 10;

  // Auto-detect item icon if not explicitly provided
  let displayIcon = icon;
  if (!displayIcon) {
    const u = unit.toLowerCase();
    if (u.includes('gà')) displayIcon = '🐔';
    else if (u.includes('trứng')) displayIcon = '🥚';
    else if (u.includes('cây')) displayIcon = '🌳';
    else if (u.includes('hoa')) displayIcon = '🌸';
    else if (u.includes('bi')) displayIcon = '🔵';
    else if (u.includes('táo')) displayIcon = '🍎';
    else if (u.includes('sách') || u.includes('vở')) displayIcon = '📚';
    else displayIcon = '🍊';
  }

  return (
    <div className="bg-amber-50/90 border-2 border-amber-300 rounded-2xl p-4 shadow-sm flex flex-col items-center">
      <div className="flex items-center gap-2 mb-3">
        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-amber-500 text-white font-bold text-sm shadow">
          {count}
        </span>
        <h4 className="font-bold text-amber-900 text-base">{label || `Trực quan xác định: ${count} ${unit}`}</h4>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-4 w-full">
        {/* Tens baskets */}
        {Array.from({ length: tens }).map((_, tIdx) => (
          <div key={`ten-${tIdx}`} className="bg-amber-100 border border-amber-400 rounded-xl p-2.5 flex flex-col items-center shadow-xs">
            <span className="text-xs font-bold text-amber-800 bg-amber-200 px-2 py-0.5 rounded-full mb-1">
              1 Chục (10 {unit})
            </span>
            <div className="grid grid-cols-5 gap-1 bg-white/70 p-1.5 rounded-lg border border-amber-200">
              {Array.from({ length: 10 }).map((_, i) => (
                <div
                  key={i}
                  className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 border border-amber-600 flex items-center justify-center shadow-xs text-[9px] text-white font-bold"
                  title={`1 ${unit}`}
                >
                  {displayIcon}
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Units basket */}
        {units > 0 && (
          <div className="bg-orange-100 border border-orange-400 rounded-xl p-2.5 flex flex-col items-center shadow-xs">
            <span className="text-xs font-bold text-orange-800 bg-orange-200 px-2 py-0.5 rounded-full mb-1">
              {units} Đơn vị rời
            </span>
            <div className="flex flex-wrap gap-1.5 bg-white/70 p-2 rounded-lg border border-orange-200 max-w-[140px] justify-center">
              {Array.from({ length: units }).map((_, i) => (
                <div
                  key={i}
                  className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 border border-amber-600 flex items-center justify-center shadow-xs text-[9px]"
                  title={`1 ${unit} rời`}
                >
                  {displayIcon}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <p className="mt-2.5 text-xs text-amber-700 text-center font-medium">
        Lớp trực quan xác định bằng thuật toán: {tens > 0 ? `${tens} chục` : ''} {units > 0 ? `và ${units} đơn vị` : ''} {unit} (chính xác 100%, không bị sai số đồ họa)
      </p>
    </div>
  );
};

// 2. Base-10 Blocks (Thanh chục và khối đơn vị SGK Toán 2)
export const BaseTenBlocksVisual: React.FC<{ num1: number; num2: number; operation: string }> = ({
  num1,
  num2,
  operation,
}) => {
  const tens1 = Math.floor(num1 / 10);
  const units1 = num1 % 10;
  const tens2 = Math.floor(num2 / 10);
  const units2 = num2 % 10;

  return (
    <div className="bg-indigo-50/90 border-2 border-indigo-200 rounded-2xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3 border-b border-indigo-100 pb-2">
        <h4 className="font-bold text-indigo-900 text-sm flex items-center gap-2">
          <span className="p-1 rounded bg-indigo-600 text-white text-xs">Trực quan</span>
          Thanh Chục & Khối Đơn Vị (SGK GDPT 2018)
        </h4>
        <span className="text-xs bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded-md font-mono font-bold">
          {num1} {operation === 'TRỪ' ? '-' : '+'} {num2}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Number 1 */}
        <div className="bg-white p-3 rounded-xl border border-indigo-100">
          <p className="text-xs font-bold text-indigo-700 mb-2">Số thứ nhất: {num1} ({tens1} chục, {units1} đơn vị)</p>
          <div className="flex items-end gap-2">
            <div className="flex gap-1.5">
              {Array.from({ length: tens1 }).map((_, i) => (
                <div key={i} className="flex flex-col gap-0.5 p-1 bg-blue-100 rounded border border-blue-400" title="Thanh 10">
                  {Array.from({ length: 10 }).map((_, j) => (
                    <div key={j} className="w-3.5 h-1.5 bg-blue-500 rounded-xs" />
                  ))}
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-1 max-w-[80px] p-1 bg-sky-50 rounded border border-sky-300">
              {Array.from({ length: units1 }).map((_, i) => (
                <div key={i} className="w-3.5 h-3.5 bg-sky-500 rounded-xs border border-sky-600" title="1 đơn vị" />
              ))}
            </div>
          </div>
        </div>

        {/* Number 2 */}
        <div className="bg-white p-3 rounded-xl border border-indigo-100">
          <p className="text-xs font-bold text-indigo-700 mb-2">Số thứ hai: {num2} ({tens2} chục, {units2} đơn vị)</p>
          <div className="flex items-end gap-2">
            <div className="flex gap-1.5">
              {Array.from({ length: tens2 }).map((_, i) => (
                <div key={i} className="flex flex-col gap-0.5 p-1 bg-emerald-100 rounded border border-emerald-400" title="Thanh 10">
                  {Array.from({ length: 10 }).map((_, j) => (
                    <div key={j} className="w-3.5 h-1.5 bg-emerald-500 rounded-xs" />
                  ))}
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-1 max-w-[80px] p-1 bg-teal-50 rounded border border-teal-300">
              {Array.from({ length: units2 }).map((_, i) => (
                <div key={i} className="w-3.5 h-3.5 bg-teal-500 rounded-xs border border-teal-600" title="1 đơn vị" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// 3. SVG Analog Clock with deterministic hour and minute hands
export const ClockVisual: React.FC<{ hours: number; minutes: number }> = ({ hours, minutes }) => {
  const minuteAngle = (minutes / 60) * 360;
  const hourAngle = ((hours % 12) / 12) * 360 + (minutes / 60) * 30;

  return (
    <div className="flex flex-col items-center p-3 bg-cyan-50 border border-cyan-200 rounded-2xl">
      <svg width="140" height="140" viewBox="0 0 140 140" className="drop-shadow-sm">
        <circle cx="70" cy="70" r="64" fill="#ffffff" stroke="#0891b2" strokeWidth="6" />
        {/* Clock marks */}
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => {
          const angle = (num / 12) * 2 * Math.PI - Math.PI / 2;
          const x = 70 + 48 * Math.cos(angle);
          const y = 70 + 48 * Math.sin(angle) + 4;
          return (
            <text
              key={num}
              x={x}
              y={y}
              fontSize="12"
              fontWeight="bold"
              fill="#0f172a"
              textAnchor="middle"
            >
              {num}
            </text>
          );
        })}
        {/* Hour hand */}
        <line
          x1="70"
          y1="70"
          x2={70 + 30 * Math.sin((hourAngle * Math.PI) / 180)}
          y2={70 - 30 * Math.cos((hourAngle * Math.PI) / 180)}
          stroke="#ef4444"
          strokeWidth="4"
          strokeLinecap="round"
        />
        {/* Minute hand */}
        <line
          x1="70"
          y1="70"
          x2={70 + 42 * Math.sin((minuteAngle * Math.PI) / 180)}
          y2={70 - 42 * Math.cos((minuteAngle * Math.PI) / 180)}
          stroke="#0284c7"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <circle cx="70" cy="70" r="4" fill="#0f172a" />
      </svg>
      <span className="mt-2 text-xs font-bold text-cyan-900 bg-cyan-100 px-3 py-1 rounded-full">
        Đồng hồ chỉ: {hours} giờ {minutes > 0 ? `${minutes} phút` : 'đúng'}
      </span>
    </div>
  );
};
