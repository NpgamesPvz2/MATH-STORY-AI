import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Play,
  Upload,
  Volume2,
  Sparkles,
  CheckCircle2,
  Music,
  Trash2,
  ArrowRight,
  Layers,
  Wand2,
} from 'lucide-react';
import { Storyboard } from '../../types/mathStory';
import { requestTTS } from '../../services/api';
import { soundEffects } from '../../utils/audioEffects';

interface AudioStudioProps {
  storyboard: Storyboard | null;
  onSceneAudioUpdated: (sceneNumber: number, audioUrl: string) => void;
  onBackgroundMusicUpdated?: (bgMusic: string, bgVolume: number) => void;
  onGoToInteractivePlayer: () => void;
}

export const AudioStudio: React.FC<AudioStudioProps> = ({
  storyboard,
  onSceneAudioUpdated,
  onBackgroundMusicUpdated,
  onGoToInteractivePlayer,
}) => {
  const [viewMode, setViewMode] = useState<'all-3-scenes' | 'single-scene'>('all-3-scenes');
  const [selectedSceneNumber, setSelectedSceneNumber] = useState<number>(1);

  // Recording state per active scene
  const [recordingSceneNumber, setRecordingSceneNumber] = useState<number | null>(null);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);

  // TTS loading state per scene
  const [ttsLoadingScene, setTtsLoadingScene] = useState<Record<number, boolean>>({});
  const [ttsStatusScene, setTtsStatusScene] = useState<Record<number, string>>({});
  const [isGeneratingAll, setIsGeneratingAll] = useState<boolean>(false);

  // Background music state
  const [bgMusic, setBgMusic] = useState<string>(storyboard?.bgMusic || 'vui-tuoi');
  const [bgVolume, setBgVolume] = useState<number>(storyboard?.bgVolume ?? 25);
  const [isPlayingMusicPreview, setIsPlayingMusicPreview] = useState<boolean>(false);

  // Voice preference per scene
  const [voiceScene1, setVoiceScene1] = useState<string>('auto');
  const [voiceScene2, setVoiceScene2] = useState<string>('auto');
  const [voiceScene3, setVoiceScene3] = useState<string>('auto');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  // Sync background music state when storyboard changes
  useEffect(() => {
    if (storyboard?.bgMusic) setBgMusic(storyboard.bgMusic);
    if (storyboard?.bgVolume !== undefined) setBgVolume(storyboard.bgVolume);
  }, [storyboard?.bgMusic, storyboard?.bgVolume]);

  const handleMusicChange = (newMusic: string) => {
    setBgMusic(newMusic);
    onBackgroundMusicUpdated?.(newMusic, bgVolume);
    if (isPlayingMusicPreview) {
      soundEffects.startBackgroundMusic(newMusic, bgVolume);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setBgVolume(newVol);
    onBackgroundMusicUpdated?.(bgMusic, newVol);
    if (isPlayingMusicPreview) {
      soundEffects.setBackgroundMusicVolume(newVol);
    }
  };

  const toggleMusicPreview = () => {
    if (isPlayingMusicPreview) {
      soundEffects.stopBackgroundMusic();
      setIsPlayingMusicPreview(false);
    } else {
      soundEffects.startBackgroundMusic(bgMusic, bgVolume);
      setIsPlayingMusicPreview(true);
    }
  };

  // Clean up music preview and recording when leaving
  useEffect(() => {
    return () => {
      soundEffects.stopBackgroundMusic();
      if (timerRef.current) clearInterval(timerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const scenes = storyboard?.scenes || [];
  const scene1 = scenes.find((s) => s.sceneNumber === 1) || scenes[0];
  const scene2 = scenes.find((s) => s.sceneNumber === 2) || scenes[1];
  const scene3 = scenes.find((s) => s.sceneNumber === 3) || scenes[2];

  // Universal recording engine for any scene
  const startRecordingForScene = async (sceneNumber: number) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        onSceneAudioUpdated(sceneNumber, audioUrl);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecordingSceneNumber(sceneNumber);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      alert('Không thể mở micro: ' + err.message + '. Vui lòng cấp quyền micro trên trình duyệt.');
    }
  };

  const stopRecordingForScene = () => {
    if (mediaRecorderRef.current && recordingSceneNumber !== null) {
      mediaRecorderRef.current.stop();
      setRecordingSceneNumber(null);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleFileUploadForScene = (sceneNumber: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    onSceneAudioUpdated(sceneNumber, url);
  };

  // ==========================================
  // CODE TẠO ÂM THANH CẢNH 1
  // ==========================================
  const handleGenerateAudioScene1 = async () => {
    if (!scene1) return;
    setTtsLoadingScene((prev) => ({ ...prev, 1: true }));
    setTtsStatusScene((prev) => ({ ...prev, 1: 'Đang gửi yêu cầu tạo giọng đọc AI Cảnh 1...' }));

    try {
      const charName = scene1.characters?.[0] || 'Bé Lan';
      const voiceToRequest = voiceScene1 === 'auto' ? undefined : voiceScene1;
      const res = await requestTTS(scene1.dialogue, voiceToRequest, charName);

      if (res.success && res.audioUrl) {
        onSceneAudioUpdated(1, res.audioUrl);
        setTtsStatusScene((prev) => ({
          ...prev,
          1: `✨ Đã nhận file âm thanh AI Cảnh 1 (${res.voiceUsed || 'Gemini TTS'})! Bấm nút Play bên dưới để nghe thử.`,
        }));
      } else {
        // Chưa nhận được file âm thanh: Không tự động phát file âm thanh sẵn có hay Web Speech
        setTtsStatusScene((prev) => ({
          ...prev,
          1: '⚠️ Chưa nhận được file âm thanh từ AI. Hệ thống không tự động phát file âm thanh sẵn có.',
        }));
      }
    } catch (err: any) {
      setTtsStatusScene((prev) => ({
        ...prev,
        1: `⚠️ Chưa nhận được file âm thanh (${err.message || 'Lỗi kết nối'}). Không tự động phát âm thanh sẵn có.`,
      }));
    } finally {
      setTtsLoadingScene((prev) => ({ ...prev, 1: false }));
    }
  };

  // ==========================================
  // CODE TẠO ÂM THANH CẢNH 2 (Sao chép từ Cảnh 1 & chỉnh sửa tương ứng)
  // ==========================================
  const handleGenerateAudioScene2 = async () => {
    if (!scene2) return;
    setTtsLoadingScene((prev) => ({ ...prev, 2: true }));
    setTtsStatusScene((prev) => ({ ...prev, 2: 'Đang gửi yêu cầu tạo giọng đọc AI Cảnh 2...' }));

    try {
      const charName = scene2.characters?.[0] || 'Bé Lan';
      const voiceToRequest = voiceScene2 === 'auto' ? undefined : voiceScene2;
      const res = await requestTTS(scene2.dialogue, voiceToRequest, charName);

      if (res.success && res.audioUrl) {
        onSceneAudioUpdated(2, res.audioUrl);
        setTtsStatusScene((prev) => ({
          ...prev,
          2: `✨ Đã nhận file âm thanh AI Cảnh 2 (${res.voiceUsed || 'Gemini TTS'})! Bấm nút Play bên dưới để nghe thử.`,
        }));
      } else {
        // Chưa nhận được file âm thanh: Không tự động phát file âm thanh sẵn có hay Web Speech
        setTtsStatusScene((prev) => ({
          ...prev,
          2: '⚠️ Chưa nhận được file âm thanh từ AI. Hệ thống không tự động phát file âm thanh sẵn có.',
        }));
      }
    } catch (err: any) {
      setTtsStatusScene((prev) => ({
        ...prev,
        2: `⚠️ Chưa nhận được file âm thanh (${err.message || 'Lỗi kết nối'}). Không tự động phát âm thanh sẵn có.`,
      }));
    } finally {
      setTtsLoadingScene((prev) => ({ ...prev, 2: false }));
    }
  };

  // ==========================================
  // CODE TẠO ÂM THANH CẢNH 3 (Sao chép từ Cảnh 1 & chỉnh sửa tương ứng)
  // ==========================================
  const handleGenerateAudioScene3 = async () => {
    if (!scene3) return;
    setTtsLoadingScene((prev) => ({ ...prev, 3: true }));
    setTtsStatusScene((prev) => ({ ...prev, 3: 'Đang gửi yêu cầu tạo giọng đọc AI Cảnh 3...' }));

    try {
      const charName = scene3.characters?.[0] || 'Bé Lan';
      const voiceToRequest = voiceScene3 === 'auto' ? undefined : voiceScene3;
      const res = await requestTTS(scene3.dialogue, voiceToRequest, charName);

      if (res.success && res.audioUrl) {
        onSceneAudioUpdated(3, res.audioUrl);
        setTtsStatusScene((prev) => ({
          ...prev,
          3: `✨ Đã nhận file âm thanh AI Cảnh 3 (${res.voiceUsed || 'Gemini TTS'})! Bấm nút Play bên dưới để nghe thử.`,
        }));
      } else {
        // Chưa nhận được file âm thanh: Không tự động phát file âm thanh sẵn có hay Web Speech
        setTtsStatusScene((prev) => ({
          ...prev,
          3: '⚠️ Chưa nhận được file âm thanh từ AI. Hệ thống không tự động phát file âm thanh sẵn có.',
        }));
      }
    } catch (err: any) {
      setTtsStatusScene((prev) => ({
        ...prev,
        3: `⚠️ Chưa nhận được file âm thanh (${err.message || 'Lỗi kết nối'}). Không tự động phát âm thanh sẵn có.`,
      }));
    } finally {
      setTtsLoadingScene((prev) => ({ ...prev, 3: false }));
    }
  };

  // Batch generate all 3 scenes at once
  const handleGenerateAllScenes = async () => {
    setIsGeneratingAll(true);
    await Promise.all([
      handleGenerateAudioScene1(),
      handleGenerateAudioScene2(),
      handleGenerateAudioScene3(),
    ]);
    setIsGeneratingAll(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-pink-100 text-pink-700">
              <Mic className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 6: Giọng Đọc Sư Phạm & Thu Âm Lời Thoại (Cảnh 1, 2, 3)
            </h2>
            <span className="text-xs bg-pink-100 text-pink-800 font-bold px-2.5 py-0.5 rounded-full">
              Gemini TTS & Micro Thật
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Giáo viên có thể tự thu âm bằng giọng đọc hoặc tạo giọng nói AI chuẩn sư phạm cho từng cảnh (Cảnh 1, Cảnh 2 và Cảnh 3).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateAllScenes}
            disabled={isGeneratingAll}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
          >
            <Wand2 className="w-4 h-4" />
            <span>{isGeneratingAll ? 'Đang tạo cả 3 cảnh...' : '⚡ Tạo AI Cả 3 Cảnh (1 Chạm)'}</span>
          </button>

          <button
            onClick={onGoToInteractivePlayer}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Sang Bài Học Tương Tác</span>
          </button>
        </div>
      </div>

      {/* Global Background Music Setting Card */}
      <div className="bg-white rounded-3xl p-5 border border-pink-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-pink-600" />
            <div>
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">
                Nhạc Nền Hoạt Hình Toàn Dự Án (Đồng bộ Phân hệ 7):
              </h3>
              <p className="text-[11px] text-slate-500">
                Nhạc nền sẽ tự động giảm âm lượng (ducking) êm ái khi nhân vật đọc lời thoại.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">{bgVolume}%</span>
            <button
              type="button"
              onClick={toggleMusicPreview}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                isPlayingMusicPreview
                  ? 'bg-red-500 text-white shadow-xs'
                  : 'bg-pink-100 hover:bg-pink-200 text-pink-900 border border-pink-200'
              }`}
            >
              {isPlayingMusicPreview ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Dừng nghe</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Nghe thử nhạc</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          <select
            value={bgMusic}
            onChange={(e) => handleMusicChange(e.target.value)}
            className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-medium"
          >
            <option value="vui-tuoi">🎵 Vui tươi: Bé tập đếm rộn ràng (C major vui nhộn)</option>
            <option value="diu-dang">🌸 Êm dịu: Vườn trường tuổi thơ (Piano êm dịu)</option>
            <option value="kham-pha">🚀 Khám phá: Vùng đất Toán học (Nhịp điệu phiêu lưu)</option>
            <option value="khong-nhac">🔇 Không phát nhạc nền</option>
          </select>

          <div className="flex items-center gap-3 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
            <span className="text-xs text-slate-600 font-bold whitespace-nowrap">Âm lượng nhạc:</span>
            <input
              type="range"
              min="0"
              max="100"
              value={bgVolume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              className="w-full accent-pink-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* View Mode Toggle: All 3 scenes simultaneously vs Single scene focus */}
      <div className="flex items-center justify-between bg-slate-100 p-1.5 rounded-2xl border border-slate-200 text-xs">
        <span className="font-extrabold text-slate-700 ml-2">
          Trình tạo âm thanh lời thoại:
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setViewMode('all-3-scenes')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              viewMode === 'all-3-scenes'
                ? 'bg-white text-pink-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            📋 Xem Cả 3 Cảnh Cùng Lúc (Cảnh 1, 2, 3)
          </button>
          <button
            onClick={() => setViewMode('single-scene')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              viewMode === 'single-scene'
                ? 'bg-white text-pink-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            🔍 Xem Từng Cảnh
          </button>
        </div>
      </div>

      {storyboard ? (
        <>
          {/* ======================================================== */}
          {/* VIEW MODE 1: ALL 3 SCENES SIMULTANEOUSLY (3-CARD STUDIO) */}
          {/* ======================================================== */}
          {viewMode === 'all-3-scenes' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {/* =================================================== */}
              {/* CARD TẠO ÂM THANH CẢNH 1 */}
              {/* =================================================== */}
              {scene1 && (
                <div className="bg-white rounded-3xl p-5 border-2 border-sky-300 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-xl bg-sky-600 text-white font-black text-xs flex items-center justify-center">
                          1
                        </span>
                        <h3 className="font-black text-slate-900 text-sm">
                          CẢNH 1: {scene1.title.split(':')[1] || scene1.title}
                        </h3>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                        Khởi đầu
                      </span>
                    </div>

                    <div className="bg-sky-50 border border-sky-200 rounded-2xl p-3 space-y-1">
                      <span className="text-[10px] text-sky-800 font-extrabold block">
                        Lời thoại ({scene1.characters.join(', ')}):
                      </span>
                      <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-sky-100">
                        "{scene1.dialogue}"
                      </p>
                    </div>

                    {/* Microphone Recording for Scene 1 */}
                    <div className="p-3 bg-pink-50/70 border border-pink-200 rounded-2xl space-y-2 text-center">
                      <span className="text-[11px] font-extrabold text-pink-900 block">
                        🎤 Thu âm trực tiếp Cảnh 1:
                      </span>
                      {recordingSceneNumber === 1 ? (
                        <div className="space-y-2">
                          <span className="inline-block px-3 py-1 bg-red-100 text-red-700 font-bold text-xs rounded-full animate-pulse">
                            Đang thu Cảnh 1: {recordingDuration}s
                          </span>
                          <button
                            onClick={stopRecordingForScene}
                            className="w-full py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Square className="w-3.5 h-3.5 fill-current" />
                            <span>Dừng & Lưu Lời Thoại Cảnh 1</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => startRecordingForScene(1)}
                          className="w-full py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span>Bấm để thu âm Cảnh 1</span>
                        </button>
                      )}
                    </div>

                    {/* File Upload for Scene 1 */}
                    <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <span className="text-[11px] text-slate-600 font-bold">Tải file mp3/wav:</span>
                      <label className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer text-[11px] flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Chọn file</span>
                        <input
                          type="file"
                          accept="audio/*"
                          className="hidden"
                          onChange={(e) => handleFileUploadForScene(1, e)}
                        />
                      </label>
                    </div>

                    {/* AI Speech TTS for Scene 1 */}
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-purple-600" />
                          <span>Tạo giọng đọc AI Cảnh 1:</span>
                        </span>
                        <select
                          value={voiceScene1}
                          onChange={(e) => setVoiceScene1(e.target.value)}
                          className="text-[10px] p-1 rounded-lg border border-purple-300 bg-white font-semibold text-purple-900"
                        >
                          <option value="auto">Tự động ({scene1.characters[0] || 'Bé Lan'})</option>
                          <option value="Aoede">Bé gái (Aoede)</option>
                          <option value="Puck">Bé trai (Puck)</option>
                          <option value="Kore">Cô giáo (Kore)</option>
                        </select>
                      </div>

                      <button
                        onClick={handleGenerateAudioScene1}
                        disabled={ttsLoadingScene[1]}
                        className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{ttsLoadingScene[1] ? 'Đang tạo audio...' : 'Tạo giọng AI Cảnh 1'}</span>
                      </button>

                      {ttsStatusScene[1] && (
                        <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200">
                          {ttsStatusScene[1]}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Playback preview for Scene 1 */}
                  {scene1.audioUrl && (
                    <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                        <span className="flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Đã có audio Cảnh 1</span>
                        </span>
                        <button
                          onClick={() => onSceneAudioUpdated(1, '')}
                          className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Xóa</span>
                        </button>
                      </div>
                      <audio src={scene1.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                    </div>
                  )}
                </div>
              )}

              {/* =================================================== */}
              {/* CARD TẠO ÂM THANH CẢNH 2 (Sao chép & chỉnh sửa cho Cảnh 2) */}
              {/* =================================================== */}
              {scene2 && (
                <div className="bg-white rounded-3xl p-5 border-2 border-amber-300 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-xl bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center">
                          2
                        </span>
                        <h3 className="font-black text-slate-900 text-sm">
                          CẢNH 2: {scene2.title.split(':')[1] || scene2.title}
                        </h3>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                        Dừng câu hỏi ❓
                      </span>
                    </div>

                    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 space-y-1">
                      <span className="text-[10px] text-amber-800 font-extrabold block">
                        Lời thoại ({scene2.characters.join(', ')}):
                      </span>
                      <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-amber-100">
                        "{scene2.dialogue}"
                      </p>
                    </div>

                    {/* Microphone Recording for Scene 2 */}
                    <div className="p-3 bg-pink-50/70 border border-pink-200 rounded-2xl space-y-2 text-center">
                      <span className="text-[11px] font-extrabold text-pink-900 block">
                        🎤 Thu âm trực tiếp Cảnh 2:
                      </span>
                      {recordingSceneNumber === 2 ? (
                        <div className="space-y-2">
                          <span className="inline-block px-3 py-1 bg-red-100 text-red-700 font-bold text-xs rounded-full animate-pulse">
                            Đang thu Cảnh 2: {recordingDuration}s
                          </span>
                          <button
                            onClick={stopRecordingForScene}
                            className="w-full py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Square className="w-3.5 h-3.5 fill-current" />
                            <span>Dừng & Lưu Lời Thoại Cảnh 2</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => startRecordingForScene(2)}
                          className="w-full py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span>Bấm để thu âm Cảnh 2</span>
                        </button>
                      )}
                    </div>

                    {/* File Upload for Scene 2 */}
                    <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <span className="text-[11px] text-slate-600 font-bold">Tải file mp3/wav:</span>
                      <label className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer text-[11px] flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Chọn file</span>
                        <input
                          type="file"
                          accept="audio/*"
                          className="hidden"
                          onChange={(e) => handleFileUploadForScene(2, e)}
                        />
                      </label>
                    </div>

                    {/* AI Speech TTS for Scene 2 */}
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-purple-600" />
                          <span>Tạo giọng đọc AI Cảnh 2:</span>
                        </span>
                        <select
                          value={voiceScene2}
                          onChange={(e) => setVoiceScene2(e.target.value)}
                          className="text-[10px] p-1 rounded-lg border border-purple-300 bg-white font-semibold text-purple-900"
                        >
                          <option value="auto">Tự động ({scene2.characters[0] || 'Bé Lan'})</option>
                          <option value="Aoede">Bé gái (Aoede)</option>
                          <option value="Puck">Bé trai (Puck)</option>
                          <option value="Kore">Cô giáo (Kore)</option>
                        </select>
                      </div>

                      <button
                        onClick={handleGenerateAudioScene2}
                        disabled={ttsLoadingScene[2]}
                        className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{ttsLoadingScene[2] ? 'Đang tạo audio...' : 'Tạo giọng AI Cảnh 2'}</span>
                      </button>

                      {ttsStatusScene[2] && (
                        <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200">
                          {ttsStatusScene[2]}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Playback preview for Scene 2 */}
                  {scene2.audioUrl && (
                    <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                        <span className="flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Đã có audio Cảnh 2</span>
                        </span>
                        <button
                          onClick={() => onSceneAudioUpdated(2, '')}
                          className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Xóa</span>
                        </button>
                      </div>
                      <audio src={scene2.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                    </div>
                  )}
                </div>
              )}

              {/* =================================================== */}
              {/* CARD TẠO ÂM THANH CẢNH 3 (Sao chép & chỉnh sửa cho Cảnh 3) */}
              {/* =================================================== */}
              {scene3 && (
                <div className="bg-white rounded-3xl p-5 border-2 border-emerald-300 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-xl bg-emerald-600 text-white font-black text-xs flex items-center justify-center">
                          3
                        </span>
                        <h3 className="font-black text-slate-900 text-sm">
                          CẢNH 3: {scene3.title.split(':')[1] || scene3.title}
                        </h3>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        Kết luận đáp án
                      </span>
                    </div>

                    <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 space-y-1">
                      <span className="text-[10px] text-emerald-800 font-extrabold block">
                        Lời thoại ({scene3.characters.join(', ')}):
                      </span>
                      <p className="text-xs font-bold text-slate-800 italic bg-white p-2.5 rounded-xl border border-emerald-100">
                        "{scene3.dialogue}"
                      </p>
                    </div>

                    {/* Microphone Recording for Scene 3 */}
                    <div className="p-3 bg-pink-50/70 border border-pink-200 rounded-2xl space-y-2 text-center">
                      <span className="text-[11px] font-extrabold text-pink-900 block">
                        🎤 Thu âm trực tiếp Cảnh 3:
                      </span>
                      {recordingSceneNumber === 3 ? (
                        <div className="space-y-2">
                          <span className="inline-block px-3 py-1 bg-red-100 text-red-700 font-bold text-xs rounded-full animate-pulse">
                            Đang thu Cảnh 3: {recordingDuration}s
                          </span>
                          <button
                            onClick={stopRecordingForScene}
                            className="w-full py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Square className="w-3.5 h-3.5 fill-current" />
                            <span>Dừng & Lưu Lời Thoại Cảnh 3</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => startRecordingForScene(3)}
                          className="w-full py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span>Bấm để thu âm Cảnh 3</span>
                        </button>
                      )}
                    </div>

                    {/* File Upload for Scene 3 */}
                    <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <span className="text-[11px] text-slate-600 font-bold">Tải file mp3/wav:</span>
                      <label className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer text-[11px] flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Chọn file</span>
                        <input
                          type="file"
                          accept="audio/*"
                          className="hidden"
                          onChange={(e) => handleFileUploadForScene(3, e)}
                        />
                      </label>
                    </div>

                    {/* AI Speech TTS for Scene 3 */}
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-purple-900 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-purple-600" />
                          <span>Tạo giọng đọc AI Cảnh 3:</span>
                        </span>
                        <select
                          value={voiceScene3}
                          onChange={(e) => setVoiceScene3(e.target.value)}
                          className="text-[10px] p-1 rounded-lg border border-purple-300 bg-white font-semibold text-purple-900"
                        >
                          <option value="auto">Tự động ({scene3.characters[0] || 'Bé Lan'})</option>
                          <option value="Aoede">Bé gái (Aoede)</option>
                          <option value="Puck">Bé trai (Puck)</option>
                          <option value="Kore">Cô giáo (Kore)</option>
                        </select>
                      </div>

                      <button
                        onClick={handleGenerateAudioScene3}
                        disabled={ttsLoadingScene[3]}
                        className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{ttsLoadingScene[3] ? 'Đang tạo audio...' : 'Tạo giọng AI Cảnh 3'}</span>
                      </button>

                      {ttsStatusScene[3] && (
                        <p className="text-[10px] text-purple-800 bg-white/70 p-2 rounded-lg border border-purple-200">
                          {ttsStatusScene[3]}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Playback preview for Scene 3 */}
                  {scene3.audioUrl && (
                    <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                        <span className="flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Đã có audio Cảnh 3</span>
                        </span>
                        <button
                          onClick={() => onSceneAudioUpdated(3, '')}
                          className="text-red-600 hover:text-red-800 text-[10px] flex items-center gap-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Xóa</span>
                        </button>
                      </div>
                      <audio src={scene3.audioUrl} controls className="w-full h-8 accent-emerald-600" />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* VIEW MODE 2: SINGLE SCENE DETAIL VIEW */}
          {/* ======================================================== */}
          {viewMode === 'single-scene' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Scene Picker Tab */}
              <div className="lg:col-span-5 space-y-3">
                <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
                  <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
                    Chọn cảnh thu âm:
                  </h3>
                  <div className="space-y-2">
                    {scenes.map((s) => {
                      const isSelected = selectedSceneNumber === s.sceneNumber;
                      const hasAudio = Boolean(s.audioUrl);
                      return (
                        <div
                          key={s.sceneNumber}
                          onClick={() => setSelectedSceneNumber(s.sceneNumber)}
                          className={`p-3 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'border-pink-500 bg-pink-50/70 shadow-xs'
                              : 'border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-800 font-black text-xs flex items-center justify-center">
                              {s.sceneNumber}
                            </span>
                            <div>
                              <h4 className="font-extrabold text-xs text-slate-900">{s.title}</h4>
                              <span className="text-[10px] text-slate-500 line-clamp-1 italic">
                                "{s.dialogue}"
                              </span>
                            </div>
                          </div>

                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              hasAudio
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {hasAudio ? '✓ Đã có' : 'Chưa có'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Detail Scene Creation Box */}
              <div className="lg:col-span-7 space-y-4">
                {(() => {
                  const targetScene = scenes.find((s) => s.sceneNumber === selectedSceneNumber) || scene1;
                  const sceneNum = targetScene?.sceneNumber || 1;
                  const generateHandler =
                    sceneNum === 1
                      ? handleGenerateAudioScene1
                      : sceneNum === 2
                      ? handleGenerateAudioScene2
                      : handleGenerateAudioScene3;

                  return (
                    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-black text-slate-900 text-sm">
                          Tạo âm thanh cho Cảnh {sceneNum}: {targetScene?.title}
                        </h3>
                        <span className="text-xs bg-pink-100 text-pink-900 font-bold px-2.5 py-0.5 rounded-full">
                          Nhân vật: {targetScene?.characters.join(', ')}
                        </span>
                      </div>

                      <div className="bg-sky-50 border border-sky-200 rounded-2xl p-4 space-y-1">
                        <span className="text-xs text-sky-900 font-extrabold block">Lời thoại:</span>
                        <p className="text-sm font-bold text-slate-900 italic bg-white p-3 rounded-xl border border-sky-100">
                          "{targetScene?.dialogue}"
                        </p>
                      </div>

                      {/* Microphone Recording */}
                      <div className="p-4 bg-pink-50/70 border border-pink-200 rounded-2xl space-y-3 text-center">
                        <span className="text-xs font-extrabold text-pink-900 block">
                          🎤 Ghi âm trực tiếp qua Micro cho Cảnh {sceneNum}:
                        </span>
                        {recordingSceneNumber === sceneNum ? (
                          <div className="space-y-2">
                            <span className="inline-block px-3 py-1 bg-red-100 text-red-700 font-bold text-xs rounded-full animate-pulse">
                              Đang thu Cảnh {sceneNum}: {recordingDuration}s
                            </span>
                            <button
                              onClick={stopRecordingForScene}
                              className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow inline-flex items-center gap-1.5 cursor-pointer"
                            >
                              <Square className="w-4 h-4 fill-current" />
                              <span>Dừng & Lưu Lời Thoại Cảnh {sceneNum}</span>
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => startRecordingForScene(sceneNum)}
                            className="px-6 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow inline-flex items-center gap-2 cursor-pointer"
                          >
                            <Mic className="w-4 h-4" />
                            <span>Bắt Đầu Ghi Âm Lời Thoại Cảnh {sceneNum}</span>
                          </button>
                        )}
                      </div>

                      {/* File Upload */}
                      <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
                        <div>
                          <h4 className="font-extrabold text-slate-800">Tải file âm thanh (.mp3, .wav):</h4>
                          <p className="text-[11px] text-slate-500">File giọng đọc thu trước của giáo viên</p>
                        </div>
                        <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer shadow-2xs">
                          <Upload className="w-3.5 h-3.5" />
                          <span>Chọn file</span>
                          <input
                            type="file"
                            accept="audio/*"
                            className="hidden"
                            onChange={(e) => handleFileUploadForScene(sceneNum, e)}
                          />
                        </label>
                      </div>

                      {/* AI Voice TTS */}
                      <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl space-y-3 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-purple-900 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                            <span>Tạo Giọng Nói Bằng AI (Gemini TTS Sư Phạm cho Cảnh {sceneNum}):</span>
                          </span>
                          <button
                            onClick={generateHandler}
                            disabled={ttsLoadingScene[sceneNum]}
                            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold shadow flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>{ttsLoadingScene[sceneNum] ? 'Đang tạo...' : `Tạo giọng AI Cảnh ${sceneNum}`}</span>
                          </button>
                        </div>

                        {ttsStatusScene[sceneNum] && (
                          <p className="text-[11px] text-purple-800 bg-white/70 p-2.5 rounded-lg border border-purple-200">
                            {ttsStatusScene[sceneNum]}
                          </p>
                        )}
                      </div>

                      {/* Preview Player */}
                      {targetScene?.audioUrl && (
                        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2">
                          <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                            <span className="flex items-center gap-1.5">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                              <span>Đã có file ghi âm cho Cảnh {sceneNum}:</span>
                            </span>
                            <button
                              onClick={() => onSceneAudioUpdated(sceneNum, '')}
                              className="text-red-600 hover:text-red-800 text-[11px] flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Xóa thu lại</span>
                            </button>
                          </div>
                          <audio src={targetScene.audioUrl} controls className="w-full h-10 rounded-lg accent-emerald-600" />
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Mic className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có kịch bản lời thoại</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Vui lòng hoàn thành kịch bản ở Phân hệ 2 để có lời thoại thu âm.
          </p>
        </div>
      )}
    </div>
  );
};
