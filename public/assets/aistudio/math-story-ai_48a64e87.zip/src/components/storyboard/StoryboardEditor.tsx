import React, { useState } from 'react';
import {
  Film,
  Sparkles,
  Edit2,
  Copy,
  Check,
  RefreshCw,
  Download,
  CheckCircle2,
  HelpCircle,
  Clock,
  Volume2,
  User,
  ArrowRight,
  Eye,
  Camera,
  Play,
  Layers,
} from 'lucide-react';
import {
  CharacterProfile,
  MathAnalysisResult,
  Scene,
  Storyboard,
  StoryTheme,
} from '../../types/mathStory';
import { generateStoryboardScript } from '../../services/api';

const THEMES: { id: StoryTheme; label: string; icon: string }[] = [
  { id: 'Gia đình và cuộc sống', label: 'Gia đình & Cuộc sống', icon: '🏡' },
  { id: 'Trường học vui vẻ', label: 'Trường học vui vẻ', icon: '🏫' },
  { id: 'Khu vườn Toán học', label: 'Khu vườn Toán học', icon: '🌻' },
  { id: 'Siêu thị mini', label: 'Siêu thị mini', icon: '🛒' },
  { id: 'Thế giới động vật', label: 'Thế giới động vật', icon: '🦊' },
  { id: 'Phiêu lưu cùng robot AI', label: 'Phiêu lưu cùng Robot AI', icon: '🤖' },
  { id: 'Cổ tích Toán học', label: 'Cổ tích Toán học', icon: '🏰' },
  { id: 'Thành phố thông minh', label: 'Thành phố thông minh', icon: '🚀' },
];

interface StoryboardEditorProps {
  analysis: MathAnalysisResult | null;
  characters: CharacterProfile[];
  currentStoryboard: Storyboard | null;
  onStoryboardSaved: (storyboard: Storyboard) => void;
  onOpenFlowGuideWithPrompt: (prompt: string, sceneTitle: string) => void;
  onGoToImageStudio: () => void;
}

export const StoryboardEditor: React.FC<StoryboardEditorProps> = ({
  analysis,
  characters,
  currentStoryboard,
  onStoryboardSaved,
  onOpenFlowGuideWithPrompt,
  onGoToImageStudio,
}) => {
  const [selectedTheme, setSelectedTheme] = useState<StoryTheme>(
    currentStoryboard?.theme || 'Gia đình và cuộc sống'
  );
  const [duration, setDuration] = useState<number>(currentStoryboard?.durationSeconds || 45);
  const [selectedCharId, setSelectedCharId] = useState<string>(
    characters[0]?.id || 'char-lan'
  );
  const [storyboard, setStoryboard] = useState<Storyboard | null>(currentStoryboard);
  const [loading, setLoading] = useState(false);
  const [editingSceneIdx, setEditingSceneIdx] = useState<number | null>(null);
  const [copiedPromptId, setCopiedPromptId] = useState<string | null>(null);
  const [isApproved, setIsApproved] = useState(false);

  // Keep local storyboard state synchronized when project or analysis changes
  React.useEffect(() => {
    if (currentStoryboard) {
      setStoryboard(currentStoryboard);
      if (currentStoryboard.theme) {
        setSelectedTheme(currentStoryboard.theme);
      }
      if (currentStoryboard.durationSeconds) {
        setDuration(currentStoryboard.durationSeconds);
      }
    }
  }, [currentStoryboard, analysis]);

  // Generate Script using AI or structured engine
  const handleGenerateScript = async () => {
    if (!analysis) return;
    setLoading(true);
    try {
      const result = await generateStoryboardScript(
        analysis.problemStatement,
        analysis,
        selectedTheme,
        duration,
        selectedCharId
      );
      setStoryboard(result);
      onStoryboardSaved(result);
      setIsApproved(false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyPrompt = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPromptId(id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  const handleSceneChange = (sceneIdx: number, field: keyof Scene, value: any) => {
    if (!storyboard) return;
    const updatedScenes = [...storyboard.scenes];
    updatedScenes[sceneIdx] = {
      ...updatedScenes[sceneIdx],
      [field]: value,
    };
    const updated = { ...storyboard, scenes: updatedScenes };
    setStoryboard(updated);
    onStoryboardSaved(updated);
  };

  const handleApproveStoryboard = () => {
    if (!storyboard) return;
    setIsApproved(true);
    onStoryboardSaved(storyboard);
  };

  const handleExportJSON = () => {
    if (!storyboard) return;
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(storyboard, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `kich-ban-toan2-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-sky-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-purple-100 text-purple-700">
              <Film className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-800">
              Phân Hệ 2: Biên Kịch Câu Chuyện & Storyboard AI
            </h2>
            <span className="text-xs bg-purple-100 text-purple-800 font-bold px-2.5 py-0.5 rounded-full">
              Chuẩn 3 cảnh sư phạm
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Tự động chia phân cảnh 3D thiếu nhi. Cảnh 2 tạm dừng xuất hiện câu hỏi tương tác, đảm bảo KHÔNG làm lộ kết quả trước khi học sinh tự mình tư duy.
          </p>
        </div>

        {storyboard && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Xuất kịch bản (JSON)</span>
            </button>
            <button
              onClick={handleApproveStoryboard}
              className={`flex items-center gap-1.5 text-xs font-black px-4 py-2 rounded-xl shadow transition-all ${
                isApproved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isApproved ? 'Đã duyệt kịch bản' : 'Duyệt kịch bản'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Control Configuration Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-slate-500">
          Cấu hình phong cách & Thời lượng kịch bản
        </h3>

        {/* 8 Themes Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => setSelectedTheme(t.id)}
              className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer ${
                selectedTheme === t.id
                  ? 'bg-sky-50 border-sky-500 shadow-xs ring-2 ring-sky-300'
                  : 'border-slate-200 hover:bg-slate-50 bg-white'
              }`}
            >
              <div className="text-xl mb-1">{t.icon}</div>
              <p className="text-[11px] font-extrabold text-slate-800 leading-tight line-clamp-1">
                {t.label}
              </p>
            </button>
          ))}
        </div>

        {/* Secondary options row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Nhân vật đại diện câu chuyện:
            </label>
            <select
              value={selectedCharId}
              onChange={(e) => setSelectedCharId(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
            >
              {characters.map((c) => {
                const cleanName = c.name.replace(/\s*\([^)]*\)/g, '').trim();
                return (
                  <option key={c.id} value={c.id}>
                    {c.fromCurrentProblem ? '✨ ' : ''}{cleanName}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Thời lượng mục tiêu:
            </label>
            <div className="flex gap-2">
              {[30, 45, 60].map((sec) => (
                <button
                  key={sec}
                  onClick={() => setDuration(sec)}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                    duration === sec
                      ? 'bg-sky-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {sec} Giây
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleGenerateScript}
              disabled={loading || !analysis}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-xs shadow transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Đang biên kịch...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{storyboard ? 'Biên Kịch Lại Storyboard' : 'Tạo Kịch Bản Storyboard AI'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Storyboard Scenes Display */}
      {storyboard ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {storyboard.scenes.map((scene, idx) => {
              const isInteractiveScene = Boolean(scene.interactiveQuestion);
              const isEditing = editingSceneIdx === idx;

              return (
                <div
                  key={scene.sceneNumber}
                  className={`bg-white rounded-3xl border-2 transition-all shadow-sm overflow-hidden flex flex-col ${
                    isInteractiveScene
                      ? 'border-amber-400 ring-2 ring-amber-100'
                      : 'border-slate-200 hover:border-sky-300'
                  }`}
                >
                  {/* Scene Card Header */}
                  <div
                    className={`p-4 flex items-center justify-between text-white ${
                      isInteractiveScene
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                        : 'bg-gradient-to-r from-sky-600 to-teal-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-black">
                        {scene.sceneNumber}
                      </span>
                      <h4 className="font-extrabold text-xs truncate max-w-[180px]">
                        {scene.title}
                      </h4>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] font-bold bg-black/20 px-2 py-0.5 rounded-full">
                      <Clock className="w-3 h-3" />
                      <span>{scene.duration}s</span>
                    </div>
                  </div>

                  {/* Scene Start Image Preview */}
                  {scene.imageUrl && (
                    <div className="relative aspect-video w-full bg-slate-900 overflow-hidden border-b border-slate-100">
                      <img
                        src={scene.imageUrl}
                        alt={scene.title}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1.5 left-2 bg-black/60 backdrop-blur-xs text-[10px] text-white px-2 py-0.5 rounded-md font-bold">
                        Khung hình bắt đầu
                      </span>
                    </div>
                  )}

                  {/* Scene Body */}
                  <div className="p-4 space-y-3.5 flex-1 text-xs">
                    {/* Setting & Action */}
                    <div>
                      <span className="text-[10px] font-extrabold text-slate-600 uppercase tracking-wider block mb-0.5">
                        Bối cảnh & Hành động:
                      </span>
                      {isEditing ? (
                        <textarea
                          value={scene.setting}
                          onChange={(e) => handleSceneChange(idx, 'setting', e.target.value)}
                          className="w-full text-xs p-2 border rounded bg-slate-50 font-medium"
                          rows={2}
                        />
                      ) : (
                        <p className="text-slate-700 leading-relaxed font-medium">
                          {scene.setting}
                        </p>
                      )}
                    </div>

                    {/* Dialogue */}
                    <div className="bg-sky-50/70 p-3 rounded-2xl border border-sky-100">
                      <div className="flex items-center gap-1 text-[11px] font-bold text-sky-800 mb-1">
                        <Volume2 className="w-3 h-3 text-sky-600" />
                        <span>Lời thoại tiếng Việt ({scene.characters.join(', ')}):</span>
                      </div>
                      {isEditing ? (
                        <textarea
                          value={scene.dialogue}
                          onChange={(e) => handleSceneChange(idx, 'dialogue', e.target.value)}
                          className="w-full text-xs p-2 border rounded bg-white font-medium"
                          rows={2}
                        />
                      ) : (
                        <p className="italic text-slate-800 font-semibold leading-relaxed">
                          "{scene.dialogue}"
                        </p>
                      )}
                    </div>

                    {/* Math Data Badge */}
                    <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl">
                      <span className="text-[10px] font-extrabold text-slate-500 uppercase">Dữ kiện:</span>
                      <span className="font-bold text-slate-800">{scene.mathData}</span>
                    </div>

                    {/* Interactive Question Box if scene 2 */}
                    {isInteractiveScene && scene.interactiveQuestion && (
                      <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3.5 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase bg-amber-500 text-white px-2 py-0.5 rounded-full">
                            Tạm dừng tương tác
                          </span>
                          <span className="text-[10px] text-amber-800 font-bold">Điểm dừng: giây thứ 15</span>
                        </div>
                        <p className="font-extrabold text-amber-950 text-xs">
                          {scene.interactiveQuestion.question}
                        </p>
                        <div className="space-y-1">
                          {scene.interactiveQuestion.options.map((opt, oIdx) => (
                            <div
                              key={oIdx}
                              className={`p-1.5 rounded-lg text-[11px] font-semibold border ${
                                opt.isCorrect
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                                  : 'bg-white border-amber-200 text-slate-700'
                              }`}
                            >
                              {opt.label} {opt.isCorrect && '✓ (Đáp án đúng)'}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Prompts for Image & Video */}
                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      {/* Image prompt */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-extrabold text-slate-600 uppercase flex items-center gap-1">
                            <Camera className="w-3 h-3 text-sky-600" />
                            <span>Prompt tạo ảnh (AI Image):</span>
                          </span>
                          <button
                            onClick={() => handleCopyPrompt(scene.imagePrompt, `img-${idx}`)}
                            className="text-[10px] font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1"
                          >
                            {copiedPromptId === `img-${idx}` ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span>Đã chép</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Chép</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="bg-slate-900 text-slate-300 p-2.5 rounded-xl font-mono text-[10px] leading-relaxed max-h-16 overflow-y-auto no-scrollbar">
                          {scene.imagePrompt}
                        </div>
                      </div>

                      {/* Video Motion prompt & Flow quick button */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-extrabold text-slate-600 uppercase flex items-center gap-1">
                            <Film className="w-3 h-3 text-purple-600" />
                            <span>Prompt chuyển động video:</span>
                          </span>
                          <button
                            onClick={() =>
                              onOpenFlowGuideWithPrompt(
                                scene.motionPrompt || scene.imagePrompt,
                                scene.title
                              )
                            }
                            className="text-[10px] font-bold text-purple-600 hover:text-purple-800 flex items-center gap-1 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200"
                          >
                            <span>Sang Google Flow</span>
                          </button>
                        </div>
                        <div className="bg-slate-900 text-slate-300 p-2.5 rounded-xl font-mono text-[10px] leading-relaxed max-h-14 overflow-y-auto no-scrollbar">
                          {scene.motionPrompt}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Scene Card Footer Actions */}
                  <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                    <button
                      onClick={() => setEditingSceneIdx(isEditing ? null : idx)}
                      className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>{isEditing ? 'Lưu cảnh' : 'Chỉnh sửa'}</span>
                    </button>

                    <button
                      onClick={onGoToImageStudio}
                      className="text-xs font-bold text-sky-700 hover:text-sky-900 flex items-center gap-1"
                    >
                      <span>Studio Ảnh</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Next Step Link */}
          <div className="bg-sky-50 rounded-2xl p-4 border border-sky-200 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs text-sky-900">
              <strong>Bước tiếp theo:</strong> Kịch bản đã được khởi tạo. Bạn có thể duyệt nhân vật ở <strong>Phân hệ 3</strong> hoặc chuyển sang <strong>Studio Tạo Ảnh (Phân hệ 4)</strong>.
            </div>
            <button
              onClick={onGoToImageStudio}
              className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <span>Tiếp tục: Chuyển sang Studio Tạo Ảnh</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Film className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
          <h4 className="font-extrabold text-slate-700 text-base">Chưa có kịch bản storyboard</h4>
          <p className="text-xs max-w-md mx-auto text-slate-500 leading-relaxed">
            Chọn chủ đề và nhân vật mong muốn ở trên, sau đó bấm nút <strong>"Tạo Kịch Bản Storyboard AI"</strong> để tạo phân cảnh chi tiết cho bài toán.
          </p>
        </div>
      )}
    </div>
  );
};
