import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ArrowRight,
  HelpCircle,
  Volume2,
  VolumeX,
  Music,
  Smile,
  ShieldCheck,
  ChevronRight,
  Award,
  Layers,
} from 'lucide-react';
import {
  ErrorType,
  InteractiveQuestion,
  ProjectLesson,
  Scene,
} from '../../types/mathStory';
import { submitStudentAnswer, requestTTS } from '../../services/api';
import { BaseTenBlocksVisual, OrangeCounterVisual } from '../common/DeterministicVisuals';
import { CartoonAnimatedVideo } from './CartoonAnimatedVideo';
import { soundEffects } from '../../utils/audioEffects';

interface InteractivePlayerProps {
  project: ProjectLesson;
  isDemoMode: boolean;
  studentName?: string;
  studentCode?: string;
  onGoToPersonalizedTier: () => void;
}

export const InteractivePlayer: React.FC<InteractivePlayerProps> = ({
  project,
  isDemoMode,
  studentName = 'Học sinh Lớp 2A2',
  studentCode = 'HS-2A2-DEMO',
  onGoToPersonalizedTier,
}) => {
  const [currentSceneIdx, setCurrentSceneIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [sceneProgress, setSceneProgress] = useState<number>(0); // 0 to 100
  const [isPausedForQuestion, setIsPausedForQuestion] = useState<boolean>(false);
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number | null>(null);
  const [answerState, setAnswerState] = useState<'idle' | 'correct' | 'incorrect'>('idle');
  const [feedbackText, setFeedbackText] = useState<string>('');
  const [currentHintLevel, setCurrentHintLevel] = useState<number>(0);
  const [attemptCount, setAttemptCount] = useState<number>(0);
  const [completedStory, setCompletedStory] = useState<boolean>(false);
  const [interactiveMode, setInteractiveMode] = useState<'multiple-choice' | 'drag-drop' | 'number-input'>('multiple-choice');
  const [videoDisplayMode, setVideoDisplayMode] = useState<'video-demo-3d' | 'video-uploaded' | 'image-cinematic'>('video-demo-3d');
  const [videoLoadError, setVideoLoadError] = useState<boolean>(false);
  const [draggedOrangesCount, setDraggedOrangesCount] = useState<number>(project.mathAnalysis?.num1 ?? 25);
  const [inputAnswerValue, setInputAnswerValue] = useState<string>('');

  // Audio subsystem states for Gemini TTS and ambient background music
  const [isMusicEnabled, setIsMusicEnabled] = useState<boolean>(true);
  const [isTtsPlaying, setIsTtsPlaying] = useState<boolean>(false);
  const [ttsLoading, setTtsLoading] = useState<boolean>(false);
  const dialogueAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (project.mathAnalysis?.num1 !== undefined) {
      setDraggedOrangesCount(project.mathAnalysis.num1);
    }
  }, [project.mathAnalysis]);

  const speakDialogueFallback = (text: string, characterName?: string) => {
    if ('speechSynthesis' in window && text) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'vi-VN';
      const char = (characterName || currentScene?.characters?.[0] || 'Bé Lan').toLowerCase();
      // Adjust pitch based on character: child characters get cute higher pitch, adults get warm natural pitch
      if (char.includes('lan') || char.includes('bé') || char.includes('con') || char.includes('minh') || char.includes('nam')) {
        utterance.pitch = 1.35; // Giọng trẻ em trong trẻo, hồn nhiên
        utterance.rate = 0.95;
      } else {
        utterance.pitch = 1.0; // Giọng mẹ / cô giáo dịu dàng
        utterance.rate = 0.88;
      }
      setIsTtsPlaying(true);
      soundEffects.duckBackgroundMusic(true);
      utterance.onend = () => {
        setIsTtsPlaying(false);
        if (!isPausedForQuestion) {
          soundEffects.duckBackgroundMusic(false);
        }
      };
      utterance.onerror = () => {
        setIsTtsPlaying(false);
        soundEffects.duckBackgroundMusic(false);
      };
      window.speechSynthesis.speak(utterance);
    }
  };

  const playDialogueAudio = async (text: string, customAudioUrl?: string, characterName?: string) => {
    if (!text && !customAudioUrl) return;

    // Stop currently running dialogue audio and synthesis
    if (dialogueAudioRef.current) {
      dialogueAudioRef.current.pause();
      dialogueAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    const charName = characterName || currentScene?.characters?.[0] || 'Bé Lan';
    let urlToPlay = customAudioUrl;

    if (!urlToPlay) {
      setTtsLoading(true);
      try {
        const res = await requestTTS(text, undefined, charName);
        if (res.success && res.audioUrl) {
          urlToPlay = res.audioUrl;
          if (currentScene) {
            currentScene.audioUrl = urlToPlay;
          }
        } else if (res.fallbackSpeech) {
          setTtsLoading(false);
          speakDialogueFallback(text, charName);
          return;
        }
      } catch (err) {
        console.warn('TTS fetch error, using client speech engine:', err);
      } finally {
        setTtsLoading(false);
      }
    }

    if (urlToPlay) {
      try {
        const audio = new Audio(urlToPlay);
        dialogueAudioRef.current = audio;
        setIsTtsPlaying(true);
        // Duck background music for clarity during dialogue
        soundEffects.duckBackgroundMusic(true);

        audio.onended = () => {
          setIsTtsPlaying(false);
          if (!isPausedForQuestion) {
            soundEffects.duckBackgroundMusic(false);
          }
        };

        audio.onerror = () => {
          setIsTtsPlaying(false);
          soundEffects.duckBackgroundMusic(false);
          speakDialogueFallback(text, charName);
        };

        await audio.play();
      } catch (e) {
        console.warn('Audio auto-play prevented or error, falling back to speech synthesis:', e);
        speakDialogueFallback(text, charName);
      }
    } else {
      speakDialogueFallback(text, charName);
    }
  };

  const scenes = project.storyboard?.scenes || [];
  const currentScene: Scene | undefined = scenes[currentSceneIdx];
  const question: InteractiveQuestion | null = currentScene?.interactiveQuestion || null;

  // Scene progression timer
  useEffect(() => {
    let interval: any = null;

    if (isPlaying && !isPausedForQuestion && !completedStory) {
      interval = setInterval(() => {
        setSceneProgress((prev) => {
          if (prev >= 100) {
            // Check if this scene has an interactive question and we haven't answered it yet
            if (currentScene?.interactiveQuestion && answerState !== 'correct') {
              setIsPausedForQuestion(true);
              setIsPlaying(false);
              soundEffects.playDingDong();
              return 100;
            }

            // Move to next scene
            if (currentSceneIdx < scenes.length - 1) {
              setCurrentSceneIdx((curr) => curr + 1);
              return 0;
            } else {
              // Completed all scenes
              setCompletedStory(true);
              setIsPlaying(false);
              soundEffects.playCelebration();
              return 100;
            }
          }
          return prev + 2.5; // smooth progress
        });
      }, 250);
    }

    return () => clearInterval(interval);
  }, [isPlaying, isPausedForQuestion, currentSceneIdx, scenes.length, answerState, completedStory]);

  // Background music management synchronized with player state
  useEffect(() => {
    const bgTheme = project.storyboard?.bgMusic || 'vui-tuoi';
    const bgVol = project.storyboard?.bgVolume ?? 25;

    if (isPlaying && !completedStory && isMusicEnabled && bgTheme !== 'khong-nhac') {
      soundEffects.startBackgroundMusic(bgTheme, bgVol);
      if (isPausedForQuestion || isTtsPlaying) {
        soundEffects.duckBackgroundMusic(true);
      } else {
        soundEffects.duckBackgroundMusic(false);
      }
    } else {
      soundEffects.stopBackgroundMusic();
    }

    return () => {
      soundEffects.stopBackgroundMusic();
      if (dialogueAudioRef.current) {
        dialogueAudioRef.current.pause();
      }
    };
  }, [isPlaying, isPausedForQuestion, isMusicEnabled, completedStory, isTtsPlaying, project.storyboard?.bgMusic, project.storyboard?.bgVolume]);

  // Auto-play scene dialogue audio whenever current scene changes
  useEffect(() => {
    if (currentScene && isPlaying && !isPausedForQuestion && !completedStory) {
      playDialogueAudio(currentScene.dialogue, currentScene.audioUrl);
    }
  }, [currentSceneIdx, isPlaying]);

  // Handle student selecting multiple choice option
  const handleSelectOption = async (optionIdx: number) => {
    if (!question) return;
    setSelectedOptionIdx(optionIdx);
    const chosen = question.options[optionIdx];
    const newAttempt = attemptCount + 1;
    setAttemptCount(newAttempt);

    if (chosen.isCorrect) {
      setAnswerState('correct');
      setFeedbackText(chosen.feedback);
      soundEffects.playCelebration();

      // Record successful answer
      await submitStudentAnswer({
        projectId: project.id,
        studentCode,
        studentName,
        chosenOption: chosen.label,
        isCorrect: true,
        attemptCount: newAttempt,
        timeTakenSeconds: 12,
        errorType: 'KHÔNG_CÓ',
        isDemo: isDemoMode,
      });
    } else {
      setAnswerState('incorrect');
      setFeedbackText(chosen.feedback);
      setCurrentHintLevel((prev) => Math.min(prev + 1, 2));
      soundEffects.playTryAgain();

      // Record error for diagnostics
      await submitStudentAnswer({
        projectId: project.id,
        studentCode,
        studentName,
        chosenOption: chosen.label,
        isCorrect: false,
        attemptCount: newAttempt,
        timeTakenSeconds: 15,
        errorType: 'SAI_LỰA_CHỌN_PHÉP_TÍNH',
        isDemo: isDemoMode,
      });
    }
  };

  // Continue story after answering correctly
  const handleResumeStory = () => {
    setIsPausedForQuestion(false);
    setAnswerState('idle');
    setSelectedOptionIdx(null);
    if (currentSceneIdx < scenes.length - 1) {
      setCurrentSceneIdx((prev) => prev + 1);
      setSceneProgress(0);
      setIsPlaying(true);
    } else {
      setCompletedStory(true);
    }
  };

  const handleRestart = () => {
    setCurrentSceneIdx(0);
    setSceneProgress(0);
    setIsPausedForQuestion(false);
    setSelectedOptionIdx(null);
    setAnswerState('idle');
    setFeedbackText('');
    setCurrentHintLevel(0);
    setAttemptCount(0);
    setCompletedStory(false);
    setDraggedOrangesCount(25);
    setIsPlaying(true);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner for Student View */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-sky-600 rounded-3xl p-6 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-black backdrop-blur-xs">
              🌟 RẠP PHIM TOÁN HỌC TƯƠNG TÁC
            </span>
            <span className="text-xs bg-amber-300 text-amber-950 font-black px-2.5 py-0.5 rounded-full">
              Lớp 2A2
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-black">{project.title}</h2>
          <p className="text-xs text-amber-100 font-medium">
            Học sinh: <strong>{studentName}</strong> | Đề tài: <em>{project.problemText}</em>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Display Mode switch: 3D Pixar Video vs Uploaded Video vs Cinematic Image */}
          <div className="bg-black/30 p-1 rounded-2xl flex text-xs border border-white/20">
            <button
              onClick={() => setVideoDisplayMode('video-demo-3d')}
              className={`px-3.5 py-1.5 rounded-xl font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                videoDisplayMode === 'video-demo-3d'
                  ? 'bg-amber-400 text-slate-950 shadow-md scale-102'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <span>🎬 Video Demo 3D</span>
              <span className="bg-red-600 text-white text-[9px] px-1 py-0.2 rounded font-black animate-pulse">100% 3D</span>
            </button>
            {currentScene?.videoUrl && (
              <button
                onClick={() => setVideoDisplayMode('video-uploaded')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 cursor-pointer ${
                  videoDisplayMode === 'video-uploaded'
                    ? 'bg-white text-slate-900 shadow-md'
                    : 'text-white/80 hover:text-white'
                }`}
              >
                <span>🎥 Clip Tải Lên</span>
              </button>
            )}
            <button
              onClick={() => setVideoDisplayMode('image-cinematic')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                videoDisplayMode === 'image-cinematic'
                  ? 'bg-white text-slate-900 shadow-md'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <span>🖼️ Tranh 3D Minh Họa</span>
            </button>
          </div>

          {/* Mode switch */}
          <div className="bg-black/20 p-1 rounded-2xl flex text-xs">
            <button
              onClick={() => setInteractiveMode('multiple-choice')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                interactiveMode === 'multiple-choice'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              Chọn phép tính
            </button>
            <button
              onClick={() => setInteractiveMode('drag-drop')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                interactiveMode === 'drag-drop'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              Đếm cam trực quan
            </button>
          </div>
        </div>
      </div>

      {/* Main Interactive Screen Theater */}
      <div className="relative bg-slate-950 rounded-3xl overflow-hidden border-4 border-amber-300 shadow-2xl">
        {/* Top Status Bar in Player */}
        <div className="absolute top-0 inset-x-0 z-20 bg-gradient-to-b from-black/85 via-black/50 to-transparent p-4 flex flex-wrap items-center justify-between gap-2 text-white text-xs">
          <div className="flex items-center gap-2">
            <span className="bg-amber-500 text-slate-950 font-black px-2.5 py-0.5 rounded-md text-[11px]">
              CẢNH {currentScene?.sceneNumber || 1} / {scenes.length}
            </span>
            <span className="font-bold drop-shadow hidden sm:inline">{currentScene?.title}</span>
            <span className="bg-purple-900/80 text-purple-200 border border-purple-500/40 px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${isTtsPlaying ? 'bg-emerald-400 animate-ping' : 'bg-purple-400'}`} />
              <span>Gemini TTS</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Background Music */}
            <button
              onClick={() => setIsMusicEnabled(!isMusicEnabled)}
              title="Bật/Tắt nhạc nền hoạt hình"
              className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg backdrop-blur-xs transition-colors cursor-pointer border ${
                isMusicEnabled
                  ? 'bg-pink-950/70 text-pink-200 border-pink-500/50 hover:bg-pink-900/80'
                  : 'bg-slate-800/80 text-slate-400 border-slate-600 hover:text-white'
              }`}
            >
              {isMusicEnabled ? <Music className="w-3.5 h-3.5 text-pink-400" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isMusicEnabled ? 'Nhạc nền: Bật' : 'Nhạc nền: Tắt'}</span>
            </button>

            {/* Replay Dialogue Audio with Gemini TTS */}
            <button
              onClick={() => playDialogueAudio(currentScene?.dialogue || '', currentScene?.audioUrl)}
              disabled={ttsLoading}
              className="flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-950/70 border border-amber-500/50 px-2.5 py-1 rounded-lg backdrop-blur-xs cursor-pointer disabled:opacity-50"
            >
              <Volume2 className={`w-3.5 h-3.5 ${isTtsPlaying ? 'animate-bounce text-emerald-400' : ''}`} />
              <span>{ttsLoading ? 'Đang tải âm...' : 'Phát lại lời thoại'}</span>
            </button>

            {/* Restart */}
            <button
              onClick={handleRestart}
              className="flex items-center gap-1 text-[11px] font-bold text-slate-200 hover:text-white bg-white/20 px-2.5 py-1 rounded-lg backdrop-blur-xs cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">Xem lại từ đầu</span>
            </button>
          </div>
        </div>

        {/* Video / Visual Screen Area */}
        <div className="relative aspect-video w-full flex items-center justify-center bg-slate-900">
          {/* PRIMARY: 100% 3D Animated Cartoon Simulation Video (Guaranteed instant 0ms, zero lag, fail-proof) */}
          {videoDisplayMode === 'video-demo-3d' && currentScene && (
            <CartoonAnimatedVideo
              sceneNumber={currentScene.sceneNumber}
              isPlaying={isPlaying && !isPausedForQuestion}
              dialogue={currentScene.dialogue}
              mathData={currentScene.mathData}
              num1={project.mathAnalysis?.num1}
              num2={project.mathAnalysis?.num2}
              result={project.mathAnalysis?.result ?? undefined}
              operation={project.mathAnalysis?.operation}
              unit={project.mathAnalysis?.unit}
              characterName={currentScene.characters?.[0] || 'Bé Lan'}
              problemTitle={project.title}
            />
          )}

          {/* SECONDARY: User-uploaded custom video clip if present */}
          {videoDisplayMode === 'video-uploaded' && currentScene?.videoUrl && (
            <div className="w-full h-full relative">
              <video
                key={currentScene.sceneNumber}
                src={currentScene.videoUrl}
                controls
                autoPlay={isPlaying && !isPausedForQuestion}
                className="w-full h-full object-cover"
                onError={() => {
                  console.warn('Uploaded video error, switching back to 3D Pixar Animation');
                  setVideoDisplayMode('video-demo-3d');
                }}
                onEnded={() => {
                  if (currentScene.interactiveQuestion && answerState !== 'correct') {
                    setIsPausedForQuestion(true);
                    setIsPlaying(false);
                    soundEffects.playDingDong();
                  } else if (currentSceneIdx < scenes.length - 1) {
                    setCurrentSceneIdx((curr) => curr + 1);
                    setSceneProgress(0);
                  } else {
                    setCompletedStory(true);
                  }
                }}
              />
            </div>
          )}

          {/* OPTION 3: Cinematic High-Definition Illustration */}
          {videoDisplayMode === 'image-cinematic' && (
            <div className="w-full h-full relative overflow-hidden">
              <img
                src={
                  currentScene?.imageUrl ||
                  'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=1200&q=80'
                }
                alt={currentScene?.title}
                className={`w-full h-full object-cover transition-transform duration-3000 ${
                  isPlaying ? 'scale-110' : 'scale-100'
                }`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />
            </div>
          )}

          {/* Subtitles & Spoken Dialogue (Visible in uploaded video and cinematic image modes) */}
          {videoDisplayMode !== 'video-demo-3d' && (
            <div className="absolute bottom-4 inset-x-4 z-10 bg-black/80 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-white text-center pointer-events-none">
              <p className="text-xs md:text-sm font-black text-amber-300 drop-shadow">
                "{currentScene?.dialogue}"
              </p>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                — {currentScene?.characters.join(', ')} ({currentScene?.mathData}) —
              </span>
            </div>
          )}

          {/* INTERACTIVE QUESTION OVERLAY (POPS UP WHEN VIDEO PAUSES AT SCENE 2) */}
          {isPausedForQuestion && question && (
            <div className="absolute inset-0 z-30 bg-slate-950/85 backdrop-blur-md p-6 flex flex-col justify-center items-center animate-in fade-in zoom-in-95 duration-200">
              <div className="max-w-xl w-full bg-white rounded-3xl p-6 border-4 border-amber-400 shadow-2xl space-y-4 text-slate-800">
                {/* Header Question */}
                <div className="flex items-center justify-between border-b border-amber-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center font-black text-sm">
                      ❓
                    </span>
                    <h3 className="text-base font-black text-amber-950">
                      THỬ THÁCH TƯ DUY CHO BÉ
                    </h3>
                  </div>
                  <span className="text-xs bg-amber-100 text-amber-800 font-extrabold px-3 py-1 rounded-full">
                    Lan đang chờ em giúp!
                  </span>
                </div>

                <div className="text-sm font-extrabold text-slate-900 leading-snug">
                  {question.question}
                </div>

                {/* Multiple choice options */}
                <div className="space-y-2.5">
                  {question.options.map((opt, idx) => {
                    const isSelected = selectedOptionIdx === idx;
                    let style = 'border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 bg-white';

                    if (isSelected) {
                      if (answerState === 'correct') {
                        style = 'border-emerald-500 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-300';
                      } else if (answerState === 'incorrect') {
                        style = 'border-amber-400 bg-amber-50 text-amber-950 ring-2 ring-amber-300';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectOption(idx)}
                        className={`w-full p-3.5 rounded-2xl border-2 text-left font-extrabold text-sm flex items-center justify-between transition-all cursor-pointer shadow-xs ${style}`}
                      >
                        <span>{opt.label}</span>
                        {isSelected && answerState === 'correct' && (
                          <span className="text-emerald-600 font-black">✓ Đúng rồi!</span>
                        )}
                        {isSelected && answerState === 'incorrect' && (
                          <span className="text-amber-600 font-bold">Thử lại nhé</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Gentle Feedback and Hints */}
                {answerState === 'correct' && (
                  <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-4 space-y-2 animate-in fade-in duration-200">
                    <div className="flex items-center gap-2 text-emerald-900 font-black text-sm">
                      <Sparkles className="w-5 h-5 text-emerald-600 animate-bounce" />
                      <span>HOAN HÔ EM! CHÍNH XÁC TUYỆT ĐỐI!</span>
                    </div>
                    <p className="text-xs text-emerald-800 font-medium leading-relaxed">
                      {feedbackText}
                    </p>
                    <button
                      onClick={handleResumeStory}
                      className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Tiếp Tục Xem Câu Chuyện Kết Thúc</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {answerState === 'incorrect' && (
                  <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 space-y-2 animate-in fade-in duration-200">
                    <div className="flex items-center gap-2 text-amber-900 font-extrabold text-xs">
                      <Smile className="w-4 h-4 text-amber-600" />
                      <span>Không sao cả, hãy đọc gợi ý của cô giáo nhé:</span>
                    </div>
                    <p className="text-xs text-amber-800 font-medium">{feedbackText}</p>

                    {currentHintLevel >= 1 && (
                      <div className="bg-white/80 p-2.5 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
                        <p className="font-bold">💡 Gợi ý 1: {question.hintStep1}</p>
                        {currentHintLevel >= 2 && (
                          <p className="font-bold text-sky-800">
                            💡 Gợi ý 2: {question.hintStep2}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STORY COMPLETED CONGRATULATIONS OVERLAY */}
          {completedStory && (
            <div className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-md p-6 flex flex-col justify-center items-center animate-in fade-in duration-300 text-white text-center">
              <div className="max-w-md w-full bg-gradient-to-b from-sky-900 to-slate-900 border-2 border-amber-300 rounded-3xl p-6 space-y-4 shadow-2xl">
                <div className="text-4xl animate-bounce">🎉🏆</div>
                <h3 className="text-xl font-black text-amber-300">
                  CHÚC MỪNG EM ĐÃ HOÀN THÀNH BÀI TOÁN!
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {currentScene?.characters?.[0] || 'Bé Lan'} đã tìm ra đáp án là <strong>{project.mathAnalysis?.result ?? 42} {project.mathAnalysis?.unit ?? 'quả cam'}</strong> bằng phép tính <strong>{project.mathAnalysis?.calculation ? `${project.mathAnalysis.calculation} = ${project.mathAnalysis.result}` : '25 + 17 = 42'}</strong>. Em đã thể hiện tư duy toán học rất xuất sắc!
                </p>

                <div className="bg-white/10 p-3 rounded-2xl border border-white/20 text-xs space-y-1">
                  <p>Số lần thử: <strong>{attemptCount} lần</strong></p>
                  <p className="text-emerald-300 font-bold">Đã lưu kết quả rèn luyện vào hồ sơ Lớp 2A2 ✓</p>
                </div>

                <div className="flex flex-col gap-2 pt-2">
                  <button
                    onClick={onGoToPersonalizedTier}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 text-slate-950 font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Luyện Tập 3 Mức Độ Cá Nhân Hóa (Phân hệ 8)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={handleRestart}
                    className="w-full py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs"
                  >
                    Xem lại câu chuyện hoạt hình
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Playback Control Bar */}
        <div className="bg-slate-900 px-6 py-3 flex items-center justify-between text-xs text-white border-t border-slate-800">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={isPausedForQuestion || completedStory}
              className="w-8 h-8 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center font-bold disabled:opacity-40 cursor-pointer shadow"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
            <span className="font-bold text-slate-300">
              Cảnh {currentScene?.sceneNumber}: {currentScene?.duration}s
            </span>
          </div>

          {/* Progress bar */}
          <div className="flex-1 mx-6 h-2 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-sky-400 transition-all duration-300"
              style={{ width: `${sceneProgress}%` }}
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-amber-300 font-extrabold">
              {isPausedForQuestion ? 'TẠM DỪNG: CÂU HỎI' : isPlaying ? 'ĐANG PHÁT' : 'TẠM DỪNG'}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Scene Selector & Video Mode Alert */}
      {videoLoadError && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3 text-xs text-amber-900 flex items-center justify-between animate-in fade-in">
          <span>
            💡 <strong>Thông báo mượt mà:</strong> Môi trường mạng/iframe đang bật tường lửa, hệ thống đã tự động kích hoạt <strong>Động cơ Hoạt Họa 3D Bé Lan</strong> để video phát tức thì, không bị loading!
          </span>
          <button
            onClick={() => setVideoLoadError(false)}
            className="text-amber-700 hover:text-amber-900 font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Quick Scene Navigation Bar */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-slate-700">
          <span>Chọn xem nhanh phân cảnh:</span>
        </div>
        <div className="flex items-center gap-2">
          {scenes.map((s, idx) => (
            <button
              key={s.sceneNumber}
              onClick={() => {
                setCurrentSceneIdx(idx);
                setSceneProgress(0);
                setIsPausedForQuestion(false);
                setAnswerState('idle');
                setIsPlaying(true);
              }}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                currentSceneIdx === idx
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              Cảnh {s.sceneNumber}: {s.title.split(':')[0]} {s.interactiveQuestion ? '(Dừng hỏi ❓)' : ''}
            </button>
          ))}
        </div>
      </div>

      {/* Alternative Interactive Mode: Drag-Drop / Visual Counter */}
      {interactiveMode === 'drag-drop' && (
        <div className="bg-white rounded-3xl p-6 border border-amber-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-slate-800 text-sm">
                Thao Tác Trực Quan: Đếm & Thao Tác Số Lượng {project.mathAnalysis?.unit || 'quả cam'}
              </h3>
              <p className="text-xs text-slate-500">
                Lúc đầu có {project.mathAnalysis?.num1 ?? 25} {project.mathAnalysis?.unit || 'quả cam'}. Bấm nút để trực quan hóa số lượng và tính toán.
              </p>
            </div>
            <button
              onClick={() => setDraggedOrangesCount(project.mathAnalysis?.num1 ?? 25)}
              className="text-xs text-sky-700 font-bold bg-sky-50 px-3 py-1.5 rounded-xl border border-sky-200"
            >
              Đặt lại {project.mathAnalysis?.num1 ?? 25} ban đầu
            </button>
          </div>

          {/* Visual representations */}
          <OrangeCounterVisual
            count={draggedOrangesCount}
            unit={project.mathAnalysis?.unit || 'quả cam'}
            label={`Số lượng hiện tại: ${draggedOrangesCount} ${project.mathAnalysis?.unit || 'quả cam'}`}
          />

          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setDraggedOrangesCount((prev) => prev + 1)}
              className="px-4 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs border border-amber-300 shadow-2xs cursor-pointer"
            >
              + 1 {project.mathAnalysis?.unit || 'đơn vị'}
            </button>
            <button
              onClick={() => setDraggedOrangesCount((prev) => prev + 10)}
              className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-xs cursor-pointer"
            >
              + 10 (1 chục)
            </button>
            <button
              onClick={() => setDraggedOrangesCount(project.mathAnalysis?.result ?? 42)}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer"
            >
              Kết quả chuẩn ({project.mathAnalysis?.result ?? 42})
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
